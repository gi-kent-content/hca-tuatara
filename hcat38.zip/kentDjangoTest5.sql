-- MySQL dump 10.15  Distrib 10.0.36-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: kentDjangoTest5
-- ------------------------------------------------------
-- Server version	10.0.36-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
INSERT INTO `auth_group` VALUES (1,'wranglers'),(2,'readers'),(3,'pipeliners');
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=249 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
INSERT INTO `auth_group_permissions` VALUES (2,1,25),(3,1,26),(4,1,27),(5,1,28),(6,1,29),(7,1,30),(8,1,31),(9,1,32),(10,1,33),(11,1,34),(12,1,35),(13,1,36),(14,1,37),(15,1,38),(16,1,39),(17,1,40),(18,1,41),(19,1,42),(20,1,43),(21,1,44),(25,1,48),(29,1,52),(33,1,56),(34,1,57),(35,1,58),(36,1,59),(37,1,60),(41,1,64),(45,1,68),(46,1,69),(47,1,70),(48,1,71),(49,1,72),(50,1,73),(51,1,74),(52,1,75),(53,1,76),(54,1,77),(55,1,78),(56,1,79),(57,1,80),(58,1,81),(59,1,82),(60,1,83),(61,1,84),(62,1,85),(63,1,86),(64,1,87),(65,1,88),(66,1,89),(67,1,90),(68,1,91),(69,1,92),(70,1,93),(71,1,94),(72,1,95),(73,1,96),(74,1,97),(75,1,98),(76,1,99),(77,1,100),(79,2,128),(80,2,4),(81,2,132),(83,2,136),(85,2,140),(87,2,144),(88,2,20),(89,2,148),(90,2,152),(145,2,160),(92,2,28),(93,2,32),(94,2,36),(95,2,40),(96,2,44),(97,2,48),(98,2,52),(99,2,56),(100,2,60),(101,2,64),(102,2,68),(103,2,72),(104,2,76),(105,2,80),(106,2,84),(107,2,88),(108,2,92),(109,2,96),(110,2,100),(111,2,104),(112,2,108),(113,2,112),(114,2,116),(115,2,120),(116,2,124),(117,1,157),(118,1,158),(119,1,159),(120,1,160),(124,1,164),(125,1,165),(126,1,166),(127,1,167),(128,1,168),(129,1,169),(130,1,170),(131,1,171),(132,1,172),(133,1,173),(134,1,174),(135,1,175),(136,1,176),(137,1,101),(138,1,102),(139,1,103),(140,1,104),(141,1,105),(142,1,106),(143,1,107),(144,1,108),(146,2,164),(147,2,168),(148,2,172),(149,2,176),(150,2,236),(151,2,240),(152,2,244),(153,2,248),(154,2,252),(155,3,4),(156,3,32),(157,3,164),(158,3,168),(159,3,40),(160,3,44),(161,3,172),(162,3,48),(163,3,52),(164,3,56),(165,3,60),(166,3,64),(167,3,68),(168,3,72),(169,3,76),(170,3,80),(171,3,84),(172,3,88),(173,3,92),(174,3,96),(175,3,100),(176,3,104),(177,3,108),(178,3,236),(179,3,240),(180,3,244),(218,3,268),(217,3,264),(216,2,268),(184,1,236),(215,2,264),(214,1,268),(213,1,264),(188,1,240),(189,1,245),(190,1,246),(191,1,247),(192,1,248),(193,1,249),(194,1,250),(195,1,251),(196,1,252),(197,1,256),(198,1,253),(199,1,254),(200,1,255),(201,1,241),(202,1,244),(203,3,260),(204,3,101),(205,2,256),(206,2,260),(207,1,260),(208,3,41),(209,1,242),(210,3,42),(211,3,29),(212,3,30),(219,3,272),(220,2,272),(221,1,272),(222,3,276),(223,2,8),(224,2,12),(225,2,16),(226,2,276),(227,2,24),(228,1,161),(229,1,162),(230,1,163),(231,1,233),(232,1,234),(233,1,235),(234,1,273),(235,1,274),(236,1,275),(237,1,281),(238,1,282),(239,1,283),(240,1,284),(241,3,284),(242,2,280),(243,2,284),(244,3,280),(245,1,280),(246,1,277),(247,1,278),(248,1,279);
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=285 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add funder',7,'add_funder'),(26,'Can change funder',7,'change_funder'),(27,'Can delete funder',7,'delete_funder'),(28,'Can view funder',7,'view_funder'),(29,'Can add lab',8,'add_lab'),(30,'Can change lab',8,'change_lab'),(31,'Can delete lab',8,'delete_lab'),(32,'Can view lab',8,'view_lab'),(33,'Can add grant',9,'add_grant'),(34,'Can change grant',9,'change_grant'),(35,'Can delete grant',9,'delete_grant'),(36,'Can view grant',9,'view_grant'),(37,'Can add project',10,'add_project'),(38,'Can change project',10,'change_project'),(39,'Can delete project',10,'delete_project'),(40,'Can view project',10,'view_project'),(41,'Can add contributor',11,'add_contributor'),(42,'Can change contributor',11,'change_contributor'),(43,'Can delete contributor',11,'delete_contributor'),(44,'Can view contributor',11,'view_contributor'),(45,'Can add project status',12,'add_projectstatus'),(46,'Can change project status',12,'change_projectstatus'),(47,'Can delete project status',12,'delete_projectstatus'),(48,'Can view project status',12,'view_projectstatus'),(49,'Can add project status',13,'add_projectstatus'),(50,'Can change project status',13,'change_projectstatus'),(51,'Can delete project status',13,'delete_projectstatus'),(52,'Can view project status',13,'view_projectstatus'),(53,'Can add project state',12,'add_projectstate'),(54,'Can change project state',12,'change_projectstate'),(55,'Can delete project state',12,'delete_projectstate'),(56,'Can view project state',12,'view_projectstate'),(57,'Can add body part',14,'add_bodypart'),(58,'Can change body part',14,'change_bodypart'),(59,'Can delete body part',14,'delete_bodypart'),(60,'Can view body part',14,'view_bodypart'),(61,'Can add consent',15,'add_consent'),(62,'Can change consent',15,'change_consent'),(63,'Can delete consent',15,'delete_consent'),(64,'Can view consent',15,'view_consent'),(65,'Can add species',16,'add_species'),(66,'Can change species',16,'change_species'),(67,'Can delete species',16,'delete_species'),(68,'Can view species',16,'view_species'),(69,'Can add disease',17,'add_disease'),(70,'Can change disease',17,'change_disease'),(71,'Can delete disease',17,'delete_disease'),(72,'Can view disease',17,'view_disease'),(73,'Can add organ part',14,'add_organpart'),(74,'Can change organ part',14,'change_organpart'),(75,'Can delete organ part',14,'delete_organpart'),(76,'Can view organ part',14,'view_organpart'),(77,'Can add organ',18,'add_organ'),(78,'Can change organ',18,'change_organ'),(79,'Can delete organ',18,'delete_organ'),(80,'Can view organ',18,'view_organ'),(81,'Can add cell culture',19,'add_cellculture'),(82,'Can change cell culture',19,'change_cellculture'),(83,'Can delete cell culture',19,'delete_cellculture'),(84,'Can view cell culture',19,'view_cellculture'),(85,'Can add sample type',19,'add_sampletype'),(86,'Can change sample type',19,'change_sampletype'),(87,'Can delete sample type',19,'delete_sampletype'),(88,'Can view sample type',19,'view_sampletype'),(89,'Can add assay tech',20,'add_assaytech'),(90,'Can change assay tech',20,'change_assaytech'),(91,'Can delete assay tech',20,'delete_assaytech'),(92,'Can view assay tech',20,'view_assaytech'),(93,'Can add assay type',21,'add_assaytype'),(94,'Can change assay type',21,'change_assaytype'),(95,'Can delete assay type',21,'delete_assaytype'),(96,'Can view assay type',21,'view_assaytype'),(97,'Can add publication',22,'add_publication'),(98,'Can change publication',22,'change_publication'),(99,'Can delete publication',22,'delete_publication'),(100,'Can view publication',22,'view_publication'),(101,'Can add assay tech',21,'add_assaytech'),(102,'Can change assay tech',21,'change_assaytech'),(103,'Can delete assay tech',21,'delete_assaytech'),(104,'Can view assay tech',21,'view_assaytech'),(105,'Can add assay type',20,'add_assaytype'),(106,'Can change assay type',20,'change_assaytype'),(107,'Can delete assay type',20,'delete_assaytype'),(108,'Can view assay type',20,'view_assaytype'),(157,'Can add comment',24,'add_comment'),(158,'Can change comment',24,'change_comment'),(159,'Can delete comment',24,'delete_comment'),(160,'Can view comment',24,'view_comment'),(161,'Can add project origin',25,'add_projectorigin'),(162,'Can change project origin',25,'change_projectorigin'),(163,'Can delete project origin',25,'delete_projectorigin'),(164,'Can view project origin',25,'view_projectorigin'),(165,'Can add file',26,'add_file'),(166,'Can change file',26,'change_file'),(167,'Can delete file',26,'delete_file'),(168,'Can view file',26,'view_file'),(169,'Can add url',27,'add_url'),(170,'Can change url',27,'change_url'),(171,'Can delete url',27,'delete_url'),(172,'Can view url',27,'view_url'),(173,'Can add Wrangle comment type',23,'add_commenttype'),(174,'Can change Wrangle comment type',23,'change_commenttype'),(175,'Can delete Wrangle comment type',23,'delete_commenttype'),(176,'Can view Wrangle comment type',23,'view_commenttype'),(177,'Can add Wrangle comment',28,'add_comment'),(178,'Can change Wrangle comment',28,'change_comment'),(179,'Can delete Wrangle comment',28,'delete_comment'),(180,'Can view Wrangle comment',28,'view_comment'),(181,'Can add Wrangle consent',29,'add_consent'),(182,'Can change Wrangle consent',29,'change_consent'),(183,'Can delete Wrangle consent',29,'delete_consent'),(184,'Can view Wrangle consent',29,'view_consent'),(185,'Can add Wrangle assay tech',30,'add_assaytech'),(186,'Can change Wrangle assay tech',30,'change_assaytech'),(187,'Can delete Wrangle assay tech',30,'delete_assaytech'),(188,'Can view Wrangle assay tech',30,'view_assaytech'),(189,'Can add Wrangle assay type',31,'add_assaytype'),(190,'Can change Wrangle assay type',31,'change_assaytype'),(191,'Can delete Wrangle assay type',31,'delete_assaytype'),(192,'Can view Wrangle assay type',31,'view_assaytype'),(193,'Can add Wrangle disease',32,'add_disease'),(194,'Can change Wrangle disease',32,'change_disease'),(195,'Can delete Wrangle disease',32,'delete_disease'),(196,'Can view Wrangle disease',32,'view_disease'),(197,'Can add Wrangle file',33,'add_file'),(198,'Can change Wrangle file',33,'change_file'),(199,'Can delete Wrangle file',33,'delete_file'),(200,'Can view Wrangle file',33,'view_file'),(201,'Can add Wrangle funder',34,'add_funder'),(202,'Can change Wrangle funder',34,'change_funder'),(203,'Can delete Wrangle funder',34,'delete_funder'),(204,'Can view Wrangle funder',34,'view_funder'),(205,'Can add Wrangle organ',35,'add_organ'),(206,'Can change Wrangle organ',35,'change_organ'),(207,'Can delete Wrangle organ',35,'delete_organ'),(208,'Can view Wrangle organ',35,'view_organ'),(209,'Can add Wrangle organ part',36,'add_organpart'),(210,'Can change Wrangle organ part',36,'change_organpart'),(211,'Can delete Wrangle organ part',36,'delete_organpart'),(212,'Can view Wrangle organ part',36,'view_organpart'),(213,'Can add Wrangle project origin',37,'add_projectorigin'),(214,'Can change Wrangle project origin',37,'change_projectorigin'),(215,'Can delete Wrangle project origin',37,'delete_projectorigin'),(216,'Can view Wrangle project origin',37,'view_projectorigin'),(217,'Can add Wrangle project state',38,'add_projectstate'),(218,'Can change Wrangle project state',38,'change_projectstate'),(219,'Can delete Wrangle project state',38,'delete_projectstate'),(220,'Can view Wrangle project state',38,'view_projectstate'),(221,'Can add Wrangle publication',39,'add_publication'),(222,'Can change Wrangle publication',39,'change_publication'),(223,'Can delete Wrangle publication',39,'delete_publication'),(224,'Can view Wrangle publication',39,'view_publication'),(225,'Can add Wrangle sample type',40,'add_sampletype'),(226,'Can change Wrangle sample type',40,'change_sampletype'),(227,'Can delete Wrangle sample type',40,'delete_sampletype'),(228,'Can view Wrangle sample type',40,'view_sampletype'),(229,'Can add Wrangle URL',41,'add_url'),(230,'Can change Wrangle URL',41,'change_url'),(231,'Can delete Wrangle URL',41,'delete_url'),(232,'Can view Wrangle URL',41,'view_url'),(233,'Can add Wrangler effort type',25,'add_efforttype'),(234,'Can change Wrangler effort type',25,'change_efforttype'),(235,'Can delete Wrangler effort type',25,'delete_efforttype'),(236,'Can view Wrangler effort type',25,'view_efforttype'),(237,'Can add Wrangler contributor type',42,'add_contributortype'),(238,'Can change Wrangler contributor type',42,'change_contributortype'),(239,'Can delete Wrangler contributor type',42,'delete_contributortype'),(240,'Can view Wrangler contributor type',42,'view_contributortype'),(241,'Can add wrangler',43,'add_wrangler'),(242,'Can change wrangler',43,'change_wrangler'),(243,'Can delete wrangler',43,'delete_wrangler'),(244,'Can view wrangler',43,'view_wrangler'),(245,'Can add curator',44,'add_curator'),(246,'Can change curator',44,'change_curator'),(247,'Can delete curator',44,'delete_curator'),(248,'Can view curator',44,'view_curator'),(249,'Can add software developer',45,'add_softwaredeveloper'),(250,'Can change software developer',45,'change_softwaredeveloper'),(251,'Can delete software developer',45,'delete_softwaredeveloper'),(252,'Can view software developer',45,'view_softwaredeveloper'),(253,'Can add intern',44,'add_intern'),(254,'Can change intern',44,'change_intern'),(255,'Can delete intern',44,'delete_intern'),(256,'Can view intern',44,'view_intern'),(257,'Can add tracker',46,'add_tracker'),(258,'Can change tracker',46,'change_tracker'),(259,'Can delete tracker',46,'delete_tracker'),(260,'Can view tracker',46,'view_tracker'),(261,'Can add x wrangling state',47,'add_wranglingstate'),(262,'Can change x wrangling state',47,'change_wranglingstate'),(263,'Can delete x wrangling state',47,'delete_wranglingstate'),(264,'Can view x wrangling state',47,'view_wranglingstate'),(265,'Can add x wrangling status',47,'add_wranglingstatus'),(266,'Can change x wrangling status',47,'change_wranglingstatus'),(267,'Can delete x wrangling status',47,'delete_wranglingstatus'),(268,'Can view x wrangling status',47,'view_wranglingstatus'),(269,'Can add x project tag',48,'add_tag'),(270,'Can change x project tag',48,'change_tag'),(271,'Can delete x project tag',48,'delete_tag'),(272,'Can view x project tag',48,'view_tag'),(273,'Can add x project source type',25,'add_projectsourcetype'),(274,'Can change x project source type',25,'change_projectsourcetype'),(275,'Can delete x project source type',25,'delete_projectsourcetype'),(276,'Can view x project source type',25,'view_projectsourcetype'),(277,'Can add x assay tech',20,'add_cdnalibraryprep'),(278,'Can change x assay tech',20,'change_cdnalibraryprep'),(279,'Can delete x assay tech',20,'delete_cdnalibraryprep'),(280,'Can view x assay tech',20,'view_cdnalibraryprep'),(281,'Can add x preservation method',49,'add_preservationmethod'),(282,'Can change x preservation method',49,'change_preservationmethod'),(283,'Can delete x preservation method',49,'delete_preservationmethod'),(284,'Can view x preservation method',49,'view_preservationmethod');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$120000$uK8K79C93rme$pctDiIjzA/wEc1nFgyLJrYo9fTVQ9DC7681VigROkDE=','2019-10-08 19:10:39.926267',1,'Jim','Jim','Kent','jimkent@ucsc.edu',1,1,'2019-08-29 07:03:38.000000'),(2,'pbkdf2_sha256$120000$dCPnY4qguepH$P0sEQmHzul7+zZuPHjcyteoc9cZbGN/oaGEvSat2sLM=','2019-09-18 17:48:11.058104',1,'Clay','Clay','Fischer','clmfisch@ucsc.edu',1,1,'2019-08-29 07:41:45.000000'),(3,'pbkdf2_sha256$120000$sikMTdffLmvR$bKgeuDqEGczG7hfLmw3yILnKPZtOHSIy7cNCIxZ5qdI=','2019-09-16 14:56:41.747772',0,'Max','Maximillian','Haeussler','max@soe.ucsc.edu',1,1,'2019-08-30 02:00:51.000000'),(4,'pbkdf2_sha256$120000$ipbZ7OE5uyeS$wdXE0/ZeGSynplNzsQeoXXEN81H/GLZrVUJumt/F1Lo=','2019-09-24 13:26:52.822628',0,'Paris','Parisa','Nejad','pnejad@ucsc.edu',1,1,'2019-08-30 02:08:24.000000'),(5,'pbkdf2_sha256$120000$EJgsSunurG98$wlVO/H0y9unByPRy0yfjUL9AdJnC2T3QZLnRCEmFO4I=','2019-09-05 06:21:49.000000',0,'Jonah','Jonah','Cool','jcool@chanzuckerberg.com',1,1,'2019-08-30 06:59:38.000000'),(6,'pbkdf2_sha256$120000$doofAEjpTa5J$TGngTPTG3cnRdJ1deaM+sJxC/j1+cwgQvk5puO3XOFw=','2019-09-05 05:45:53.000000',0,'Tim','Timothy','Tickle','',1,1,'2019-09-05 05:43:31.000000'),(7,'pbkdf2_sha256$120000$hJis2XayjlXP$CRYh1t3T7Jbo2IrTjuqlZowcXBbBsmbQsf1I/MaB+9U=','2019-10-07 20:55:01.997995',0,'willrockout','William','Sullivan','wisulliv@ucsc.edu',1,1,'2019-09-05 20:16:00.000000'),(8,'pbkdf2_sha256$120000$EwrbJ0t1tjCc$BTDnbXVcywtt/2F1N03U56luuIMtL8dHT4l+OoeIFXM=','2019-09-24 17:41:03.867946',0,'chris','Christopher','Villarreal','cjvillar@ucsc.edu',1,1,'2019-09-05 20:16:12.000000'),(9,'pbkdf2_sha256$120000$Rx4QXvTUs7mU$4Nl/EZSS264KOgXhZsfu5JCLeklPAQKOIC1Nz2gJLXY=','2019-09-23 20:52:40.741569',0,'markd','','','',1,1,'2019-09-14 22:20:32.000000'),(10,'pbkdf2_sha256$120000$Xzf2dDPw7blB$5fC+A6YGyOdukvISgJQQq+Whm+vjZ/eKyuri0k8sZfo=','2019-10-08 18:44:45.506497',0,'JimWrangler','','','',1,1,'2019-09-26 00:46:10.000000'),(11,'pbkdf2_sha256$120000$qBy0fG8nZpdc$aWytdMkBar8Am+AhIo3eDybspEbFHG6TLmSGjtL7sg0=','2019-10-04 20:58:13.548482',1,'Galt','Galt','Barber','galt@soe.ucsc.edu',1,1,'2019-09-27 18:02:48.000000'),(12,'pbkdf2_sha256$120000$IBmpCSctLJkq$gNwcQhck2VHWcsB7Ha4A5K5QBzEDgo4/L6AZhPNgap8=',NULL,0,'gabs','Galabina','Yordanova','gabs@ebi.ac.uk',1,1,'2019-10-01 21:09:24.000000');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
INSERT INTO `auth_user_groups` VALUES (1,3,1),(2,4,1),(3,5,2),(4,6,3),(5,7,1),(6,8,1),(7,9,3),(8,10,1),(9,11,3),(10,12,1);
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=184 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` VALUES (1,6,41),(2,6,42),(3,6,44),(4,6,32),(5,6,29),(6,6,30),(7,5,33),(8,5,34),(9,5,65),(10,5,36),(11,5,41),(12,5,42),(13,5,44),(14,5,29),(15,5,32),(16,5,66),(17,5,68),(18,5,30),(19,11,4),(20,12,1),(21,12,2),(22,12,3),(23,12,4),(24,12,5),(25,12,6),(26,12,7),(27,12,8),(28,12,9),(29,12,10),(30,12,11),(31,12,12),(32,12,13),(33,12,14),(34,12,15),(35,12,16),(36,12,17),(37,12,18),(38,12,19),(39,12,20),(40,12,21),(41,12,22),(42,12,23),(43,12,24),(44,12,25),(45,12,26),(46,12,27),(47,12,28),(48,12,29),(49,12,30),(50,12,31),(51,12,32),(52,12,33),(53,12,34),(54,12,35),(55,12,36),(56,12,37),(57,12,38),(58,12,39),(59,12,40),(60,12,41),(61,12,42),(62,12,43),(63,12,44),(64,12,45),(65,12,46),(66,12,47),(67,12,48),(68,12,49),(69,12,50),(70,12,51),(71,12,52),(72,12,53),(73,12,54),(74,12,55),(75,12,56),(76,12,57),(77,12,58),(78,12,59),(79,12,60),(80,12,61),(81,12,62),(82,12,63),(83,12,64),(84,12,65),(85,12,66),(86,12,67),(87,12,68),(88,12,69),(89,12,70),(90,12,71),(91,12,72),(92,12,73),(93,12,74),(94,12,75),(95,12,76),(96,12,77),(97,12,78),(98,12,79),(99,12,80),(100,12,81),(101,12,82),(102,12,83),(103,12,84),(104,12,85),(105,12,86),(106,12,87),(107,12,88),(108,12,89),(109,12,90),(110,12,91),(111,12,92),(112,12,93),(113,12,94),(114,12,95),(115,12,96),(116,12,97),(117,12,98),(118,12,99),(119,12,100),(120,12,101),(121,12,102),(122,12,103),(123,12,104),(124,12,105),(125,12,106),(126,12,107),(127,12,108),(128,12,157),(129,12,158),(130,12,159),(131,12,160),(132,12,161),(133,12,162),(134,12,163),(135,12,164),(136,12,165),(137,12,166),(138,12,167),(139,12,168),(140,12,169),(141,12,170),(142,12,171),(143,12,172),(144,12,173),(145,12,174),(146,12,175),(147,12,176),(148,12,233),(149,12,234),(150,12,235),(151,12,236),(152,12,237),(153,12,238),(154,12,239),(155,12,240),(156,12,241),(157,12,242),(158,12,243),(159,12,244),(160,12,245),(161,12,246),(162,12,247),(163,12,248),(164,12,249),(165,12,250),(166,12,251),(167,12,252),(168,12,253),(169,12,254),(170,12,255),(171,12,256),(172,12,257),(173,12,258),(174,12,259),(175,12,260),(176,12,261),(177,12,262),(178,12,263),(179,12,264),(180,12,265),(181,12,266),(182,12,267),(183,12,268);
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=954 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2019-08-29 07:11:21.272601','1','Asa,Kristina,Bjorklund',1,'[{\"added\": {}}]',11,1),(2,'2019-08-29 07:14:10.764319','1','AsaBjorklundLab',1,'[{\"added\": {}}]',8,1),(3,'2019-08-29 07:14:14.719520','1','HumanInnateLymphoidCells',1,'[{\"added\": {}}]',10,1),(4,'2019-08-29 07:16:32.688437','1','MjösbergLabAtUppsala',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',8,1),(5,'2019-08-29 07:17:03.106648','2','Mjösberg,J,M',1,'[{\"added\": {}}]',11,1),(6,'2019-08-29 07:23:18.767377','1','Swedish Research Council',1,'[{\"added\": {}}]',7,1),(7,'2019-08-29 07:24:44.396012','1','SwedishTonsilSingleCell',1,'[{\"added\": {}}]',9,1),(8,'2019-08-29 07:26:53.620299','3','Fischer,Clay,M',1,'[{\"added\": {}}]',11,1),(9,'2019-08-29 07:27:31.992551','4','Kent,W,James',1,'[{\"added\": {}}]',11,1),(10,'2019-08-29 07:27:52.085438','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(11,'2019-08-29 07:35:59.520844','4','Kent,W,James',2,'[{\"changed\": {\"fields\": [\"phone\"]}}]',11,1),(12,'2019-08-29 07:41:45.357366','2','clmfisch',1,'[{\"added\": {}}]',4,1),(13,'2019-08-29 07:42:48.072087','2','clmfisch',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\", \"is_superuser\"]}}]',4,1),(14,'2019-08-29 08:00:46.569361','5','Nejad,Paris',1,'[{\"added\": {}}]',11,1),(15,'2019-08-29 08:01:08.873806','6','Sullivan,William,,',1,'[{\"added\": {}}]',11,1),(16,'2019-08-29 08:01:46.871443','7','Villareal,Chris,,',1,'[{\"added\": {}}]',11,1),(17,'2019-08-29 08:02:54.642592','8','Pollen,Alex,,',1,'[{\"added\": {}}]',11,1),(18,'2019-08-29 08:03:06.340541','8','Pollen,Alex,,',2,'[{\"changed\": {\"fields\": [\"project_role\"]}}]',11,1),(19,'2019-08-29 08:03:21.350856','5','Nejad,Paris,',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(20,'2019-08-29 08:03:36.077986','8','Pollen,Alex,',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(21,'2019-08-29 08:03:42.432809','7','Villareal,Chris,',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(22,'2019-08-29 08:03:49.055477','6','Sullivan,William,',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(23,'2019-08-29 08:04:59.710465','2','NIH',1,'[{\"added\": {}}]',7,1),(24,'2019-08-29 08:05:17.102724','3','CZI',1,'[{\"added\": {}}]',7,1),(25,'2019-08-29 08:05:24.600324','1','SwedishTonsilSingleCell',2,'[]',9,1),(26,'2019-08-29 08:06:19.391240','1','admin',2,'[]',4,1),(27,'2019-08-29 08:06:47.393174','1','admin',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\"]}}]',4,1),(28,'2019-08-29 08:31:08.233416','9','Evangelia,,Diamanti',1,'[{\"added\": {}}]',11,1),(29,'2019-08-29 08:31:54.908364','10','Fiona,,Hamey',1,'[{\"added\": {}}]',11,1),(30,'2019-08-29 08:32:07.723982','11','Dimitris,,Karamitros',1,'[{\"added\": {}}]',11,1),(31,'2019-08-29 08:32:19.566721','12','Bilyana,,Stoilova',1,'[{\"added\": {}}]',11,1),(32,'2019-08-29 08:32:46.839808','13','Lindsey,W,Plasschaert',1,'[{\"added\": {}}]',11,1),(33,'2019-08-29 08:33:09.772948','14','Rapolas,,Zilionis',1,'[{\"added\": {}}]',11,1),(34,'2019-08-29 08:33:21.448108','15','Rayman,,Choo-Wing',1,'[{\"added\": {}}]',11,1),(35,'2019-08-29 08:33:30.091442','16','Virginia,,Savova',1,'[{\"added\": {}}]',11,1),(36,'2019-08-29 08:33:42.179825','17','Judith,,Knehr',1,'[{\"added\": {}}]',11,1),(37,'2019-08-29 08:33:48.998428','18','Guglielmo,,Roma',1,'[{\"added\": {}}]',11,1),(38,'2019-08-29 08:33:58.150335','19','Allon,M,Klein',1,'[{\"added\": {}}]',11,1),(39,'2019-08-29 08:34:07.471984','20','Aron,B,Jaffe',1,'[{\"added\": {}}]',11,1),(40,'2019-08-29 08:34:47.211259','21','Simone,,Picelli',1,'[{\"added\": {}}]',11,1),(41,'2019-08-29 08:35:04.585698','22','Marianne,,Forkel',1,'[{\"added\": {}}]',11,1),(42,'2019-08-29 08:35:21.908300','23','Rickard,,Sandberg',1,'[{\"added\": {}}]',11,1),(43,'2019-08-29 08:35:46.372569','9','Evangelia,,Diamanti',2,'[{\"changed\": {\"fields\": [\"project_role\"]}}]',11,1),(44,'2019-08-29 08:37:42.414702','1','MjösbergLabAtUppsala',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',8,1),(45,'2019-08-29 08:38:54.959620','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(46,'2019-08-29 08:57:23.656634','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"wrangler\"]}}]',10,1),(47,'2019-08-29 09:00:30.257438','24','Spyros,,Darmanis',1,'[{\"added\": {}}]',11,1),(48,'2019-08-29 09:00:56.942745','25','Stephen,R,Quake',1,'[{\"added\": {}}]',11,1),(49,'2019-08-29 09:02:08.523064','2','CziBioHub',1,'[{\"added\": {}}]',8,1),(50,'2019-08-29 09:02:12.140953','2','TabulaMuris',1,'[{\"added\": {}}]',10,1),(51,'2019-08-29 09:02:21.590148','2','TabulaMuris',2,'[]',10,1),(52,'2019-08-29 09:02:48.367706','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(53,'2019-08-29 09:08:10.281529','2','TabulaMuris',2,'[]',10,1),(54,'2019-08-29 09:22:42.995656','4','MRC',1,'[{\"added\": {}}]',7,1),(55,'2019-08-29 09:23:35.818228','5','Gates',1,'[{\"added\": {}}]',7,1),(56,'2019-08-29 09:29:44.082249','6','anonymous',1,'[{\"added\": {}}]',7,1),(57,'2019-08-29 09:29:50.616441','2','anonymous gift',1,'[{\"added\": {}}]',9,1),(58,'2019-08-29 09:38:43.960375','2','anonymous gift',2,'[{\"changed\": {\"fields\": [\"funded_contributors\"]}}]',9,1),(59,'2019-08-29 09:39:21.242350','2','anonymous gift',2,'[{\"changed\": {\"fields\": [\"funded_projects\", \"funded_labs\", \"funded_contributors\"]}}]',9,1),(60,'2019-08-29 09:42:07.304038','24','Spyros,,Darmanis',2,'[{\"changed\": {\"fields\": [\"project_role\"]}}]',11,1),(61,'2019-08-29 09:46:36.394878','1','HumanInnateLymphoidCells',2,'[]',10,1),(62,'2019-08-29 09:47:22.110017','1','HumanInnateLymphoidCells',2,'[]',10,1),(63,'2019-08-29 14:16:34.877435','26','Daniel,T,Montoro',1,'[{\"added\": {}}]',11,1),(64,'2019-08-29 14:22:59.614716','7','Chris,,Villareal',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(65,'2019-08-29 14:23:17.315092','6','William,,Sullivan',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(66,'2019-08-29 14:23:31.322280','5','Paris,,Nejad',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(67,'2019-08-29 14:23:49.580323','4','W,Jim,Kent',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(68,'2019-08-29 14:24:05.327433','3','Clay,M,Fischer',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(69,'2019-08-29 14:24:24.787345','8','Alex,,Pollen',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(70,'2019-08-29 14:25:40.661499','27','Adam,L,Haber',1,'[{\"added\": {}}]',11,1),(71,'2019-08-29 14:25:57.727978','28','Moshe,,Biton',1,'[{\"added\": {}}]',11,1),(72,'2019-08-29 14:26:07.471983','29','Vladimir,,Vinarsky',1,'[{\"added\": {}}]',11,1),(73,'2019-08-29 14:26:16.237155','30','Sijia,,Chen',1,'[{\"added\": {}}]',11,1),(74,'2019-08-29 14:26:26.794393','31','Jorge,,Villoria',1,'[{\"added\": {}}]',11,1),(75,'2019-08-29 14:26:38.365435','32','Noga,,Rogel',1,'[{\"added\": {}}]',11,1),(76,'2019-08-29 14:26:46.309073','33','Purushothama,,Rao Tata',1,'[{\"added\": {}}]',11,1),(77,'2019-08-29 14:26:53.889458','34','Steven,M,Rowe',1,'[{\"added\": {}}]',11,1),(78,'2019-08-29 14:27:01.148755','35','John,F,Engelhardt',1,'[{\"added\": {}}]',11,1),(79,'2019-08-29 14:27:05.018741','36','John,F,Engelhardt',1,'[{\"added\": {}}]',11,1),(80,'2019-08-29 14:27:17.870436','36','John,F,Engelhardt',3,'',11,1),(81,'2019-08-29 14:27:47.571364','37','Aviv,,Regev',1,'[{\"added\": {}}]',11,1),(82,'2019-08-29 14:28:00.673914','38','Jayaraj,,Rajagopal',1,'[{\"added\": {}}]',11,1),(83,'2019-08-29 14:28:07.423696','39','Brian,,Lin',1,'[{\"added\": {}}]',11,1),(84,'2019-08-29 14:28:13.983678','40','Susan,,Birket',1,'[{\"added\": {}}]',11,1),(85,'2019-08-29 14:28:30.504888','41','Feng,,Yuan',1,'[{\"added\": {}}]',11,1),(86,'2019-08-29 14:28:38.305613','42','Hui Min,,Leung',1,'[{\"added\": {}}]',11,1),(87,'2019-08-29 14:28:44.619897','43','Grace,,Burgin',1,'[{\"added\": {}}]',11,1),(88,'2019-08-29 14:28:50.648637','44','Alexander,,Tsankov',1,'[{\"added\": {}}]',11,1),(89,'2019-08-29 14:29:08.559552','45','Avinash,,Waghray',1,'[{\"added\": {}}]',11,1),(90,'2019-08-29 14:29:14.940600','46','Michal,,Slyper',1,'[{\"added\": {}}]',11,1),(91,'2019-08-29 14:29:20.385621','47','Julia,,Waldman',1,'[{\"added\": {}}]',11,1),(92,'2019-08-29 14:29:26.478376','48','Lan,,Nguyen',1,'[{\"added\": {}}]',11,1),(93,'2019-08-29 14:29:32.508308','49','Danielle,,Dionne',1,'[{\"added\": {}}]',11,1),(94,'2019-08-29 14:29:40.292479','50','Orit,,Rozenblatt-Rosen',1,'[{\"added\": {}}]',11,1),(95,'2019-08-29 14:29:46.618176','51','Hongmei,,Mou',1,'[{\"added\": {}}]',11,1),(96,'2019-08-29 14:29:53.169711','52','Manjunatha,,Shivaraju',1,'[{\"added\": {}}]',11,1),(97,'2019-08-29 14:29:59.328631','53','Herman,,Bihler',1,'[{\"added\": {}}]',11,1),(98,'2019-08-29 14:30:05.618150','54','Martin,,Mense',1,'[{\"added\": {}}]',11,1),(99,'2019-08-29 14:30:13.413734','55','Guillermo,,Tearney',1,'[{\"added\": {}}]',11,1),(100,'2019-08-29 14:37:17.965521','3','RevisedAirwayEpithelialHierarchy',1,'[{\"added\": {}}]',10,1),(101,'2019-08-29 17:19:15.008081','3','kent',1,'[{\"added\": {}}]',8,2),(102,'2019-08-29 17:19:31.560404','4','clayPancreaticCells1',1,'[{\"added\": {}}]',10,2),(103,'2019-08-29 18:42:46.531132','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"wrangler2\"]}}]',10,1),(104,'2019-08-29 18:49:41.254691','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"wrangler2\"]}}]',10,1),(105,'2019-08-29 18:57:44.032862','3','kent',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',8,1),(106,'2019-08-29 19:05:31.018610','3','kent',2,'[{\"changed\": {\"fields\": [\"contact\", \"pi\"]}}]',8,1),(107,'2019-08-29 19:05:53.833782','2','CziBioHub',2,'[{\"changed\": {\"fields\": [\"contact\", \"pi\"]}}]',8,1),(108,'2019-08-29 19:06:05.367181','1','MjösbergLabAtUppsala',2,'[{\"changed\": {\"fields\": [\"contact\", \"pi\"]}}]',8,1),(109,'2019-08-29 19:21:50.519104','1','Potential',1,'[{\"added\": {}}]',12,1),(110,'2019-08-29 19:22:28.607361','2','Unsuitable',1,'[{\"added\": {}}]',12,1),(111,'2019-08-29 19:23:00.366984','2','unsuitable',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(112,'2019-08-29 19:23:11.838498','1','potential',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(113,'2019-08-29 19:23:36.563060','3','stalled',1,'[{\"added\": {}}]',12,1),(114,'2019-08-29 19:24:50.601369','4','wrangling-active',1,'[{\"added\": {}}]',12,1),(115,'2019-08-29 19:25:47.097096','5','wrangling-review',1,'[{\"added\": {}}]',12,1),(116,'2019-08-29 19:26:51.530208','6','wrangling-finished',1,'[{\"added\": {}}]',12,1),(117,'2019-08-29 19:27:18.435829','7','submitted',1,'[{\"added\": {}}]',12,1),(118,'2019-08-29 19:28:00.967242','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"status\"]}}]',10,1),(119,'2019-08-29 19:30:02.538247','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"status\", \"wrangler2\"]}}]',10,1),(120,'2019-08-29 19:30:36.600921','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"status\", \"wrangler2\"]}}]',10,1),(121,'2019-08-29 19:31:08.808968','1','HumanInnateLymphoidCells',2,'[]',10,1),(122,'2019-08-29 19:31:28.537647','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"status\"]}}]',10,1),(123,'2019-08-29 20:12:14.306521','2','TabulaMuris',2,'[]',10,1),(124,'2019-08-29 20:12:48.413861','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"priority\"]}}]',10,1),(125,'2019-08-29 20:33:38.809839','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"priority\"]}}]',10,1),(126,'2019-08-29 20:33:51.118457','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',10,1),(127,'2019-08-29 20:37:54.165410','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',10,1),(128,'2019-08-29 21:03:35.076744','1','Already openly published',1,'[{\"added\": {}}]',15,1),(129,'2019-08-29 21:04:59.472664','1','Obstructive sleep apnea',1,'[{\"added\": {}}]',17,1),(130,'2019-08-29 21:06:01.993694','1','Healthy tonsils from apnea patients',1,'[{\"added\": {}}]',14,1),(131,'2019-08-29 21:06:39.253212','1','Species object (1)',1,'[{\"added\": {}}]',16,1),(132,'2019-08-29 21:07:58.502334','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"species\", \"body_part\", \"disease\", \"concent\"]}}]',10,1),(133,'2019-08-29 21:13:27.001815','2','mouse',1,'[{\"added\": {}}]',16,1),(134,'2019-08-29 21:14:14.905486','2','Normal',1,'[{\"added\": {}}]',17,1),(135,'2019-08-29 21:15:15.918701','2','nonhuman data',1,'[{\"added\": {}}]',15,1),(136,'2019-08-29 21:21:08.906195','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"species\"]}}]',10,1),(137,'2019-08-29 21:21:19.501191','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"disease\", \"concent\"]}}]',10,1),(138,'2019-08-29 21:21:43.934766','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"species\"]}}]',10,1),(139,'2019-08-29 21:22:21.236047','1','tonsil',1,'[{\"added\": {}}]',18,1),(140,'2019-08-29 21:23:28.848428','2','lung',1,'[{\"added\": {}}]',18,1),(141,'2019-08-29 21:24:00.303918','2','lung airway epithelium',1,'[{\"added\": {}}]',14,1),(142,'2019-08-29 21:24:29.023624','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"species\", \"organ\", \"organ_part\", \"disease\", \"concent\"]}}]',10,1),(143,'2019-08-29 21:25:05.287167','3','Full body',1,'[{\"added\": {}}]',14,1),(144,'2019-08-29 21:25:25.134023','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"disease\"]}}]',10,1),(145,'2019-08-29 21:25:44.592870','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"organ_part\"]}}]',10,1),(146,'2019-08-29 21:26:15.025718','3','full body',1,'[{\"added\": {}}]',18,1),(147,'2019-08-29 21:26:26.460212','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"organ\"]}}]',10,1),(148,'2019-08-29 21:26:41.325071','3','full body',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',14,1),(149,'2019-08-29 21:26:48.068862','1','healthy tonsils from apnea patients',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',14,1),(150,'2019-08-29 21:27:53.047442','4','pancreas',1,'[{\"added\": {}}]',18,1),(151,'2019-08-29 21:28:04.665283','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"organ\"]}}]',10,1),(152,'2019-08-29 22:07:45.173112','1','Primary tissue',1,'[{\"added\": {}}]',19,1),(153,'2019-08-29 22:08:49.723452','2','standard cell line',1,'[{\"added\": {}}]',19,1),(154,'2019-08-29 22:09:01.065173','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"cell_culture\"]}}]',10,1),(155,'2019-08-29 22:09:59.058104','1','fresh sample',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',19,1),(156,'2019-08-29 22:10:31.950551','3','iPSC',1,'[{\"added\": {}}]',19,1),(157,'2019-08-29 22:11:13.151433','4','organoid',1,'[{\"added\": {}}]',19,1),(158,'2019-08-29 22:11:44.414054','5','cancer',1,'[{\"added\": {}}]',19,1),(159,'2019-08-29 22:12:16.767975','6','frozen sample',1,'[{\"added\": {}}]',19,1),(160,'2019-08-29 22:13:26.550684','7','primary cell line',1,'[{\"added\": {}}]',19,1),(161,'2019-08-29 22:14:10.896565','8','immortalized cell line',1,'[{\"added\": {}}]',19,1),(162,'2019-08-29 22:21:09.780855','3','consented',1,'[{\"added\": {}}]',15,2),(163,'2019-08-29 22:21:41.875634','5','kidney',1,'[{\"added\": {}}]',18,2),(164,'2019-08-29 22:21:59.988246','4','cortex',1,'[{\"added\": {}}]',14,2),(165,'2019-08-29 22:22:07.963698','5','humphreysKidneyOrganoids1',1,'[{\"added\": {}}]',10,2),(166,'2019-08-29 22:22:09.414685','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',10,1),(167,'2019-08-29 23:55:06.339172','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"sample_type\"]}}]',10,1),(168,'2019-08-29 23:55:37.272223','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"sample_type\"]}}]',10,1),(169,'2019-08-29 23:56:46.162557','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"sample_type\"]}}]',10,1),(170,'2019-08-29 23:59:01.904539','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"organ_part\"]}}]',10,1),(171,'2019-08-29 23:59:15.704560','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"organ_part\"]}}]',10,1),(172,'2019-08-30 00:14:55.481875','1','RNA levels',1,'[{\"added\": {}}]',21,1),(173,'2019-08-30 00:15:58.742770','1','10x Chromium V2',1,'[{\"added\": {}}]',20,1),(174,'2019-08-30 00:17:06.311914','2','smart-seq2 PE',1,'[{\"added\": {}}]',20,1),(175,'2019-08-30 00:17:31.873625','3','smart-seq2 SE',1,'[{\"added\": {}}]',20,1),(176,'2019-08-30 00:18:13.401301','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"assay_tech\", \"cells_expected\"]}}]',10,1),(177,'2019-08-30 00:19:51.797465','2','Open Chromatin',1,'[{\"added\": {}}]',21,1),(178,'2019-08-30 00:20:47.991345','4','bulk RNA',1,'[{\"added\": {}}]',20,1),(179,'2019-08-30 00:22:15.888158','5','SS-ATAC-seq',1,'[{\"added\": {}}]',20,1),(180,'2019-08-30 00:22:38.290213','3','smart-seq2 SE',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',20,1),(181,'2019-08-30 00:22:59.001182','2','smart-seq2 PE',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',20,1),(182,'2019-08-30 00:23:51.310205','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"assay_tech\", \"cells_expected\"]}}]',10,1),(183,'2019-08-30 00:58:27.301194','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"cells_expected\"]}}]',10,1),(184,'2019-08-30 00:58:46.015057','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"cells_expected\"]}}]',10,1),(185,'2019-08-30 01:11:15.110629','1','innate immune cells from three tonsil donors',1,'[{\"added\": {}}]',22,1),(186,'2019-08-30 01:12:23.983385','1','pmid: 26878113',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',22,1),(187,'2019-08-30 01:13:15.595263','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(188,'2019-08-30 01:14:39.064703','1','already openly published',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',15,1),(189,'2019-08-30 01:15:44.608617','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"sample_type\", \"organ\"]}}]',10,1),(190,'2019-08-30 02:00:51.789305','3','Max',1,'[{\"added\": {}}]',4,1),(191,'2019-08-30 02:03:07.232734','3','Max',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\"]}}]',4,1),(192,'2019-08-30 02:06:04.447471','1','wranglers',1,'[{\"added\": {}}]',3,1),(193,'2019-08-30 02:06:37.635250','3','Max',2,'[{\"changed\": {\"fields\": [\"groups\"]}}]',4,1),(194,'2019-08-30 02:07:31.210281','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(195,'2019-08-30 02:08:24.967746','4','Paris',1,'[{\"added\": {}}]',4,3),(196,'2019-08-30 02:09:19.423384','4','Paris',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\", \"is_superuser\", \"groups\"]}}]',4,3),(197,'2019-08-30 02:09:34.128326','4','Paris',2,'[{\"changed\": {\"fields\": [\"is_superuser\"]}}]',4,3),(198,'2019-08-30 02:25:00.187287','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(199,'2019-08-30 03:57:24.499533','6','brain',1,'[{\"added\": {}}]',18,1),(200,'2019-08-30 04:02:47.281066','3','metagenomics',1,'[{\"added\": {}}]',21,1),(201,'2019-08-30 04:04:30.425631','6','bulk DNA',1,'[{\"added\": {}}]',20,1),(202,'2019-08-30 04:04:40.089845','6','NewChewingGum2',1,'[{\"added\": {}}]',10,1),(203,'2019-08-30 04:05:38.321754','4','clayPancreaticCells1',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"assay_tech\"]}}]',10,1),(204,'2019-08-30 04:06:44.203326','3','metagenomics',3,'',21,1),(205,'2019-08-30 04:08:04.243448','6','NewChewingGum2',3,'',10,1),(206,'2019-08-30 04:09:43.004902','4','clayPancreaticCells1',3,'',10,1),(207,'2019-08-30 04:35:28.156884','2','Open Chromatin',2,'[]',21,1),(208,'2019-08-30 04:49:13.516476','5','whole organ',1,'[{\"added\": {}}]',14,1),(209,'2019-08-30 04:51:19.613533','4','dubious',1,'[{\"added\": {}}]',15,1),(210,'2019-08-30 05:03:24.788814','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(211,'2019-08-30 05:23:58.937981','4','histone modification',1,'[{\"added\": {}}]',21,1),(212,'2019-08-30 05:24:14.142629','2','open chromatin',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',21,1),(213,'2019-08-30 05:27:35.938798','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"consent\"]}}]',10,1),(214,'2019-08-30 05:52:48.549006','7','jk test 3',1,'[{\"added\": {}}]',10,1),(215,'2019-08-30 05:53:27.089930','3','full body',3,'',14,1),(216,'2019-08-30 05:53:35.755089','5','whole',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',14,1),(217,'2019-08-30 05:53:56.594049','4','kidney cortex',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',14,1),(218,'2019-08-30 06:19:11.846266','5','scATAC-seq',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',20,1),(219,'2019-08-30 06:31:16.327272','3','type 2 diabetes',1,'[{\"added\": {}}]',17,1),(220,'2019-08-30 06:32:27.267511','4','cardiovascular disease',1,'[{\"added\": {}}]',17,1),(221,'2019-08-30 06:32:49.041773','7','jk test 3',2,'[{\"changed\": {\"fields\": [\"organ_part\", \"disease\"]}}]',10,1),(222,'2019-08-30 06:33:11.695221','2','normal',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',17,1),(223,'2019-08-30 06:33:18.390205','1','obstructive sleep apnea',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',17,1),(224,'2019-08-30 06:37:59.382114','5','parkinsons',1,'[{\"added\": {}}]',17,1),(225,'2019-08-30 06:56:58.091007','2','readers',1,'[{\"added\": {}}]',3,1),(226,'2019-08-30 06:59:38.681570','5','Jonah',1,'[{\"added\": {}}]',4,1),(227,'2019-08-30 07:00:57.223552','5','Jonah',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\", \"groups\"]}}]',4,1),(228,'2019-08-30 07:02:18.280171','5','Jonah',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,1),(229,'2019-08-30 07:02:46.373454','5','Jonah',2,'[]',4,1),(230,'2019-08-30 07:23:04.014803','7','jk test 3',2,'[{\"changed\": {\"fields\": [\"species\"]}}]',10,1),(231,'2019-08-30 07:39:02.909254','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(232,'2019-08-30 07:41:10.497806','56','Maximillian,,Haeussler',1,'[{\"added\": {}}]',11,1),(233,'2019-08-30 07:41:35.295277','7','jk test 3',2,'[{\"changed\": {\"fields\": [\"wrangler2\"]}}]',10,1),(234,'2019-08-30 07:43:59.974148','7','jk test 3',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(235,'2019-08-30 07:48:51.067408','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(236,'2019-08-30 07:50:58.375886','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(237,'2019-08-30 07:53:36.008297','1','fresh sample',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',19,1),(238,'2019-08-30 07:59:25.351060','4','dubious',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',15,1),(239,'2019-08-30 14:43:31.217784','1','note',1,'[{\"added\": {}}]',23,1),(240,'2019-08-30 14:44:00.302986','2','wtf',1,'[{\"added\": {}}]',23,1),(241,'2019-08-30 14:44:43.174922','3','warning',1,'[{\"added\": {}}]',23,1),(242,'2019-08-30 14:45:11.047732','4','error',1,'[{\"added\": {}}]',23,1),(243,'2019-08-30 14:45:37.070207','5','yay',1,'[{\"added\": {}}]',23,1),(244,'2019-08-30 14:46:04.273118','6','sad',1,'[{\"added\": {}}]',23,1),(245,'2019-08-30 14:46:14.983529','5','glad',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',23,1),(246,'2019-08-30 14:46:31.570790','7','mad',1,'[{\"added\": {}}]',23,1),(247,'2019-08-30 14:58:18.652153','3','COMMENT: Jim, what is going o',1,'[{\"added\": {}}]',24,1),(248,'2019-08-30 15:03:19.464331','4','This is going away soon',1,'[{\"added\": {}}]',24,1),(249,'2019-08-30 15:06:22.875761','3','warn',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',23,1),(250,'2019-08-30 15:06:31.995235','4','bug',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',23,1),(251,'2019-08-30 15:11:14.771378','7','jk test 3',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',10,1),(252,'2019-08-30 15:11:42.744225','5','warn: Test set in real database?',1,'[{\"added\": {}}]',24,1),(253,'2019-08-30 15:13:15.961266','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',10,1),(254,'2019-08-30 15:13:52.170442','6','wtf: So if any piece breaks we all stop work?',1,'[{\"added\": {}}]',24,1),(255,'2019-08-30 17:28:46.748351','7','note: on vacatoin',1,'[{\"added\": {}}]',24,1),(256,'2019-08-30 17:29:20.579519','7','note: on vacation',2,'[{\"changed\": {\"fields\": [\"text\"]}}]',24,1),(257,'2019-08-30 17:29:42.722370','56','Maximillian,,Haeussler',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',11,1),(258,'2019-08-30 17:30:11.786603','8','warn: Does not know role as lab contact yet',1,'[{\"added\": {}}]',24,1),(259,'2019-08-30 17:30:15.272529','8','Alex,,Pollen',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',11,1),(260,'2019-08-30 17:56:48.296950','9','glad: It works!',1,'[{\"added\": {}}]',24,1),(261,'2019-08-30 17:57:03.198177','4','W,Jim,Kent',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',11,1),(262,'2019-08-30 17:57:49.127701','10','sad: They got mad at me',1,'[{\"added\": {}}]',24,1),(263,'2019-08-30 18:06:44.029420','11','glad: very patient',1,'[{\"added\": {}}]',24,1),(264,'2019-08-30 18:13:05.178427','2','anonymous gift',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',9,1),(265,'2019-08-30 18:13:59.683783','12','warn: faked grant id',1,'[{\"added\": {}}]',24,1),(266,'2019-08-30 18:14:26.717330','1','SwedishTonsilSingleCell',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',9,1),(267,'2019-08-30 18:15:29.091142','13','note: Would need more detail if anybody cared',1,'[{\"added\": {}}]',24,1),(268,'2019-08-30 18:15:34.169187','6','bulk DNA',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',20,1),(269,'2019-08-30 18:15:47.162103','6','bulk DNA',2,'[]',20,1),(270,'2019-08-30 18:16:11.276156','4','bulk RNA',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',20,1),(271,'2019-08-30 18:20:35.418628','4','bulk RNA',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',20,1),(272,'2019-08-30 18:20:45.772228','5','scATAC-seq',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',20,1),(273,'2019-08-30 18:42:18.109445','3','Clay,M,Fischer',2,'[{\"changed\": {\"fields\": [\"projects\"]}}]',11,1),(274,'2019-08-30 18:43:07.780719','56','Maximillian,,Haeussler',2,'[]',11,1),(275,'2019-08-30 18:43:45.370237','7','jk test 3',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(276,'2019-08-30 18:50:53.861650','3','HCA-DCP UC Santa Cruz',1,'[{\"added\": {}}]',9,1),(277,'2019-08-30 18:51:43.896236','3','HCA-DCP UC Santa Cruz',2,'[{\"changed\": {\"fields\": [\"funded_labs\"]}}]',9,1),(278,'2019-08-30 18:52:32.801248','4','W,Jim,Kent',2,'[]',11,1),(279,'2019-08-30 19:21:31.406498','1','SwedishTonsilSingleCell',3,'',9,1),(280,'2019-08-30 19:21:59.507696','7','jk test 3',3,'',10,1),(281,'2019-08-30 19:26:45.653309','6','kidney organoid',1,'[{\"added\": {}}]',14,1),(282,'2019-08-30 19:27:26.928887','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"consent\", \"stars\", \"wrangler2\", \"organ\", \"organ_part\", \"disease\"]}}]',10,1),(283,'2019-08-30 19:28:29.517408','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"state\", \"wrangler2\"]}}]',10,1),(284,'2019-08-30 19:29:28.974933','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"wrangler2\", \"assay_tech\"]}}]',10,1),(285,'2019-08-30 19:43:16.361015','1','import GEO',1,'[{\"added\": {}}]',25,1),(286,'2019-08-30 19:44:45.829775','2','HCA live wrangling',1,'[{\"added\": {}}]',25,1),(287,'2019-08-30 19:47:18.218526','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"origin\"]}}]',10,1),(288,'2019-08-30 19:47:41.304939','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"origin\"]}}]',10,1),(289,'2019-08-30 19:48:00.795345','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"origin\"]}}]',10,1),(290,'2019-08-30 19:48:27.421118','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"origin\"]}}]',10,1),(291,'2019-08-30 21:29:31.077369','7','on vacation',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',24,1),(292,'2019-08-30 21:34:40.719181','14','Split EBI vs UCSC?',1,'[{\"added\": {}}]',24,1),(293,'2019-08-30 23:45:02.240303','1','UCSC Genome Browser',1,'[{\"added\": {}}]',27,1),(294,'2019-08-30 23:47:27.272339','1','Full empty template for v6 metadata',1,'[{\"added\": {}}]',26,1),(295,'2019-08-30 23:50:31.604055','3','HCA-DCP UC Santa Cruz',2,'[{\"changed\": {\"fields\": [\"grant_id\"]}}]',9,1),(296,'2019-08-31 00:50:32.530525','15','from GSE103354',1,'[{\"added\": {}}]',24,1),(297,'2019-08-31 00:50:40.119464','2','Revised Airway Epithelial Hierarchy',1,'[{\"added\": {}}]',22,1),(298,'2019-08-31 00:53:53.648381','2','1st pass excel for GSE103354',1,'[{\"added\": {}}]',26,1),(299,'2019-08-31 00:58:15.937532','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"metadataExcel\"]}}]',10,1),(300,'2019-08-31 01:00:45.961596','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(301,'2019-08-31 01:31:13.616475','1','UCSC Genome Browser',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',27,1),(302,'2019-08-31 01:32:04.867762','16','This could be simplified',1,'[{\"added\": {}}]',24,1),(303,'2019-08-31 01:32:52.316222','2','1st pass excel for GSE103354',3,'',26,1),(304,'2019-08-31 01:35:37.389594','1','Full empty template for v6 metadata',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',26,1),(305,'2019-08-31 01:40:56.345801','16','This could be simplified',2,'[]',24,1),(306,'2019-08-31 01:42:09.666921','17','Wish I didn\'t have to do this',1,'[{\"added\": {}}]',24,1),(307,'2019-08-31 05:07:24.680401','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(308,'2019-08-31 05:08:35.487434','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(309,'2019-08-31 06:21:11.200544','2','live wrangling',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',25,1),(310,'2019-08-31 06:42:46.016041','5','unconsented',1,'[{\"added\": {}}]',15,1),(311,'2019-08-31 06:51:05.810490','6','kidney organoid',2,'[]',14,1),(312,'2019-08-31 15:28:36.496945','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"staging_area\"]}}]',10,1),(313,'2019-08-31 15:28:49.479729','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"staging_area\"]}}]',10,1),(314,'2019-08-31 16:25:11.084412','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(315,'2019-08-31 16:27:10.194694','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(316,'2019-08-31 16:28:15.370254','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(317,'2019-08-31 17:09:17.694625','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab\"]}}]',10,1),(318,'2019-08-31 17:11:13.330142','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab\"]}}]',10,1),(319,'2019-08-31 18:47:17.832314','6','staged',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(320,'2019-08-31 18:47:40.730050','6','staged',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',12,1),(321,'2019-08-31 18:48:30.185400','5','review',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(322,'2019-08-31 18:48:38.896104','4','wrangling',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(323,'2019-08-31 18:49:01.588223','3','stalled',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',12,1),(324,'2019-08-31 18:57:43.862170','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"wrangler1\", \"wrangler2\"]}}]',10,1),(325,'2019-08-31 19:10:17.958692','8','jk test 4',1,'[{\"added\": {}}]',10,1),(326,'2019-08-31 19:35:01.130568','8','jk test 4',2,'[{\"changed\": {\"fields\": [\"first_contact_date\", \"last_contact_date\"]}}]',10,1),(327,'2019-08-31 21:19:12.553132','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"submit_comments\"]}}]',10,1),(328,'2019-08-31 21:47:22.548456','8','ingested',1,'[{\"added\": {}}]',12,1),(329,'2019-08-31 21:48:34.120229','9','analysis',1,'[{\"added\": {}}]',12,1),(330,'2019-08-31 21:51:58.111341','9','primary analysis',2,'[{\"changed\": {\"fields\": [\"state\", \"description\"]}}]',12,1),(331,'2019-08-31 21:53:51.956023','10','cell matrix',1,'[{\"added\": {}}]',12,1),(332,'2019-08-31 21:55:42.888361','11','cell clusters',1,'[{\"added\": {}}]',12,1),(333,'2019-08-31 21:56:29.774289','12','Cell types',1,'[{\"added\": {}}]',12,1),(334,'2019-08-31 21:56:47.835323','12','cell types',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(335,'2019-08-31 21:58:20.990126','13','integrated analysis',1,'[{\"added\": {}}]',12,1),(336,'2019-08-31 22:03:23.296189','1','suitable',2,'[{\"changed\": {\"fields\": [\"state\"]}}]',12,1),(337,'2019-08-31 22:11:10.435282','8','jk test 4',2,'[{\"changed\": {\"fields\": [\"state\", \"cells_expected\"]}}]',10,1),(338,'2019-08-31 22:18:53.412455','7','liver',1,'[{\"added\": {}}]',18,1),(339,'2019-08-31 22:20:55.501692','6','hepatic steatosis',1,'[{\"added\": {}}]',17,1),(340,'2019-08-31 22:22:47.969149','8','jk test 4',2,'[{\"changed\": {\"fields\": [\"species\", \"sample_type\", \"organ\", \"organ_part\", \"disease\", \"contributors\"]}}]',10,1),(341,'2019-08-31 22:44:41.402111','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"consent\", \"contributors\"]}}]',10,1),(342,'2019-08-31 23:22:44.811203','8','jk test 4',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(343,'2019-08-31 23:23:20.619748','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"cur_state\"]}}]',10,1),(344,'2019-08-31 23:24:00.370782','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"cur_state\"]}}]',10,1),(345,'2019-08-31 23:25:07.718701','18','Isn\'t there more to this data set?',1,'[{\"added\": {}}]',24,1),(346,'2019-08-31 23:25:32.609128','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"cur_state\", \"comments\"]}}]',10,1),(347,'2019-08-31 23:25:50.585426','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(348,'2019-08-31 23:26:09.900801','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"cur_state\"]}}]',10,1),(349,'2019-09-01 00:31:04.688175','9','xenograft',1,'[{\"added\": {}}]',19,1),(350,'2019-09-01 00:32:38.559752','2','healthy',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',17,1),(351,'2019-09-01 00:37:27.660727','8','jk test 4',2,'[{\"changed\": {\"fields\": [\"wrangler2\"]}}]',10,1),(352,'2019-09-01 00:38:32.229345','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',10,1),(353,'2019-09-01 03:42:54.740405','2','pmid 30069044',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',22,1),(354,'2019-09-01 03:43:03.952409','2','pmid: 30069044',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',22,1),(355,'2019-09-02 22:20:25.621860','9','HumanLymphoMyeloidProgenitorCells',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab\"]}}]',10,1),(356,'2019-09-02 22:22:07.975673','9','HumanLymphoMyeloidProgenitorCells',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab\", \"sheet_from_lab_date\"]}}]',10,1),(357,'2019-09-02 22:24:36.973097','8','umbilical cord',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(358,'2019-09-02 22:25:24.837850','7','cord blood',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',14,1),(359,'2019-09-03 00:48:46.050804','9','HumanLymphoMyeloidProgenitorCells',2,'[{\"changed\": {\"fields\": [\"cur_state\"]}}]',10,1),(360,'2019-09-03 16:36:48.718951','9','Evangelia,,Diamanti',2,'[{\"changed\": {\"fields\": [\"project_role\"]}}]',11,1),(361,'2019-09-03 17:22:46.488875','9','Evangelia,,Diamanti',2,'[]',11,1),(362,'2019-09-03 17:23:29.976797','24','Spyros,,Darmanis',2,'[]',11,1),(363,'2019-09-03 17:30:24.496438','9','HumanLymphoMyeloidProgenitorCells',3,'',10,1),(364,'2019-09-03 17:31:01.953034','9','Evangelia,,Diamanti',3,'',11,1),(365,'2019-09-03 17:33:31.431015','57','Evangelia,,Diamanti',3,'',11,1),(366,'2019-09-03 17:33:47.605084','4','Gottgens University of Cambridge',3,'',8,1),(367,'2019-09-03 17:34:37.861120','10','HumanLymphoMyeloidProgenitorCells',3,'',10,1),(368,'2019-09-03 19:43:06.387781','12','Diabetic Nephropathy snRNA-seq',1,'[{\"added\": {}}]',10,4),(369,'2019-09-03 21:09:40.627531','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(370,'2019-09-04 19:44:31.533710','8','jk test 4',3,'',10,1),(371,'2019-09-04 21:23:48.666894','59','The,Great,Snark',1,'[{\"added\": {}}]',11,1),(372,'2019-09-04 21:23:51.257210','6','The snark lab east',1,'[{\"added\": {}}]',8,1),(373,'2019-09-04 22:40:44.635671','4','W,Jim,Kent',2,'[{\"changed\": {\"fields\": [\"comments\"]}}]',11,1),(374,'2019-09-04 23:43:12.862304','1','lab contact',1,'[{\"added\": {}}]',42,1),(375,'2019-09-04 23:43:21.205214','59','The,Great,Snark',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(376,'2019-09-04 23:47:23.093047','2','wrangler',1,'[{\"added\": {}}]',42,1),(377,'2019-09-04 23:50:09.821102','2','wrangler',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',42,1),(378,'2019-09-04 23:54:04.541355','2','wrangler',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',42,1),(379,'2019-09-04 23:54:37.926510','2','wrangler',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',42,1),(380,'2019-09-04 23:56:51.307262','3','contributor',1,'[{\"added\": {}}]',42,1),(381,'2019-09-04 23:57:12.369470','3','contributor',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',42,1),(382,'2019-09-04 23:57:33.394936','2','wrangler',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',42,1),(383,'2019-09-04 23:57:53.479887','2','wrangler',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',42,1),(384,'2019-09-05 00:02:42.144152','4','PI',1,'[{\"added\": {}}]',42,1),(385,'2019-09-05 00:05:01.887238','5','program officer',1,'[{\"added\": {}}]',42,1),(386,'2019-09-05 00:05:58.613142','56','Maximillian,,Haeussler',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(387,'2019-09-05 00:06:35.612362','8','Alex,,Pollen',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(388,'2019-09-05 00:06:46.954251','7','Chris,,Villareal',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(389,'2019-09-05 00:07:00.585385','6','William,,Sullivan',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(390,'2019-09-05 00:07:10.002001','5','Paris,,Nejad',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(391,'2019-09-05 00:07:19.904704','4','W,Jim,Kent',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(392,'2019-09-05 00:07:30.592919','3','Clay,M,Fischer',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(393,'2019-09-05 00:21:17.357569','25','Stephen,R,Quake',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(394,'2019-09-05 00:23:27.501831','58','Evangelia,,Diamanti',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(395,'2019-09-05 00:24:06.321608','2','Mjösberg,J,M',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(396,'2019-09-05 00:25:40.775533','59','The,Great,Snark',2,'[{\"changed\": {\"fields\": [\"city\"]}}]',11,1),(397,'2019-09-05 00:26:06.266319','10','Fiona,,Hamey',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(398,'2019-09-05 00:26:29.559179','37','Aviv,,Regev',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(399,'2019-09-05 00:45:53.717017','60','Jonah,,Cool',1,'[{\"added\": {}}]',11,1),(400,'2019-09-05 00:46:51.887072','11','Dimitris,,Karamitros',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(401,'2019-09-05 00:47:07.825928','12','Bilyana,,Stoilova',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(402,'2019-09-05 00:47:34.734072','13','Lindsey,W,Plasschaert',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(403,'2019-09-05 00:50:20.794648','1','Asa,Kristina,Bjorklund',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(404,'2019-09-05 00:51:56.625325','8','Alex,,Pollen',2,'[{\"changed\": {\"fields\": [\"city\"]}}]',11,1),(405,'2019-09-05 00:52:19.120063','4','W,Jim,Kent',2,'[{\"changed\": {\"fields\": [\"city\"]}}]',11,1),(406,'2019-09-05 01:44:53.687521','6','William,,Sullivan',2,'[]',11,1),(407,'2019-09-05 01:50:32.345497','1','Asa,Kristina,Bjorklund',2,'[{\"changed\": {\"fields\": [\"city\", \"country\"]}}]',11,1),(408,'2019-09-05 01:51:57.352207','11','HumanLymphoMyeloidProgenitorCells',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(409,'2019-09-05 01:55:41.270203','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"cur_state\", \"effort\"]}}]',10,1),(410,'2019-09-05 02:16:55.900192','3','Paris,,Nejad',1,'[{\"added\": {}}]',43,1),(411,'2019-09-05 02:17:21.737274','4','Chris,,Villareal',1,'[{\"added\": {}}]',43,1),(412,'2019-09-05 02:17:51.364131','2','Paris,,Nejad',3,'',43,1),(413,'2019-09-05 02:17:51.365691','1','Paris,,Nejad',3,'',43,1),(414,'2019-09-05 02:18:17.670952','5','William,,Sullivan',1,'[{\"added\": {}}]',43,1),(415,'2019-09-05 02:18:53.554612','6','Clay,M,Fischer',1,'[{\"added\": {}}]',43,1),(416,'2019-09-05 02:19:04.312151','7','W,Jim,Kent',1,'[{\"added\": {}}]',43,1),(417,'2019-09-05 02:19:17.674197','8','Maximillian,,Haeussler',1,'[{\"added\": {}}]',43,1),(418,'2019-09-05 02:25:46.403699','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(419,'2019-09-05 02:26:06.340176','5','humphreysKidneyOrganoids1',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(420,'2019-09-05 02:26:39.436708','3','RevisedAirwayEpithelialHierarchy',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(421,'2019-09-05 02:27:04.984182','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(422,'2019-09-05 02:27:31.297891','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(423,'2019-09-05 02:31:17.841328','8','Maximillian,,Haeussler',3,'',43,1),(424,'2019-09-05 03:03:32.325311','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"organ\"]}}]',10,1),(425,'2019-09-05 03:21:25.639096','6','pipeliner',1,'[{\"added\": {}}]',42,1),(426,'2019-09-05 03:22:47.050534','7','analyst',1,'[{\"added\": {}}]',42,1),(427,'2019-09-05 03:23:12.454954','56','Maximillian,,Haeussler',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(428,'2019-09-05 03:24:05.690624','61','Josh,,Stuart',1,'[{\"added\": {}}]',11,1),(429,'2019-09-05 03:26:42.739642','62','Jing,,Zhu',1,'[{\"added\": {}}]',11,1),(430,'2019-09-05 03:31:54.181335','61','Josh,,Stuart',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(431,'2019-09-05 03:33:41.646606','63','Benedict,,Paten',1,'[{\"added\": {}}]',11,1),(432,'2019-09-05 03:35:32.925185','64','Timothy,,Tickle',1,'[{\"added\": {}}]',11,1),(433,'2019-09-05 04:23:24.267132','1','Paris,,Nejad',1,'[{\"added\": {}}]',44,1),(434,'2019-09-05 04:24:11.452170','1','Paris,,Nejad',2,'[{\"changed\": {\"fields\": [\"interests\"]}}]',44,1),(435,'2019-09-05 04:41:22.751085','1','W,Jim,Kent',1,'[{\"added\": {}}]',45,1),(436,'2019-09-05 04:41:47.683913','2','Maximillian,,Haeussler',1,'[{\"added\": {}}]',45,1),(437,'2019-09-05 04:47:40.509605','3','Clay,M,Fischer',1,'[{\"added\": {}}]',45,1),(438,'2019-09-05 04:47:48.129913','3','Clay,M,Fischer',2,'[{\"changed\": {\"fields\": [\"favorite_languages\"]}}]',45,1),(439,'2019-09-05 04:52:57.054500','7','W,Jim,Kent',2,'[{\"changed\": {\"fields\": [\"favorite_site\"]}}]',43,1),(440,'2019-09-05 05:36:21.718996','1','Jim',2,'[{\"changed\": {\"fields\": [\"username\"]}}]',4,1),(441,'2019-09-05 05:36:28.561542','2','Clay',2,'[{\"changed\": {\"fields\": [\"username\"]}}]',4,1),(442,'2019-09-05 05:38:33.488139','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(443,'2019-09-05 05:41:28.249805','3','pipeliners',1,'[{\"added\": {}}]',3,1),(444,'2019-09-05 05:43:31.458430','6','Tim',1,'[{\"added\": {}}]',4,1),(445,'2019-09-05 05:44:28.870484','6','Tim',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"is_staff\", \"groups\"]}}]',4,1),(446,'2019-09-05 05:49:21.828521','6','Tim',2,'[{\"changed\": {\"fields\": [\"user_permissions\"]}}]',4,1),(447,'2019-09-05 05:51:38.362747','6','Tim',2,'[{\"changed\": {\"fields\": [\"user_permissions\"]}}]',4,1),(448,'2019-09-05 06:24:20.240286','5','Jonah',2,'[{\"changed\": {\"fields\": [\"user_permissions\"]}}]',4,1),(449,'2019-09-05 06:26:08.631245','5','Jonah',2,'[{\"changed\": {\"fields\": [\"user_permissions\"]}}]',4,1),(450,'2019-09-05 14:51:02.213503','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"cur_state\"]}}]',10,1),(451,'2019-09-05 20:16:00.515123','7','willrockout',1,'[{\"added\": {}}]',4,2),(452,'2019-09-05 20:16:12.838528','8','chris',1,'[{\"added\": {}}]',4,2),(453,'2019-09-05 20:17:02.908532','7','willrockout',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\", \"groups\"]}}]',4,2),(454,'2019-09-05 20:17:39.009075','8','chris',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\", \"groups\"]}}]',4,2),(455,'2019-09-06 00:06:17.820592','13','HumanIlcSubsetsHumblesWang',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(456,'2019-09-06 00:19:33.956532','14','HumanDevoRetinaHuTang',3,'',10,1),(457,'2019-09-06 00:20:00.469586','15','HumanDevoRetinaHuTang',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(458,'2019-09-06 00:29:18.782159','16','HumanNaturalKillerDiversityYang',2,'[{\"changed\": {\"fields\": [\"disease\"]}}]',10,1),(459,'2019-09-06 00:29:39.896520','7','donor',3,'',17,1),(460,'2019-09-06 00:30:03.256704','8','GATA2T354M',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',17,1),(461,'2019-09-06 00:36:07.405321','16','HumanNaturalKillerDiversityYang',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(462,'2019-09-06 00:36:48.592594','15','HumanDevoRetinaHuTang',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(463,'2019-09-06 00:37:09.622026','13','HumanIlcSubsetsHumblesWang',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(464,'2019-09-06 00:59:36.595310','59','The,Great,Snark',3,'',11,1),(465,'2019-09-06 00:59:51.469450','6','The snark lab east',3,'',8,1),(466,'2019-09-06 01:00:27.891440','7','Liu Lab Columbia University',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(467,'2019-09-06 01:06:38.777767','18','CsfFromTwinsDiscordantForMultSclerosis',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(468,'2019-09-06 01:08:26.838966','7','Fluidigm C1 SMARTer-seq',1,'[{\"added\": {}}]',20,1),(469,'2019-09-06 01:08:43.188151','17','PreCdcFateTxFactCompetition',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(470,'2019-09-06 01:09:11.818588','16','HumanNaturalKillerDiversityYang',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(471,'2019-09-06 01:11:05.112719','3','Clay,M,Fischer',2,'[{\"changed\": {\"fields\": [\"email\"]}}]',11,1),(472,'2019-09-06 02:25:01.780023','20','HumanDevoKidneyAndOrganoidsRansickMcMahon',3,'',10,1),(473,'2019-09-06 02:37:36.767799','22','HumanSkinBloodHypSensAndNormalKim',2,'[{\"changed\": {\"fields\": [\"organ\", \"assay_tech\"]}}]',10,1),(474,'2019-09-06 02:39:51.617497','21','HumanDevoKidneyAndOrganoidsRansickMcMahon',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(475,'2019-09-06 02:40:43.012761','19','MammalSomatogenEndodermLiXu',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(476,'2019-09-06 02:47:43.966191','23','Human5Ovary10xChuva',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(477,'2019-09-06 02:56:10.198198','21','HumanDevoKidneyOrganoidsRansick',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',10,1),(478,'2019-09-06 02:56:51.992349','7','C1 SMARTer-seq',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',20,1),(479,'2019-09-06 02:57:49.540454','13','integrated analysis',3,'',12,1),(480,'2019-09-06 04:13:48.736598','1','Mjösberg Lab Uppsala University',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',8,1),(481,'2019-09-06 04:42:26.997277','12','cancer',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',17,1),(482,'2019-09-06 04:43:26.558247','10','multiple schlerosis',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',17,1),(483,'2019-09-06 04:44:35.509414','9','subclinical neuro-inflammation',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',17,1),(484,'2019-09-06 04:45:23.322200','11','autoimmune encephalitis',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',17,1),(485,'2019-09-06 04:46:22.894752','11','bone marrow',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',18,1),(486,'2019-09-06 04:47:33.376403','5','kidney',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(487,'2019-09-06 04:48:10.201632','5','kidney',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(488,'2019-09-06 04:48:35.988341','5','kidney',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(489,'2019-09-06 04:50:46.794979','9','Chuva Sousa Lopes Lab',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(490,'2019-09-06 05:18:10.955444','25','Follicle 1-2mm from ovary',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',14,1),(491,'2019-09-06 05:18:40.929201','24','Follicle 2-5mm from ovary',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',14,1),(492,'2019-09-06 05:20:00.050827','23','stroma from ovary',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',14,1),(493,'2019-09-06 13:43:35.571648','21','HumanDevoKidneyOrganoidsRansick',2,'[{\"changed\": {\"fields\": [\"organ_part\"]}}]',10,1),(494,'2019-09-06 13:43:57.574222','22','human kidney organoid',3,'',14,1),(495,'2019-09-06 13:44:02.717844','21','human kidney',3,'',14,1),(496,'2019-09-06 13:45:25.594942','8','peripheral blood',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',14,1),(497,'2019-09-06 13:45:59.357894','10','Bone marrow NK cells',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',14,1),(498,'2019-09-06 14:48:05.141982','24','HumanMarrowIntegrationButlerStuart',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(499,'2019-09-06 15:00:23.778192','25','HumanQuickAdultKidneyLiaoMo',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(500,'2019-09-06 15:05:25.139915','27','human peripheral blood dendritic cells and monocyt',3,'',14,1),(501,'2019-09-06 15:10:17.724165','13','lupus',1,'[{\"added\": {}}]',17,1),(502,'2019-09-06 15:13:47.528171','26','Bone Marrow Mononuclear Cells',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',14,1),(503,'2019-09-06 15:16:11.701084','28','peripheral blood phagocytes',1,'[{\"added\": {}}]',14,1),(504,'2019-09-06 15:17:22.751569','26','HumanPhagocytesHealthyLupusDutetre',2,'[{\"changed\": {\"fields\": [\"organ_part\", \"disease\"]}}]',10,1),(505,'2019-09-06 15:22:45.439975','26','HumanPhagocytesHealthyLupusDutetre',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"assay_tech\"]}}]',10,1),(506,'2019-09-06 15:26:16.167357','27','HumanFoveaRetinaScheetzSheffield',2,'[{\"changed\": {\"fields\": [\"sample_type\", \"assay_tech\"]}}]',10,1),(507,'2019-09-06 15:33:34.950769','8','Andrew McMahon University of Southern California',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(508,'2019-09-06 16:24:16.646486','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(509,'2019-09-06 16:25:43.262273','1','Paris,,Nejad',2,'[{\"changed\": {\"fields\": [\"interests\"]}}]',44,4),(510,'2019-09-06 17:25:11.943637','14','ovary',2,'[]',18,4),(511,'2019-09-06 17:39:00.931641','14','ovary',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(512,'2019-09-06 17:40:05.466547','13','skin',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,4),(513,'2019-09-06 17:40:55.305146','13','skin',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\"]}}]',18,4),(514,'2019-09-06 17:41:04.840526','14','ovary',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,4),(515,'2019-09-06 17:41:19.217191','13','skin',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,4),(516,'2019-09-06 17:48:40.268653','12','spinal chord',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(517,'2019-09-06 17:49:28.870621','11','bone marrow',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(518,'2019-09-06 17:50:05.748919','10','eye',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(519,'2019-09-06 17:50:48.999759','9','blood',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(520,'2019-09-06 17:51:29.233926','8','umbilical cord',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(521,'2019-09-06 17:52:32.918323','7','liver',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(522,'2019-09-06 17:53:33.695965','6','brain',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(523,'2019-09-06 17:54:20.764490','5','kidney',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(524,'2019-09-06 17:54:58.420741','4','pancreas',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(525,'2019-09-06 17:55:35.282139','2','lung',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(526,'2019-09-06 17:56:26.465566','1','tonsil',2,'[{\"changed\": {\"fields\": [\"ontology_id\", \"ontology_label\", \"description\"]}}]',18,4),(527,'2019-09-06 17:56:53.955937','3','full body',2,'[]',18,4),(528,'2019-09-06 18:36:41.675755','9','blood',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(529,'2019-09-06 18:59:12.787645','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(530,'2019-09-06 19:12:36.124611','168','Beagan,,Nguy',1,'[{\"added\": {}}]',11,4),(531,'2019-09-06 19:13:14.433204','2','Beagan,,Nguy',1,'[{\"added\": {}}]',44,4),(532,'2019-09-06 19:13:57.355486','169','Pranav,,Muthuraman',1,'[{\"added\": {}}]',11,4),(533,'2019-09-06 19:14:10.801739','3','Pranav,,Muthuraman',1,'[{\"added\": {}}]',44,4),(534,'2019-09-06 19:14:51.431199','170','Kamron,,Mojabe',1,'[{\"added\": {}}]',11,4),(535,'2019-09-06 19:14:57.220728','4','Kamron,,Mojabe',1,'[{\"added\": {}}]',44,4),(536,'2019-09-06 19:15:21.722679','1','Paris,,Nejad',3,'',44,4),(537,'2019-09-06 19:15:31.809954','4','Kamron,,Mojabe',2,'[{\"changed\": {\"fields\": [\"interests\"]}}]',44,4),(538,'2019-09-06 20:08:16.207934','8','intern',1,'[{\"added\": {}}]',42,1),(539,'2019-09-06 20:09:56.546397','170','Kamron,,Mojabe',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(540,'2019-09-06 20:10:09.846204','169','Pranav,,Muthuraman',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(541,'2019-09-06 20:10:21.418876','168','Beagan,,Nguy',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(542,'2019-09-06 20:32:17.915943','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(543,'2019-09-06 20:49:40.695331','27','HumanFoveaRetinaScheetzSheffield',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(544,'2019-09-06 20:50:02.862063','26','HumanPhagocytesHealthyLupusDutetre',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(545,'2019-09-06 20:50:17.700676','25','HumanQuickAdultKidneyLiaoMo',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(546,'2019-09-06 20:50:35.544532','24','HumanMarrowIntegrationButlerStuart',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(547,'2019-09-06 20:50:55.376899','23','Human5Ovary10xChuva',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(548,'2019-09-06 20:51:09.377306','13','HumanIlcSubsetsHumblesWang',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(549,'2019-09-06 20:52:18.876292','15','HumanDevoRetinaHuTang',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(550,'2019-09-06 20:52:48.535540','16','HumanNaturalKillerDiversityYang',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(551,'2019-09-06 21:19:01.527095','171','A,Test,Case',1,'[{\"added\": {}}]',11,1),(552,'2019-09-13 01:50:16.034748','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"stars\", \"description\", \"contributors\"]}}]',10,1),(553,'2019-09-13 01:53:37.849307','33','Multiplexed scRNA-seq with barcoded antibodies',2,'[{\"changed\": {\"fields\": [\"stars\", \"description\", \"contributors\"]}}]',10,1),(554,'2019-09-13 02:08:05.839283','42','Single cell RNAseq characterization of cell types produced over time in an in vi',3,'',10,1),(555,'2019-09-13 02:09:19.976194','9','Mallory,Ann,Freeberg',1,'[{\"added\": {}}]',43,1),(556,'2019-09-13 02:09:43.308552','10','Laura,,Huerta',1,'[{\"added\": {}}]',43,1),(557,'2019-09-13 02:09:58.506436','11','Matthew,,Green',1,'[{\"added\": {}}]',43,1),(558,'2019-09-13 02:10:56.597866','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"stars\", \"organ\", \"description\"]}}]',10,1),(559,'2019-09-13 02:13:06.651948','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(560,'2019-09-13 02:13:26.771399','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(561,'2019-09-13 02:15:21.992753','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"stars\"]}}]',10,1),(562,'2019-09-13 02:15:51.004708','50','HDCA-Sweden-10x',2,'[{\"changed\": {\"fields\": [\"stars\"]}}]',10,1),(563,'2019-09-13 02:16:32.183158','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"consent\"]}}]',10,1),(564,'2019-09-13 02:16:45.616755','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"consent\"]}}]',10,1),(565,'2019-09-13 02:17:03.330205','50','HDCA-Sweden-10x',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"consent\"]}}]',10,1),(566,'2019-09-13 02:17:49.000298','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"wrangler2\"]}}]',10,1),(567,'2019-09-13 02:18:23.889012','48','Fetal/Maternal Interface',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\"]}}]',10,1),(568,'2019-09-13 02:18:52.951527','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\"]}}]',10,1),(569,'2019-09-13 02:19:55.369939','12','Danielle,,Welter',1,'[{\"added\": {}}]',43,1),(570,'2019-09-13 02:20:27.950024','46','1M Immune Cells',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"wrangler2\"]}}]',10,1),(571,'2019-09-13 02:23:06.332223','45','Drop-seq, DroNc-seq, Fluidigm C1 Comparison',2,'[{\"changed\": {\"fields\": [\"short_name\", \"state_reached\", \"title\", \"stars\", \"consent\", \"wrangler1\", \"assay_tech\", \"description\"]}}]',10,1),(572,'2019-09-13 02:25:02.640611','44','WongAdultRetina',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"species\", \"organ\", \"organ_part\", \"assay_type\", \"assay_tech\"]}}]',10,1),(573,'2019-09-13 02:25:47.794375','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\"]}}]',10,1),(574,'2019-09-13 02:26:54.623258','13','Dana,,Pe\'er',1,'[{\"added\": {}}]',43,1),(575,'2019-09-13 02:27:03.606899','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"consent\", \"wrangler1\", \"wrangler2\"]}}]',10,1),(576,'2019-09-13 02:27:59.849439','13','Dana,,Pe\'er',3,'',43,1),(577,'2019-09-13 02:29:31.134861','40','BM_PC',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\"]}}]',10,1),(578,'2019-09-13 02:30:06.061063','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\"]}}]',10,1),(579,'2019-09-13 02:31:37.125907','31','differentiated H1 cells',1,'[{\"added\": {}}]',14,1),(580,'2019-09-13 02:31:45.350731','38','Single cell RNAseq characterization of cell types produced over time in an in vi',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"wrangler2\", \"organ_part\"]}}]',10,1),(581,'2019-09-13 02:32:40.684989','37','Single cell transcriptome analysis of human pancreas',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"wrangler2\"]}}]',10,1),(582,'2019-09-13 02:33:40.309451','36','Healthy and type 2 diabetes pancreas',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"wrangler2\", \"organ\", \"disease\"]}}]',10,1),(583,'2019-09-13 02:34:53.795669','35','Tabula Muris',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"sample_type\", \"organ\", \"disease\", \"assay_type\"]}}]',10,1),(584,'2019-09-13 02:36:07.205820','2','TabulaMuris',2,'[{\"changed\": {\"fields\": [\"uuid\"]}}]',10,1),(585,'2019-09-13 02:37:22.526890','2','Tabula Muris',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',10,1),(586,'2019-09-13 02:37:35.758028','35','Tabula Muris',3,'',10,1),(587,'2019-09-13 02:39:00.908067','32','cerebral organoid',1,'[{\"added\": {}}]',14,1),(588,'2019-09-13 02:39:13.872816','34','HPSI human cerebral organoids',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"organ_part\"]}}]',10,1),(589,'2019-09-13 02:39:45.547211','33','Multiplexed scRNA-seq with barcoded antibodies',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"consent\", \"assay_type\", \"assay_tech\"]}}]',10,1),(590,'2019-09-13 02:40:05.514197','33','Multiplexed scRNA-seq with barcoded antibodies',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,1),(591,'2019-09-13 02:40:48.635695','32','KidneySingleCellAtlas',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"organ\"]}}]',10,1),(592,'2019-09-13 02:41:57.475027','14','melanoma',1,'[{\"added\": {}}]',17,1),(593,'2019-09-13 02:42:04.330945','31','Mouse Melanoma',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"wrangler2\", \"disease\"]}}]',10,1),(594,'2019-09-13 02:42:48.944199','30','demo HPSI human cerebral organoids',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"organ_part\"]}}]',10,1),(595,'2019-09-13 02:43:51.979084','29','Tissue stability',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\"]}}]',10,1),(596,'2019-09-13 02:45:17.062354','15','colon',1,'[{\"added\": {}}]',18,1),(597,'2019-09-13 02:45:46.033289','15','colon',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(598,'2019-09-13 02:47:13.882380','28','HumanColonicMesenchymeIBD',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\", \"consent\", \"wrangler1\", \"organ\"]}}]',10,1),(599,'2019-09-13 02:59:00.210176','5','humphreysKidneyOrganoids1',3,'',10,1),(600,'2019-09-13 03:01:17.172951','12','spinal cord',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',18,1),(601,'2019-09-13 04:08:51.134175','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(602,'2019-09-13 04:09:11.277166','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(603,'2019-09-13 04:09:36.325077','184','William,G,Sullivan',3,'',11,1),(604,'2019-09-13 12:18:11.318594','6','William,G,Sullivan',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(605,'2019-09-13 12:23:36.525116','27','HumanFoveaRetinaScheetzSheffield',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(606,'2019-09-13 12:24:11.070562','166','Todd,E,Scheetz',3,'',11,1),(607,'2019-09-13 12:24:37.938375','165','Todd,E,Scheetz',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(608,'2019-09-13 12:25:34.231478','27','HumanFoveaRetinaScheetzSheffield',2,'[{\"changed\": {\"fields\": [\"contacts\", \"contributors\"]}}]',10,1),(609,'2019-09-13 12:26:12.532103','165','Todd,E,Scheetz',2,'[]',11,1),(610,'2019-09-13 12:30:26.492529','45','Drop-seq, DroNc-seq, Fluidigm C1 Comparison',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(611,'2019-09-13 12:31:20.822820','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(612,'2019-09-13 12:31:55.575608','190','Parisa,,Nejad',3,'',11,1),(613,'2019-09-13 12:32:22.779727','5','Parisa,,Nejad',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(614,'2019-09-13 12:32:45.702604','5','Parisa,,Nejad',2,'[]',11,1),(615,'2019-09-13 12:36:40.408131','185','Christopher,,Villarreal',3,'',11,1),(616,'2019-09-13 12:36:53.286142','7','Christopher,,Villareal',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(617,'2019-09-13 12:37:35.079364','182','Enrique,,Sapena-Ventura',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(618,'2019-09-13 12:39:18.119201','205','Zinaida,A,Perova',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(619,'2019-09-13 12:39:29.655252','202','Marion,F,Shadbolt',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(620,'2019-09-13 12:39:53.423626','187','Anja,,Fullgrabe',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(621,'2019-09-13 12:43:24.722774','202','Marion,F,Shadbolt',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(622,'2019-09-13 16:06:17.189963','2','Tabula Muris',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(623,'2019-09-13 16:22:56.025909','44','WongAdultRetina',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(624,'2019-09-13 16:24:20.906725','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(625,'2019-09-13 16:25:27.198374','44','WongAdultRetina',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(626,'2019-09-13 16:32:42.603633','44','WongAdultRetina',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(627,'2019-09-13 16:34:17.520442','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(628,'2019-09-13 16:36:17.417954','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(629,'2019-09-13 16:36:31.512552','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"effort\"]}}]',10,1),(630,'2019-09-13 16:37:13.939598','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"sheet_validated_date\"]}}]',10,1),(631,'2019-09-13 16:40:39.331551','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"cur_state\", \"sheet_validated_date\", \"sheet_that_validated\"]}}]',10,1),(632,'2019-09-13 16:43:32.991557','32','KidneySingleCellAtlas',2,'[{\"changed\": {\"fields\": [\"sheet_validated_date\", \"sheet_that_validated\", \"description\"]}}]',10,1),(633,'2019-09-13 16:50:59.077772','53','MouseGastrulationAtlas',1,'[{\"added\": {}}]',10,1),(634,'2019-09-13 16:56:00.959363','209','John,C,Marioni',1,'[{\"added\": {}}]',11,1),(635,'2019-09-13 16:56:13.372186','209','John,C,Marioni',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(636,'2019-09-13 16:56:52.972572','53','MouseGastrulationAtlas',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(637,'2019-09-13 16:57:11.954029','53','MouseGastrulationAtlas',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"stars\"]}}]',10,1),(638,'2019-09-13 17:30:35.353719','53','MouseGastrulationAtlas',2,'[{\"changed\": {\"fields\": [\"assay_type\", \"assay_tech\", \"cells_expected\"]}}]',10,1),(639,'2019-09-13 17:33:17.503127','9','pmid: 30787436',1,'[{\"added\": {}}]',22,1),(640,'2019-09-13 17:38:33.820125','210','Berthold,,Göttgens',1,'[{\"added\": {}}]',11,1),(641,'2019-09-13 17:39:46.372562','210','Berthold,,Göttgens',2,'[{\"changed\": {\"fields\": [\"institute\"]}}]',11,1),(642,'2019-09-14 02:12:34.596104','28','HumanColonicMesenchymeIBD',2,'[{\"changed\": {\"fields\": [\"sheet_validated_date\", \"sheet_that_validated\"]}}]',10,1),(643,'2019-09-14 02:15:20.787524','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"sheet_validated_date\", \"sheet_that_validated\"]}}]',10,1),(644,'2019-09-14 02:24:59.996148','50','HDCA-Sweden-10x',2,'[{\"changed\": {\"fields\": [\"stars\", \"description\"]}}]',10,1),(645,'2019-09-14 02:27:18.214716','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"stars\", \"description\"]}}]',10,1),(646,'2019-09-14 02:28:32.025744','52','HumanMousePancreas',2,'[]',10,1),(647,'2019-09-14 02:29:49.759696','46','1M Immune Cells',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(648,'2019-09-14 02:43:40.406816','38','Single cell RNAseq characterization of cell types produced over time',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',10,1),(649,'2019-09-14 02:50:37.858305','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"uuid\"]}}]',10,1),(650,'2019-09-14 02:53:38.774535','10','PMID: 31506348',1,'[{\"added\": {}}]',22,1),(651,'2019-09-14 03:26:43.808736','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(652,'2019-09-14 21:56:14.025633','171','A,Test,Case',3,'',11,1),(653,'2019-09-14 21:58:03.429890','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(654,'2019-09-14 21:59:22.495766','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(655,'2019-09-14 22:00:10.154018','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(656,'2019-09-14 22:20:32.969531','9','markd',1,'[{\"added\": {}}]',4,1),(657,'2019-09-15 00:15:18.281132','36','Healthy and type 2 diabetes pancreas',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(658,'2019-09-15 00:15:56.636333','46','1M Immune Cells',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(659,'2019-09-15 00:16:13.972947','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(660,'2019-09-15 00:16:32.634097','40','BM_PC',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(661,'2019-09-15 00:16:49.089322','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(662,'2019-09-15 00:17:31.100300','30','demo HPSI human cerebral organoids',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(663,'2019-09-15 00:17:55.399933','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(664,'2019-09-15 00:18:10.236644','45','Drop-seq, DroNc-seq, Fluidigm C1 Comparison',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(665,'2019-09-15 00:18:24.440811','36','Healthy and type 2 diabetes pancreas',2,'[]',10,1),(666,'2019-09-15 00:18:39.972888','48','Fetal/Maternal Interface',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(667,'2019-09-15 00:19:30.592040','10','Laura,,Huerta',3,'',43,1),(668,'2019-09-15 00:20:20.166613','50','HDCA-Sweden-10x',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(669,'2019-09-15 00:20:57.588027','34','HPSI human cerebral organoids',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(670,'2019-09-15 00:21:16.254040','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(671,'2019-09-15 00:21:34.486128','28','HumanColonicMesenchymeIBD',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(672,'2019-09-15 00:22:20.233339','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(673,'2019-09-15 00:22:46.790619','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(674,'2019-09-15 00:23:14.988460','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(675,'2019-09-15 00:23:47.120812','32','KidneySingleCellAtlas',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(676,'2019-09-15 00:24:08.042635','31','Mouse Melanoma',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(677,'2019-09-15 00:24:20.630171','33','Multiplexed scRNA-seq with barcoded antibodies',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(678,'2019-09-15 00:24:33.410320','38','Single cell RNAseq characterization of cell types produced over time',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(679,'2019-09-15 00:24:48.199731','37','Single cell transcriptome analysis of human pancreas',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(680,'2019-09-15 00:25:22.240304','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(681,'2019-09-15 00:25:35.240797','2','Tabula Muris',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(682,'2019-09-15 00:25:47.791541','29','Tissue stability',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(683,'2019-09-15 00:26:00.116344','44','WongAdultRetina',2,'[{\"changed\": {\"fields\": [\"state_reached\"]}}]',10,1),(684,'2019-09-15 01:38:01.555043','9','markd',2,'[{\"changed\": {\"fields\": [\"is_staff\", \"groups\"]}}]',4,1),(685,'2019-09-15 01:39:07.474187','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(686,'2019-09-15 16:10:29.152721','52','HumanMousePancreas',2,'[]',10,1),(687,'2019-09-15 18:35:03.781264','16','spleen',1,'[{\"added\": {}}]',18,1),(688,'2019-09-15 18:35:41.473879','17','esophagus',1,'[{\"added\": {}}]',18,1),(689,'2019-09-15 18:36:20.318844','29','Tissue stability',2,'[{\"changed\": {\"fields\": [\"sample_type\", \"organ\"]}}]',10,1),(690,'2019-09-15 18:38:24.675626','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(691,'2019-09-16 02:59:08.683521','54','AirwayEpitheliumPulmonaryIonocyte',3,'',10,1),(692,'2019-09-16 02:59:59.220153','33','HBECs',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',14,1),(693,'2019-09-16 03:00:11.594687','55','AirwayEpitheliumPulmonaryIonocyte',3,'',10,1),(694,'2019-09-16 03:01:03.395314','11','Klein Lab Harvard Medical School',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(695,'2019-09-16 03:01:50.047166','56','AirwayEpitheliumPulmonaryIonocyte',2,'[{\"changed\": {\"fields\": [\"stars\", \"assay_tech\"]}}]',10,1),(696,'2019-09-16 03:02:40.347717','56','AirwayEpitheliumPulmonaryIonocyte',2,'[]',10,1),(697,'2019-09-16 03:10:20.477788','56','AirwayEpitheliumPulmonaryIonocyte',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(698,'2019-09-16 03:31:27.647215','57','CorticalNephrogenicNicheKidney',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(699,'2019-09-16 04:25:07.681950','58','DevelopmentalLineageMouseMammaryGland',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\", \"contributors\"]}}]',10,1),(700,'2019-09-16 04:56:09.754040','59','MouseMammaryEpithelialCells',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(701,'2019-09-16 05:04:55.633944','218','\"Aron,B,Jaffe\"',3,'',11,1),(702,'2019-09-16 05:04:55.635827','217','\"Guglielmo,,Roma\"',3,'',11,1),(703,'2019-09-16 05:04:55.636861','216','\"Judith,,Knehr\"',3,'',11,1),(704,'2019-09-16 05:04:55.637876','215','\"Virginia,,Savova\"',3,'',11,1),(705,'2019-09-16 05:04:55.638871','214','\"Rayman,,Choo-Wing\"',3,'',11,1),(706,'2019-09-16 05:04:55.639847','213','\"Rapolas,,Zilionis\"',3,'',11,1),(707,'2019-09-16 05:04:55.640827','212','\"Lindsey,W,Plasschaert\"',3,'',11,1),(708,'2019-09-16 05:04:55.641779','211','\"Allon,M,Klein\"',3,'',11,1),(709,'2019-09-16 05:05:29.252960','231','Katalin,,Suszták',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(710,'2019-09-16 05:18:52.609031','61','TranscriptomeLandscapeHumanFollicle',2,'[{\"changed\": {\"fields\": [\"stars\"]}}]',10,1),(711,'2019-09-16 05:20:33.278995','57','CorticalNephrogenicNicheKidney',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(712,'2019-09-16 05:30:38.067571','61','TranscriptomeLandscapeHumanFollicle',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(713,'2019-09-16 05:30:49.652841','60','SingleCellTranscriptomicsMouseKidney',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(714,'2019-09-16 06:04:52.452237','235','M,D,Lynch',3,'',11,1),(715,'2019-09-16 06:05:24.679581','62','HumanDermalFibroblastSubpopulations',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(716,'2019-09-16 06:29:10.466085','238','Thiago,,Oliveira',3,'',11,1),(717,'2019-09-16 06:29:50.157051','63','HumanDCsFromPre-cDCs',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\", \"contributors\"]}}]',10,1),(718,'2019-09-16 06:30:00.850714','62','HumanDermalFibroblastSubpopulations',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab_date\"]}}]',10,1),(719,'2019-09-16 06:31:45.905735','63','HumanDCsFromPre-cDCs',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(720,'2019-09-16 06:32:59.844701','237','Thiago,Y,Oliveira',2,'[{\"changed\": {\"fields\": [\"city\"]}}]',11,1),(721,'2019-09-16 06:34:19.018556','4','W,James,Kent',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(722,'2019-09-16 06:36:40.255906','10','Satija Lab New York Genome Center',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(723,'2019-09-16 06:37:05.544473','12','Smyth Lab Walter and Eliza Hall Institute',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(724,'2019-09-16 06:37:30.939394','5','Gottgens University of Cambridge',2,'[{\"changed\": {\"fields\": [\"pi\"]}}]',8,1),(725,'2019-09-16 07:05:40.730492','97','Kang,,Liu',2,'[{\"changed\": {\"fields\": [\"city\"]}}]',11,1),(726,'2019-09-16 07:08:58.762502','10','multiple schlerosis',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',17,1),(727,'2019-09-16 20:06:30.610735','15','sn-RNA-seq',1,'[{\"added\": {}}]',20,4),(728,'2019-09-16 20:08:19.572964','12','Diabetic Nephropathy snRNA-seq',2,'[{\"changed\": {\"fields\": [\"staging_area_date\", \"submit_date\", \"submit_comments\", \"assay_tech\"]}}]',10,4),(729,'2019-09-17 00:33:38.949589','3','Kent Single Cell UC Santa Cruz',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',8,1),(730,'2019-09-17 00:34:00.977570','3','Jim Kent Single Cell UC Santa Cruz',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',8,1),(731,'2019-09-18 01:05:44.882712','2','Tabula Muris',2,'[{\"changed\": {\"fields\": [\"sheet_validated_date\", \"sheet_that_validated\"]}}]',10,1),(732,'2019-09-18 18:09:29.717144','239','Enrique,Sapena,Ventura',1,'[{\"added\": {}}]',11,7),(733,'2019-09-18 18:09:50.373698','14','Enrique,Sapena,Ventura',1,'[{\"added\": {}}]',43,7),(734,'2019-09-18 18:11:06.110787','53','MouseGastrulationAtlas',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,7),(735,'2019-09-18 18:12:52.204960','32','KidneySingleCellAtlas',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,7),(736,'2019-09-18 18:14:06.891134','15','Marion,F,Shadbolt',1,'[{\"added\": {}}]',43,7),(737,'2019-09-18 18:14:17.509530','44','WongAdultRetina',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,7),(738,'2019-09-18 18:42:17.099016','44','cerebral cortex',1,'[{\"added\": {}}]',14,7),(739,'2019-09-18 18:43:18.656748','45','subventricular zone',1,'[{\"added\": {}}]',14,7),(740,'2019-09-18 18:43:34.957519','46','hippocampus',1,'[{\"added\": {}}]',14,7),(741,'2019-09-18 18:51:14.706704','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"chat_url\", \"cur_state\", \"sample_type\", \"organ\", \"organ_part\", \"disease\", \"assay_type\", \"cells_expected\"]}}]',10,7),(742,'2019-09-18 18:59:56.011521','7','Christopher,,Villarreal',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,8),(743,'2019-09-18 19:02:08.168962','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,8),(744,'2019-09-18 19:05:37.699874','13','Sims Lab; Department of Systems Biology',1,'[{\"added\": {}}]',8,8),(745,'2019-09-18 19:06:25.270697','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"labs\"]}}]',10,8),(746,'2019-09-18 19:08:01.611021','16','Zinaida,A,Perova',1,'[{\"added\": {}}]',43,8),(747,'2019-09-18 19:08:06.707518','50','HDCA-Sweden-10x',2,'[{\"changed\": {\"fields\": [\"wrangler1\"]}}]',10,8),(748,'2019-09-19 02:08:53.895286','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"organ\"]}}]',10,1),(749,'2019-09-19 02:19:33.956755','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(750,'2019-09-19 02:20:53.826887','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(751,'2019-09-19 02:42:34.293936','59','MouseMammaryEpithelialCells',2,'[{\"changed\": {\"fields\": [\"assay_tech\", \"cells_expected\"]}}]',10,1),(752,'2019-09-19 19:11:47.924105','25','HumanQuickAdultKidneyLiaoMo',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(753,'2019-09-19 19:16:20.909662','62','HumanDermalFibroblastSubpopulations',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(754,'2019-09-20 14:35:53.670023','63','HumanDCsFromPre-cDCs',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(755,'2019-09-20 14:36:40.401024','62','HumanDermalFibroblastSubpopulations',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(756,'2019-09-20 14:37:29.023715','61','TranscriptomeLandscapeHumanFollicle',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(757,'2019-09-20 14:39:09.072104','60','SingleCellTranscriptomicsMouseKidney',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(758,'2019-09-20 14:39:44.809055','59','MouseMammaryEpithelialCells',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(759,'2019-09-20 14:41:15.611003','56','AirwayEpitheliumPulmonaryIonocyte',2,'[{\"changed\": {\"fields\": [\"contacts\"]}}]',10,1),(760,'2019-09-20 14:42:36.817556','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(761,'2019-09-20 15:03:36.409476','47','pancreatic islets',1,'[{\"added\": {}}]',14,1),(762,'2019-09-20 15:03:57.307595','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"organ_part\"]}}]',10,1),(763,'2019-09-20 15:25:04.429089','240','Adrian,,Veres',1,'[{\"added\": {}}]',11,1),(764,'2019-09-20 15:25:46.074720','241','Maayan,,Baron',1,'[{\"added\": {}}]',11,1),(765,'2019-09-20 15:31:17.559105','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"contacts\", \"disease\", \"assay_type\", \"contributors\"]}}]',10,1),(766,'2019-09-20 15:44:16.612616','19','lymph node',1,'[{\"added\": {}}]',18,1),(767,'2019-09-20 15:44:40.876062','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"origin_name\", \"organ\"]}}]',10,1),(768,'2019-09-20 15:45:46.067823','242','P,A,Szabo',1,'[{\"added\": {}}]',11,1),(769,'2019-09-20 15:46:34.878654','243','Levitin,H,Mendez',1,'[{\"added\": {}}]',11,1),(770,'2019-09-20 15:47:05.859256','244','M,,Miron',1,'[{\"added\": {}}]',11,1),(771,'2019-09-20 15:47:59.206300','245','M,E,Snyder',1,'[{\"added\": {}}]',11,1),(772,'2019-09-20 15:48:35.937187','246','T,,Senda',1,'[{\"added\": {}}]',11,1),(773,'2019-09-20 15:49:10.871022','247','J,,Yuan',1,'[{\"added\": {}}]',11,1),(774,'2019-09-20 15:49:48.188390','248','Y,L,Cheng',1,'[{\"added\": {}}]',11,1),(775,'2019-09-20 15:50:08.564549','249','E,C,Bush',1,'[{\"added\": {}}]',11,1),(776,'2019-09-20 15:50:28.108413','250','P,,Dogra',1,'[{\"added\": {}}]',11,1),(777,'2019-09-20 15:50:53.407334','251','P,,Thapa',1,'[{\"added\": {}}]',11,1),(778,'2019-09-20 15:50:56.446036','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"contributors\"]}}]',10,1),(779,'2019-09-20 16:05:41.189131','251','Puspa,,Thapa',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(780,'2019-09-20 16:05:51.715060','250','Pranay,,Dogra',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(781,'2019-09-20 16:06:01.066875','249','Erin,C,Bush',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(782,'2019-09-20 16:06:09.570762','248','Yim,L,Cheng',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(783,'2019-09-20 16:06:17.581255','247','Jinzhou,,Yuan',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(784,'2019-09-20 16:06:33.503569','246','Takashi,,Senda',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(785,'2019-09-20 16:06:53.711601','245','Mark,E,Snyder',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(786,'2019-09-20 16:07:02.730588','244','Michelle,,Miron',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(787,'2019-09-20 16:07:52.130117','243','Hanna,,Mendes Levitin',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(788,'2019-09-20 16:08:08.258801','242','Peter,A,Szabo',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(789,'2019-09-20 16:10:15.869773','236','Fiona,M,Watt',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(790,'2019-09-20 16:17:10.711391','51','HumanTissueTcellActivation',2,'[{\"changed\": {\"fields\": [\"state_reached\", \"disease\"]}}]',10,1),(791,'2019-09-20 16:25:29.532701','243','Hanna,Mendes,Levitin',2,'[{\"changed\": {\"fields\": [\"name\"]}}]',11,1),(792,'2019-09-20 16:28:10.868350','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(793,'2019-09-20 17:01:02.872868','252','Pandurangan,,Vijayanand',1,'[{\"added\": {}}]',11,1),(794,'2019-09-20 17:01:24.933854','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"contacts\", \"contributors\"]}}]',10,1),(795,'2019-09-20 17:02:21.940054','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"organ\"]}}]',10,1),(796,'2019-09-20 17:03:13.650341','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"assay_tech\"]}}]',10,1),(797,'2019-09-20 17:06:03.723630','18','pmid: 29352091',1,'[{\"added\": {}}]',22,1),(798,'2019-09-20 17:06:31.202966','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(799,'2019-09-20 17:07:17.856047','49','CD4+ cytotoxic T lymphocytes',2,'[]',10,1),(800,'2019-09-20 21:04:28.083447','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(801,'2019-09-20 21:05:28.896166','19','pmid: 28091601',1,'[{\"added\": {}}]',22,1),(802,'2019-09-20 21:08:41.805944','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(803,'2019-09-20 21:32:05.666644','253','Grace,X.Y.,Zheng',1,'[{\"added\": {}}]',11,1),(804,'2019-09-20 21:32:25.050741','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"contacts\", \"contributors\"]}}]',10,1),(805,'2019-09-20 21:41:25.495541','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(806,'2019-09-20 21:42:56.820330','20','pmid: 30348985',1,'[{\"added\": {}}]',22,1),(807,'2019-09-20 21:43:06.738096','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(808,'2019-09-20 21:45:38.849479','254','Jeff,,Liu',1,'[{\"added\": {}}]',11,1),(809,'2019-09-20 21:45:57.804344','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"contacts\", \"contributors\"]}}]',10,1),(810,'2019-09-20 21:54:24.022148','43','SingleCellLiverLandscape',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(811,'2019-09-20 22:05:40.671164','21','pmid: 30899105',1,'[{\"added\": {}}]',22,1),(812,'2019-09-20 22:06:13.538274','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"publications\"]}}]',10,1),(813,'2019-09-20 22:14:39.806888','14','D Pe\'er lab Sloan Kettering',1,'[{\"added\": {}}]',8,1),(814,'2019-09-20 22:16:15.764222','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"labs\", \"organ\"]}}]',10,1),(815,'2019-09-20 22:31:45.969439','7','liver',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',18,1),(816,'2019-09-21 23:15:15.868232','63','HumanDCsFromPre-cDCs',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(817,'2019-09-21 23:15:51.434950','62','HumanDermalFibroblastSubpopulations',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(818,'2019-09-21 23:16:33.801548','61','TranscriptomeLandscapeHumanFollicle',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(819,'2019-09-21 23:16:49.523925','60','SingleCellTranscriptomicsMouseKidney',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(820,'2019-09-21 23:17:05.705852','59','MouseMammaryEpithelialCells',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(821,'2019-09-21 23:18:05.650082','56','AirwayEpitheliumPulmonaryIonocyte',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(822,'2019-09-21 23:21:28.623335','40','BM_PC',2,'[{\"changed\": {\"fields\": [\"organ\", \"assay_type\", \"cells_expected\", \"description\"]}}]',10,1),(823,'2019-09-21 23:23:21.539470','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"organ\", \"cells_expected\"]}}]',10,1),(824,'2019-09-21 23:35:45.469196','22','PMID: 29980650',1,'[{\"added\": {}}]',22,1),(825,'2019-09-21 23:36:17.934544','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"origin_name\", \"publications\"]}}]',10,1),(826,'2019-09-21 23:39:08.625667','39','Kidney biopsy scRNA-seq',2,'[]',10,1),(827,'2019-09-22 00:02:20.224405','23','PMID: 28279351',1,'[{\"added\": {}}]',22,1),(828,'2019-09-22 00:05:07.509507','18','pmid: 29352091',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',22,1),(829,'2019-09-22 00:05:16.678271','18','pmid: 29352091',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',22,1),(830,'2019-09-22 00:06:00.885828','17','pmid: 27864467',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(831,'2019-09-22 00:06:12.587021','22','pmid: 29980650',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',22,1),(832,'2019-09-22 00:06:20.362824','23','pmid: 28279351',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',22,1),(833,'2019-09-22 00:06:34.402134','10','pmid: 31506348',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',22,1),(834,'2019-09-22 00:08:03.299087','16','pmid: 30472193',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(835,'2019-09-22 00:08:32.723762','15','pmid: 29622724',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(836,'2019-09-22 00:09:19.321172','14','pmid: 29225342',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(837,'2019-09-22 00:09:57.138659','13','pmid: 29158510',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(838,'2019-09-22 00:10:36.696596','12','pmid: 29449449',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(839,'2019-09-22 00:11:28.547028','11','pmid: 30069046',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(840,'2019-09-22 00:12:00.470216','8','pmid: 31075224',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(841,'2019-09-22 00:12:44.600285','7','pmid: 31178118',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(842,'2019-09-22 00:13:19.768450','6','pmid: 31320652',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(843,'2019-09-22 00:14:08.226444','5','pmid: 31253076',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(844,'2019-09-22 00:14:38.311404','4','pmid: 31269016',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(845,'2019-09-22 00:15:11.607111','3','pmid: 29167569',2,'[{\"changed\": {\"fields\": [\"title\", \"doi\"]}}]',22,1),(846,'2019-09-22 00:16:46.559560','38','Single cell RNAseq characterization of cell types produced over time',2,'[{\"changed\": {\"fields\": [\"sample_type\"]}}]',10,1),(847,'2019-09-22 00:22:13.339029','38','Single cell RNAseq characterization of cell types produced over time',2,'[{\"changed\": {\"fields\": [\"origin_name\", \"publications\"]}}]',10,1),(848,'2019-09-23 19:49:06.792457','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"origin_name\"]}}]',10,1),(849,'2019-09-23 21:55:17.960193','64','Mouse_J1_scRNA_seq_comparison',2,'[{\"changed\": {\"fields\": [\"sheet_from_lab\", \"description\"]}}]',10,1),(850,'2019-09-24 02:19:41.837429','64','Mouse_J1_scRNA_seq_comparison',2,'[]',10,1),(851,'2019-09-24 02:20:23.220663','47','1M Neurons',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(852,'2019-09-24 02:24:13.082676','39','Kidney biopsy scRNA-seq',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(853,'2019-09-24 02:46:46.886050','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"shared_google_sheet\"]}}]',10,1),(854,'2019-09-24 02:50:36.171833','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(855,'2019-09-24 02:51:38.339115','257','Itai,,Yana',1,'[{\"added\": {}}]',11,1),(856,'2019-09-24 02:51:59.179705','52','HumanMousePancreas',2,'[{\"changed\": {\"fields\": [\"contacts\", \"contributors\"]}}]',10,1),(857,'2019-09-24 04:21:03.566322','40','BM_PC',2,'[{\"changed\": {\"fields\": [\"comments\", \"shared_google_sheet\"]}}]',10,1),(858,'2019-09-24 04:22:48.237547','53','MouseGastrulationAtlas',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\", \"contributors\"]}}]',10,1),(859,'2019-09-24 04:24:51.022017','53','MouseGastrulationAtlas',2,'[]',10,1),(860,'2019-09-24 04:25:36.640309','48','Fetal/Maternal Interface',2,'[{\"changed\": {\"fields\": [\"wrangler1\", \"wrangler2\", \"sheet_that_validated\"]}}]',10,1),(861,'2019-09-24 04:27:11.329878','45','Drop-seq, DroNc-seq, Fluidigm C1 Comparison',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(862,'2019-09-24 04:28:29.416565','33','Multiplexed scRNA-seq with barcoded antibodies',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(863,'2019-09-24 04:30:14.176332','31','Mouse Melanoma',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(864,'2019-09-24 04:32:14.788649','37','Single cell transcriptome analysis of human pancreas',2,'[{\"changed\": {\"fields\": [\"origin_name\", \"sheet_that_validated\"]}}]',10,1),(865,'2019-09-24 04:33:44.944436','49','CD4+ cytotoxic T lymphocytes',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(866,'2019-09-24 04:35:31.700431','36','Healthy and type 2 diabetes pancreas',2,'[{\"changed\": {\"fields\": [\"origin_name\", \"sheet_that_validated\"]}}]',10,1),(867,'2019-09-24 04:37:11.755216','38','Single cell RNAseq characterization of cell types produced over time',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(868,'2019-09-24 17:19:08.936605','8','chris',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,2),(869,'2019-09-24 17:33:25.605123','8','chris',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,2),(870,'2019-09-24 17:38:36.948193','182','Enrique,,Sapena-Ventura',3,'',11,1),(871,'2019-09-24 17:39:02.618814','239','Enrique,Sapena,Ventura',2,'[{\"changed\": {\"fields\": [\"projects\"]}}]',11,1),(872,'2019-09-24 20:05:36.803956','12','cell types',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',12,1),(873,'2019-09-24 20:06:08.754097','11','cell clusters',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',12,1),(874,'2019-09-24 20:06:51.292809','9','primary analysis',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',12,1),(875,'2019-09-25 18:45:08.663428','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(876,'2019-09-25 21:24:43.173000','5','scATAC-seq',3,'',20,1),(877,'2019-09-25 23:24:35.330974','1','starting',1,'[{\"added\": {}}]',47,1),(878,'2019-09-26 00:40:25.229237','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(879,'2019-09-26 00:42:13.225871','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(880,'2019-09-26 00:42:35.876394','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(881,'2019-09-26 00:43:12.154214','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(882,'2019-09-26 00:44:28.635899','41','Human Hematopoietic Profiling',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,1),(883,'2019-09-26 00:46:11.056398','10','Jim-the-Wrangler',1,'[{\"added\": {}}]',4,1),(884,'2019-09-26 00:46:25.012849','10','Jim-the-Wrangler',2,'[{\"changed\": {\"fields\": [\"groups\"]}}]',4,1),(885,'2019-09-26 00:49:19.966478','10','Jim-the-Wrangler',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,1),(886,'2019-09-26 00:49:54.522827','10','Jim-the-Wrangler',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,1),(887,'2019-09-26 00:51:01.136423','10','JimWrangler',2,'[{\"changed\": {\"fields\": [\"username\"]}}]',4,1),(888,'2019-09-26 00:52:13.443599','10','JimWrangler',2,'[{\"changed\": {\"fields\": [\"is_staff\"]}}]',4,1),(889,'2019-09-26 00:55:09.506875','2','wrangling',1,'[{\"added\": {}}]',47,1),(890,'2019-09-26 00:56:22.251571','3','review',1,'[{\"added\": {}}]',47,1),(891,'2019-09-26 00:57:28.194011','4','staged',1,'[{\"added\": {}}]',47,1),(892,'2019-09-26 00:58:39.060831','5','submitted',1,'[{\"added\": {}}]',47,1),(893,'2019-09-26 01:33:13.941025','64','Mouse_J1_scRNA_seq_comparison',2,'[{\"changed\": {\"fields\": [\"sample_type\", \"assay_tech\"]}}]',10,10),(894,'2019-09-26 01:34:12.640749','1','HumanInnateLymphoidCells',2,'[{\"changed\": {\"fields\": [\"status\", \"wrangling_status\"]}}]',10,10),(895,'2019-09-26 01:35:20.885439','6','staged',3,'',13,10),(896,'2019-09-26 01:35:20.886884','5','review',3,'',13,10),(897,'2019-09-26 04:13:08.106703','24','pmid: 28212749',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',22,10),(898,'2019-09-26 04:58:54.551559','258','Filipe,,Pereira',1,'[{\"added\": {}}]',11,10),(899,'2019-09-26 04:59:03.571882','65','Reprogrammed_Dendritic_Cell',1,'[{\"added\": {}}]',10,10),(900,'2019-09-26 05:00:12.774440','65','Reprogrammed_Dendritic_Cells',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',10,10),(901,'2019-09-26 05:05:38.594868','66','snRNA-seq_for_human_retina',1,'[{\"added\": {}}]',10,10),(902,'2019-09-26 05:06:20.633836','65','Reprogrammed_Dendritic_Cells',2,'[{\"changed\": {\"fields\": [\"status\"]}}]',10,10),(903,'2019-09-26 05:10:35.929200','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"status\"]}}]',10,10),(904,'2019-09-26 05:13:14.947881','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"submit_date\"]}}]',10,10),(905,'2019-09-26 05:13:40.689747','65','Reprogrammed_Dendritic_Cells',2,'[{\"changed\": {\"fields\": [\"submit_date\"]}}]',10,10),(906,'2019-09-26 05:14:39.799513','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"effort\"]}}]',10,10),(907,'2019-09-26 05:15:01.799256','65','Reprogrammed_Dendritic_Cells',2,'[{\"changed\": {\"fields\": [\"wrangling_status\", \"effort\"]}}]',10,10),(908,'2019-09-26 05:37:07.014422','3','Jim Kent UC Santa Cruz',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',8,10),(909,'2019-09-26 05:37:38.567599','14','D Pe\'er Lab Sloan Kettering',2,'[{\"changed\": {\"fields\": [\"short_name\"]}}]',8,10),(910,'2019-09-26 17:41:39.830453','1','Jim',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,2),(911,'2019-09-26 17:46:43.868035','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(912,'2019-09-26 17:59:02.516788','65','Reprogrammed_Dendritic_Cells',2,'[{\"changed\": {\"fields\": [\"consent\", \"description\", \"sheet_that_validated\"]}}]',10,1),(913,'2019-09-26 18:00:12.065941','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"description\"]}}]',10,1),(914,'2019-09-26 18:01:21.383707','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"sheet_that_validated\"]}}]',10,1),(915,'2019-09-26 18:02:05.554572','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"consent\"]}}]',10,1),(916,'2019-09-27 18:02:48.672775','11','Galt',1,'[{\"added\": {}}]',4,1),(917,'2019-09-27 18:03:40.699637','11','Galt',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"is_staff\", \"groups\", \"user_permissions\"]}}]',4,1),(918,'2019-10-01 21:09:24.640848','12','gabs',1,'[{\"added\": {}}]',4,2),(919,'2019-10-01 21:10:12.445313','12','gabs',2,'[{\"changed\": {\"fields\": [\"first_name\", \"last_name\", \"email\", \"is_staff\", \"groups\", \"user_permissions\"]}}]',4,2),(920,'2019-10-03 23:55:53.112323','11','Galt',2,'[{\"changed\": {\"fields\": [\"email\"]}}]',4,2),(921,'2019-10-03 23:56:17.556872','11','Galt',2,'[{\"changed\": {\"fields\": [\"password\"]}}]',4,2),(922,'2019-10-08 17:02:41.634564','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"organ_part\", \"disease\"]}}]',10,1),(923,'2019-10-08 17:08:44.981967','259','Rui,,Chen',1,'[{\"added\": {}}]',11,1),(924,'2019-10-08 17:09:12.715799','15','Rui Chen Lab at Baylor',1,'[{\"added\": {}}]',8,1),(925,'2019-10-08 17:12:46.188488','260','Margaret,,DeAngelis',1,'[{\"added\": {}}]',11,1),(926,'2019-10-08 17:12:49.555628','16','DeAngelis Lab University of Utah',1,'[{\"added\": {}}]',8,1),(927,'2019-10-08 17:13:14.449450','259','Rui,,Chen',2,'[{\"changed\": {\"fields\": [\"type\"]}}]',11,1),(928,'2019-10-08 17:19:54.381530','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"labs\"]}}]',10,1),(929,'2019-10-08 18:38:01.399935','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"cells_expected\"]}}]',10,10),(930,'2019-10-08 19:11:24.976186','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(931,'2019-10-08 19:11:35.699586','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(932,'2019-10-08 19:12:01.992768','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(933,'2019-10-08 19:13:05.107545','1','preview',1,'[{\"added\": {}}]',48,1),(934,'2019-10-08 19:14:06.918168','2','soft launch',1,'[{\"added\": {}}]',48,1),(935,'2019-10-08 19:15:43.856404','3','Barcelona incentives',1,'[{\"added\": {}}]',48,1),(936,'2019-10-08 19:16:06.452791','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"tags\"]}}]',10,1),(937,'2019-10-08 19:27:11.426784','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(938,'2019-10-08 19:27:31.819882','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(939,'2019-10-08 19:27:48.436340','1','wranglers',2,'[]',3,1),(940,'2019-10-08 21:14:30.882132','1','fresh',1,'[{\"added\": {}}]',49,1),(941,'2019-10-08 21:16:12.685066','1','primary tissue',2,'[{\"changed\": {\"fields\": [\"short_name\", \"description\"]}}]',19,1),(942,'2019-10-08 21:17:37.704240','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(943,'2019-10-08 21:18:19.327194','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(944,'2019-10-08 21:18:40.636538','2','readers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(945,'2019-10-08 21:18:52.608096','3','pipeliners',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(946,'2019-10-08 21:19:23.979290','66','snRNA-seq_for_human_retina',2,'[{\"changed\": {\"fields\": [\"preservation_method\"]}}]',10,1),(947,'2019-10-08 22:41:18.083071','261','A,Test,Case',1,'[{\"added\": {}}]',11,1),(948,'2019-10-08 22:41:34.625665','261','A,Test,Case',3,'',11,1),(949,'2019-10-09 19:05:34.715125','1','wranglers',2,'[{\"changed\": {\"fields\": [\"permissions\"]}}]',3,1),(950,'2019-10-09 22:42:12.966402','16','cel-seq2',1,'[{\"added\": {}}]',20,1),(951,'2019-10-09 22:43:44.603467','17','sci-rna-seq',1,'[{\"added\": {}}]',20,1),(952,'2019-10-09 22:45:05.214753','18','seq-well',1,'[{\"added\": {}}]',20,1),(953,'2019-10-09 22:50:59.609728','67','scRNAseqSystemicComparison',1,'[{\"added\": {}}]',10,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(2,'auth','permission'),(3,'auth','group'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(7,'hcat','funder'),(8,'hcat','lab'),(9,'hcat','grant'),(10,'hcat','project'),(11,'hcat','contributor'),(12,'hcat','projectstate'),(13,'hcat','projectstatus'),(14,'hcat','organpart'),(15,'hcat','consent'),(16,'hcat','species'),(17,'hcat','disease'),(18,'hcat','organ'),(19,'hcat','sampletype'),(20,'hcat','cdnalibraryprep'),(21,'hcat','assaytype'),(22,'hcat','publication'),(23,'hcat','commenttype'),(24,'hcat','comment'),(25,'hcat','projectsourcetype'),(26,'hcat','file'),(27,'hcat','url'),(42,'hcat','contributortype'),(43,'hcat','wrangler'),(44,'hcat','intern'),(45,'hcat','softwaredeveloper'),(46,'hcat','tracker'),(47,'hcat','wranglingstatus'),(48,'hcat','tag'),(49,'hcat','preservationmethod');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-08-29 06:48:44.665486'),(2,'auth','0001_initial','2019-08-29 06:48:46.039320'),(3,'admin','0001_initial','2019-08-29 06:48:46.276716'),(4,'admin','0002_logentry_remove_auto_add','2019-08-29 06:48:46.295344'),(5,'admin','0003_logentry_add_action_flag_choices','2019-08-29 06:48:46.326955'),(6,'contenttypes','0002_remove_content_type_name','2019-08-29 06:48:46.356378'),(7,'auth','0002_alter_permission_name_max_length','2019-08-29 06:48:46.364176'),(8,'auth','0003_alter_user_email_max_length','2019-08-29 06:48:46.383012'),(9,'auth','0004_alter_user_username_opts','2019-08-29 06:48:46.399027'),(10,'auth','0005_alter_user_last_login_null','2019-08-29 06:48:46.416002'),(11,'auth','0006_require_contenttypes_0002','2019-08-29 06:48:46.417595'),(12,'auth','0007_alter_validators_add_error_messages','2019-08-29 06:48:46.431244'),(13,'auth','0008_alter_user_username_max_length','2019-08-29 06:48:46.448491'),(14,'auth','0009_alter_user_last_name_max_length','2019-08-29 06:48:46.462102'),(15,'sessions','0001_initial','2019-08-29 06:48:46.529519'),(16,'hcat','0001_initial','2019-08-29 06:57:14.871087'),(17,'hcat','0002_auto_20190829_0853','2019-08-29 08:54:07.772450'),(18,'hcat','0003_auto_20190829_1841','2019-08-29 18:42:03.238850'),(19,'hcat','0004_auto_20190829_1844','2019-08-29 18:48:51.586660'),(20,'hcat','0005_auto_20190829_1856','2019-08-29 18:56:19.813841'),(21,'hcat','0006_auto_20190829_1204','2019-08-29 19:05:07.390000'),(22,'hcat','0007_auto_20190829_1220','2019-08-29 19:20:53.813691'),(23,'hcat','0008_auto_20190829_1233','2019-08-29 19:42:34.989974'),(24,'hcat','0009_auto_20190829_1308','2019-08-29 20:10:24.977260'),(25,'hcat','0010_auto_20190829_1323','2019-08-29 20:31:18.689521'),(26,'hcat','0011_auto_20190829_1332','2019-08-29 20:32:35.329449'),(27,'hcat','0012_auto_20190829_1348','2019-08-29 20:48:18.083952'),(28,'hcat','0013_auto_20190829_1416','2019-08-29 21:16:19.943293'),(29,'hcat','0014_auto_20190829_1420','2019-08-29 21:20:55.414067'),(30,'hcat','0015_auto_20190829_1438','2019-08-29 21:38:44.807984'),(31,'hcat','0016_auto_20190829_1505','2019-08-29 22:05:06.105677'),(32,'hcat','0017_auto_20190829_1506','2019-08-29 22:06:51.511222'),(33,'hcat','0018_auto_20190829_1518','2019-08-29 22:18:57.360974'),(34,'hcat','0019_auto_20190829_1540','2019-08-29 22:40:58.813524'),(35,'hcat','0020_auto_20190829_1542','2019-08-29 22:42:45.725585'),(36,'hcat','0021_auto_20190829_1544','2019-08-29 22:44:37.062088'),(37,'hcat','0022_auto_20190829_1701','2019-08-30 00:01:26.586306'),(38,'hcat','0023_auto_20190829_1713','2019-08-30 00:13:44.086494'),(39,'hcat','0024_auto_20190829_1757','2019-08-30 00:57:39.236781'),(40,'hcat','0002_auto_20190829_2134','2019-08-30 04:34:40.487598'),(41,'hcat','0003_auto_20190829_2147','2019-08-30 04:48:16.379372'),(42,'hcat','0004_auto_20190829_2155','2019-08-30 04:55:55.451780'),(43,'hcat','0005_auto_20190829_2158','2019-08-30 04:58:38.973646'),(44,'hcat','0006_auto_20190829_2200','2019-08-30 05:00:15.455953'),(45,'hcat','0007_auto_20190829_2201','2019-08-30 05:02:08.455225'),(46,'hcat','0008_auto_20190829_2229','2019-08-30 05:29:53.610833'),(47,'hcat','0009_vocabcommenttype','2019-08-30 14:37:49.342814'),(48,'hcat','0010_vocabcomment','2019-08-30 14:41:24.537844'),(49,'hcat','0011_auto_20190830_0754','2019-08-30 14:54:15.888852'),(50,'hcat','0012_auto_20190830_1054','2019-08-30 18:08:56.680020'),(51,'hcat','0013_auto_20190830_1224','2019-08-30 19:25:05.517407'),(52,'hcat','0014_auto_20190830_1240','2019-08-30 19:41:12.900033'),(53,'hcat','0015_auto_20190830_1328','2019-08-30 20:28:22.098316'),(54,'hcat','0002_auto_20190830_1621','2019-08-30 23:24:06.308207'),(55,'hcat','0003_auto_20190830_1624','2019-08-30 23:27:54.808776'),(56,'hcat','0002_vocaburl','2019-08-30 23:42:10.492070'),(57,'hcat','0003_vocabfile','2019-08-30 23:42:31.898209'),(58,'hcat','0004_auto_20190830_1740','2019-08-31 00:40:27.077305'),(59,'hcat','0005_auto_20190830_1746','2019-08-31 00:46:12.980036'),(60,'hcat','0006_auto_20190830_1757','2019-08-31 00:57:36.673978'),(61,'hcat','0007_auto_20190830_1851','2019-08-31 01:51:19.032455'),(62,'hcat','0008_auto_20190830_1854','2019-08-31 01:54:13.404934'),(63,'hcat','0009_auto_20190830_1855','2019-08-31 02:03:16.797111'),(64,'hcat','0002_auto_20190830_1918','2019-08-31 03:30:10.305452'),(65,'hcat','0002_auto_20190830_2344','2019-08-31 06:44:56.350799'),(66,'hcat','0003_auto_20190831_0009','2019-08-31 07:09:17.635601'),(67,'hcat','0004_project_staging_area','2019-08-31 15:11:49.124724'),(68,'hcat','0005_auto_20190831_0842','2019-08-31 15:42:10.019135'),(69,'hcat','0006_auto_20190831_0921','2019-08-31 16:22:13.840710'),(70,'hcat','0007_remove_project_metadataexcel','2019-08-31 19:21:35.502013'),(71,'hcat','0008_auto_20190831_1227','2019-08-31 19:27:34.680477'),(72,'hcat','0009_auto_20190831_1234','2019-08-31 19:34:28.224285'),(73,'hcat','0010_auto_20190831_1244','2019-08-31 19:44:51.042403'),(74,'hcat','0011_auto_20190831_1245','2019-08-31 19:45:40.024607'),(75,'hcat','0012_auto_20190831_1252','2019-08-31 19:52:04.531189'),(76,'hcat','0002_project_submit_comments','2019-08-31 20:12:59.334644'),(77,'hcat','0003_auto_20190831_1319','2019-08-31 20:19:29.125543'),(78,'hcat','0004_auto_20190831_1400','2019-08-31 21:01:12.298377'),(79,'hcat','0002_project_organ','2019-08-31 21:10:43.404936'),(80,'hcat','0003_project_submit_comments','2019-08-31 21:16:48.828004'),(81,'hcat','0004_auto_20190831_1534','2019-08-31 22:34:27.587226'),(82,'hcat','0005_auto_20190831_1554','2019-08-31 22:54:39.261726'),(83,'hcat','0006_auto_20190831_1555','2019-08-31 22:55:57.347122'),(84,'hcat','0007_auto_20190831_1600','2019-08-31 23:00:55.548341'),(85,'hcat','0008_auto_20190903_1021','2019-09-03 17:22:05.085638'),(86,'hcat','0009_contributor_department','2019-09-03 18:07:39.146400'),(87,'hcat','0010_contributor_institute','2019-09-03 18:08:58.616039'),(88,'hcat','0002_auto_20190904_1418','2019-09-04 21:18:58.395448'),(89,'hcat','0002_auto_20190904_1539','2019-09-04 22:40:08.423768'),(90,'hcat','0003_auto_20190904_1545','2019-09-04 22:45:32.944355'),(91,'hcat','0004_remove_contributor_project_role','2019-09-04 23:25:37.134621'),(92,'hcat','0005_contributortype','2019-09-04 23:34:26.515674'),(93,'hcat','0006_contributor_type','2019-09-04 23:34:26.619163'),(94,'hcat','0007_auto_20190904_1757','2019-09-05 00:58:45.557906'),(95,'hcat','0008_auto_20190904_1758','2019-09-05 00:58:45.623877'),(96,'hcat','0009_auto_20190904_1803','2019-09-05 01:04:00.507423'),(97,'hcat','0010_remove_lab_contact','2019-09-05 01:27:18.229310'),(98,'hcat','0011_lab_contacts','2019-09-05 01:31:30.776411'),(99,'hcat','0012_auto_20190904_1841','2019-09-05 01:41:10.481898'),(100,'hcat','0013_remove_lab_contacts','2019-09-05 01:43:32.494493'),(101,'hcat','0014_wrangler','2019-09-05 02:09:42.208772'),(102,'hcat','0015_auto_20190904_1921','2019-09-05 02:21:27.465071'),(103,'hcat','0016_project_wrangler1','2019-09-05 02:25:14.075281'),(104,'hcat','0017_auto_20190904_1925','2019-09-05 02:25:14.239012'),(105,'hcat','0018_auto_20190904_1949','2019-09-05 02:49:24.129813'),(106,'hcat','0019_auto_20190904_2111','2019-09-05 04:12:22.443361'),(107,'hcat','0020_auto_20190904_2122','2019-09-05 04:22:20.186794'),(108,'hcat','0021_auto_20190904_2129','2019-09-05 04:29:30.545058'),(109,'hcat','0022_auto_20190904_2132','2019-09-05 04:33:09.259662'),(110,'hcat','0023_auto_20190904_2134','2019-09-05 04:34:52.462443'),(111,'hcat','0024_project_chat_url','2019-09-05 04:58:22.369485'),(112,'hcat','0025_auto_20190906_1038','2019-09-06 17:38:32.820019'),(113,'hcat','0026_auto_20190906_1039','2019-09-06 17:39:32.352124'),(114,'hcat','0027_auto_20190906_1140','2019-09-06 18:40:33.798025'),(115,'hcat','0028_auto_20190906_1152','2019-09-06 18:52:41.934739'),(116,'hcat','0029_auto_20190906_1334','2019-09-06 20:34:46.004094'),(117,'hcat','0030_auto_20190906_1346','2019-09-06 20:46:31.792182'),(118,'hcat','0002_project_uuid','2019-09-13 01:46:08.707561'),(119,'hcat','0003_remove_project_uuid','2019-09-14 18:50:18.136979'),(120,'hcat','0004_tracker','2019-09-14 19:06:16.689160'),(121,'hcat','0005_auto_20190914_1205','2019-09-14 19:06:16.820546'),(122,'hcat','0006_auto_20190914_1218','2019-09-14 19:18:20.799111'),(123,'hcat','0007_auto_20190914_1253','2019-09-14 20:14:12.901733'),(124,'hcat','0008_auto_20190914_1314','2019-09-14 20:14:13.278547'),(125,'hcat','0002_auto_20190917_1149','2019-09-17 18:49:50.603337'),(126,'hcat','0002_auto_20190918_1904','2019-09-19 02:05:16.368036'),(127,'hcat','0003_auto_20190918_1915','2019-09-19 02:15:23.195017'),(128,'hcat','0004_auto_20190918_1918','2019-09-19 02:18:31.353770'),(129,'hcat','0002_auto_20190925_1619','2019-09-25 23:20:39.692161'),(130,'hcat','0003_auto_20190925_1725','2019-09-26 00:25:23.641034'),(131,'hcat','0004_auto_20190925_1727','2019-09-26 00:27:48.214973'),(132,'hcat','0005_auto_20190925_1731','2019-09-26 00:32:00.866265'),(133,'hcat','0006_auto_20190925_1734','2019-09-26 00:34:18.546325'),(134,'hcat','0007_auto_20190925_1735','2019-09-26 00:35:12.425997'),(135,'hcat','0008_auto_20190925_1811','2019-09-26 01:12:03.826363'),(136,'hcat','0009_auto_20190925_1816','2019-09-26 01:17:32.328719'),(137,'hcat','0010_auto_20190925_1817','2019-09-26 01:18:02.163330'),(138,'hcat','0011_auto_20190927_1916','2019-10-08 18:34:55.490468'),(139,'hcat','0012_auto_20191008_1134','2019-10-08 18:34:55.762276'),(140,'hcat','0013_auto_20191008_1201','2019-10-08 19:01:46.820110'),(141,'hcat','0014_auto_20191008_1225','2019-10-08 19:25:09.974175'),(142,'hcat','0015_auto_20191008_1226','2019-10-08 19:26:42.149289'),(143,'hcat','0016_auto_20191008_1248','2019-10-08 19:48:06.670683'),(144,'hcat','0017_auto_20191008_1342','2019-10-08 20:42:51.694716'),(145,'hcat','0018_auto_20191008_1346','2019-10-08 20:47:02.221162'),(146,'hcat','0019_auto_20191008_1351','2019-10-08 20:51:41.366152'),(147,'hcat','0020_auto_20191008_1409','2019-10-08 21:10:17.902688'),(148,'hcat','0021_auto_20191016_1025','2019-10-16 17:25:35.949524');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('hl8j4pwo9brgapaytsrscebvirh21k3d','NmQwY2FkYmUyMzlhYmQ5NmI5NWYxMmQzMzYwNDgxN2FkMmNmYTk5Yzp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJiMWRlYWQxNzgzYmJhODA2NjYzNjNhMjE2NjdiZjc2MjUzMTBiMjliIn0=','2019-09-13 07:45:14.488032'),('zjjdohocc07s9jmhfa8evn2qhi3qmz25','MWE2NDMzYzcwYzM2YTcxOGViNmVlMDlkMDllODg2ZDVlZTJmNmUyZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmYjhlYmVjNjcwYmU5NjBiMGZmN2I2MmM4YmQ1ODUyODE1YTM5NGQyIn0=','2019-09-12 16:56:30.210003'),('7cx0iapi5glkjswnyzkyjbs6hcu6l04d','MWE2NDMzYzcwYzM2YTcxOGViNmVlMDlkMDllODg2ZDVlZTJmNmUyZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmYjhlYmVjNjcwYmU5NjBiMGZmN2I2MmM4YmQ1ODUyODE1YTM5NGQyIn0=','2019-09-12 22:14:48.325904'),('bm74ed724r4f4vj832zw2h0kqufffv1x','ZDMxNGM3ODRmNTA5MTU3YTQxNDU1MWM4MGJmZWVlN2EwYjhlZmU5NDp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1ZWJjZTU2YjljZmY4ZTY1YzcwZDIyODg1NzEyYjc1M2UxYjQyNTdjIn0=','2019-09-13 02:25:22.515905'),('o92bxi4qgybg8xkxisud2cfqkayf4cuu','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-13 07:02:18.285840'),('4zhjuu6kdxg14n1nfvtt6gk3am141kqg','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-13 13:48:17.034847'),('pmb0j51c4gfeljo8zth0704zqv5r0x5j','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-13 14:01:30.418464'),('klt5zkbpwewwcq8k01n7pxu236wq1rmj','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-13 17:23:44.744366'),('ea02sw9wq37nqnjk8sakphhu3ucr3m1i','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-13 19:13:04.888416'),('0x7vyucfjbfe31zvl19udsg4pd7ixwof','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-13 19:50:15.576402'),('w5wn6hpijs51zlzdbf1zzszs92muone7','ZDMxNGM3ODRmNTA5MTU3YTQxNDU1MWM4MGJmZWVlN2EwYjhlZmU5NDp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1ZWJjZTU2YjljZmY4ZTY1YzcwZDIyODg1NzEyYjc1M2UxYjQyNTdjIn0=','2019-09-17 19:38:12.883492'),('nfakioivs4eap9v1hrkomk9stqgs36i2','MGIzYzFmOTdlYjI2MWRhODk1ZGYwYzEwZTRhYjUyNDllY2I1YWJkMzp7Il9hdXRoX3VzZXJfaWQiOiI4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIwZThiMGY5MWJiNmY2NzljYjI3ZDVkNGEyOWY5ZjIzZjhkYTYwMzA1In0=','2019-09-19 20:23:25.591722'),('hthwedmn2i8kvqny4dm23h64acfp4n5q','ZDMxNGM3ODRmNTA5MTU3YTQxNDU1MWM4MGJmZWVlN2EwYjhlZmU5NDp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1ZWJjZTU2YjljZmY4ZTY1YzcwZDIyODg1NzEyYjc1M2UxYjQyNTdjIn0=','2019-09-20 15:49:35.514146'),('zpr58rx5xx4fibm28f8bslwaeic6omjg','OTc5MjgyODcxNGU3ZmQ5ZjgxMmRmYjVmZDU3ZGI4NDVhMGQ4MTEwYjp7Il9hdXRoX3VzZXJfaWQiOiI4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlNDdlYWRhZGU4NjlmNjgxYmFlMzlkMmViYzIxMmEwY2YwMTRiZTkxIn0=','2019-09-19 20:25:14.513417'),('cqbamje8qny3rrctgimrhmo9bjs45iun','MWE2NDMzYzcwYzM2YTcxOGViNmVlMDlkMDllODg2ZDVlZTJmNmUyZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmYjhlYmVjNjcwYmU5NjBiMGZmN2I2MmM4YmQ1ODUyODE1YTM5NGQyIn0=','2019-09-27 02:57:21.289873'),('qbquzchiq2x52yu6ri0d8lw4y3b8xywx','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-28 02:09:59.078887'),('dv0ifutad8kn3ewwoyoa45lp8sxjwq0j','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-09-28 18:24:28.187306'),('tvcqohsg13vl2b69dx1uygnb6uw8i77o','OTQwYmZkOGY1MzA2NmU5YzgwNDMzMDY2MTk3YmY3MGI1MzY1NzUzNjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJjMWFiNzQ3MzIxNGYyNzNhMDA3ZDEyZmU4MWRjMjEzOTJjMzVlM2Y0In0=','2019-10-10 00:49:54.528522'),('2yutnqan1g46pqhirb9usxfhnk1zqtq7','OWFlYWQwODQ5Y2NlMTkyZTM2ZWI4M2IzYTA2NGZhNDMxZWMxOTY3Yzp7Il9hdXRoX3VzZXJfaWQiOiI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0MDhiNzk2ZmE5ODE5OGE2ZjFmMDYzMjdlODA0YWFmMWQ4MTNlMjdhIn0=','2019-09-30 17:59:54.867713'),('553ziuxjao44gu040ed94un49jjhirut','OWFlYWQwODQ5Y2NlMTkyZTM2ZWI4M2IzYTA2NGZhNDMxZWMxOTY3Yzp7Il9hdXRoX3VzZXJfaWQiOiI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0MDhiNzk2ZmE5ODE5OGE2ZjFmMDYzMjdlODA0YWFmMWQ4MTNlMjdhIn0=','2019-09-29 01:43:58.855814'),('g4rxwkqm7d8qv5d47wqd1sla4usylnxf','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-10 17:43:20.811850'),('4ee64s7j9tahra8jz3mweca70inhyarg','YTAxYjg1ZDEyY2E2MWQzYWE3NWJmNDczNDk3ZGI4NjI0ZDliNDc3Mjp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWUwNTNhNThjZGI0OGFhN2YzZjU2OGI0YTY5Y2U4NzQxMzRlZjY3OCJ9','2019-10-18 00:15:41.854509'),('tfevzlj6622chierclvz9kf64pree4xc','OTY0ZmZiNDZhZTJlNWQxOGQ3YTlhZjAwY2FmYWM4NzhmYWNmOGEyYzp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYzc1NjExMTVmNjE0MTg1OTJlNWM3MzUxMThjNmEwOTBlMGQ2ZGQxIn0=','2019-10-01 21:33:11.976346'),('tw3pv0s6b5w732xn26i32jf4qmcm1hsf','OTY0ZmZiNDZhZTJlNWQxOGQ3YTlhZjAwY2FmYWM4NzhmYWNmOGEyYzp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYzc1NjExMTVmNjE0MTg1OTJlNWM3MzUxMThjNmEwOTBlMGQ2ZGQxIn0=','2019-10-02 18:37:10.897347'),('8flgruwl167rqacsstyq2k0p4y56tptw','OTY0ZmZiNDZhZTJlNWQxOGQ3YTlhZjAwY2FmYWM4NzhmYWNmOGEyYzp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYzc1NjExMTVmNjE0MTg1OTJlNWM3MzUxMThjNmEwOTBlMGQ2ZGQxIn0=','2019-10-02 18:39:41.608741'),('f0l2xv3lsnxdxia4dwvp4vod42ymv4rq','OWFlYWQwODQ5Y2NlMTkyZTM2ZWI4M2IzYTA2NGZhNDMxZWMxOTY3Yzp7Il9hdXRoX3VzZXJfaWQiOiI5IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0MDhiNzk2ZmE5ODE5OGE2ZjFmMDYzMjdlODA0YWFmMWQ4MTNlMjdhIn0=','2019-10-07 20:52:40.743589'),('zrxjheps71rr1q51wc4id34relhxb8je','ZDMxNGM3ODRmNTA5MTU3YTQxNDU1MWM4MGJmZWVlN2EwYjhlZmU5NDp7Il9hdXRoX3VzZXJfaWQiOiI0IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1ZWJjZTU2YjljZmY4ZTY1YzcwZDIyODg1NzEyYjc1M2UxYjQyNTdjIn0=','2019-10-08 13:26:52.824420'),('vpmw34mcvddywp0lr74f0g16acplw3bi','MGMyYTkxYjQyNmIyZjczZDVhNjFlNTEzNGZlNmRjNTZlNTY5NjQ3ZDp7Il9hdXRoX3VzZXJfaWQiOiI4IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmZjI4YzU3NDUyODJjOWVhZjY0YjUzOTJkMWJlY2M2NDM3ZTM2YzQ1In0=','2019-10-08 17:41:03.870520'),('z0bs8ksyb510omib3j2xd2k03qjyc4mb','NjkzOWJkMDBkZjM4YTI4NzIzYzgxODkzOGVlMTQ2YTkwMDU1OTAwMDp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTEyODlkZjI1NTA3ODJlOTc0MWIxNmIzN2EyOTAxNzdlMWQ1MDEzNiJ9','2019-10-10 00:52:24.587559'),('x84ichj5vdwfsaundvr2uxm78iz7jgk6','NjkzOWJkMDBkZjM4YTI4NzIzYzgxODkzOGVlMTQ2YTkwMDU1OTAwMDp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTEyODlkZjI1NTA3ODJlOTc0MWIxNmIzN2EyOTAxNzdlMWQ1MDEzNiJ9','2019-10-10 01:04:06.825482'),('aepxfx6rauplm8tniwz895rf96cs9quq','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-10 17:45:41.538737'),('lhmy8qn4up3fu4jb8nx4f5xqvfgnef4p','MWE2NDMzYzcwYzM2YTcxOGViNmVlMDlkMDllODg2ZDVlZTJmNmUyZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmYjhlYmVjNjcwYmU5NjBiMGZmN2I2MmM4YmQ1ODUyODE1YTM5NGQyIn0=','2019-10-10 17:41:39.851539'),('o00xkqnsljzm6nv1no4kaaqktirvnfkz','NjkzOWJkMDBkZjM4YTI4NzIzYzgxODkzOGVlMTQ2YTkwMDU1OTAwMDp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTEyODlkZjI1NTA3ODJlOTc0MWIxNmIzN2EyOTAxNzdlMWQ1MDEzNiJ9','2019-10-22 17:03:42.640113'),('pw3404c0f5ydf5jvondn1jqcy8cayt9c','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-10 17:52:50.872744'),('mvr7uirez3q1mwyp6cr7hrpeny2g9pwz','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-10 17:53:50.484557'),('h30hfonr61380egsxqzv85liaji28zfx','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-12 02:15:24.330919'),('bagq2tkg9klv07xt1qlyupwwbsnyppri','OTY0ZmZiNDZhZTJlNWQxOGQ3YTlhZjAwY2FmYWM4NzhmYWNmOGEyYzp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYzc1NjExMTVmNjE0MTg1OTJlNWM3MzUxMThjNmEwOTBlMGQ2ZGQxIn0=','2019-10-17 17:58:47.035788'),('1mkd7bmpu2paozir09b4rf12i4kj5k77','MWE2NDMzYzcwYzM2YTcxOGViNmVlMDlkMDllODg2ZDVlZTJmNmUyZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmYjhlYmVjNjcwYmU5NjBiMGZmN2I2MmM4YmQ1ODUyODE1YTM5NGQyIn0=','2019-10-17 23:56:17.565172'),('vsu5xz46kw0hgq13rta4rtndytf12plk','OTY0ZmZiNDZhZTJlNWQxOGQ3YTlhZjAwY2FmYWM4NzhmYWNmOGEyYzp7Il9hdXRoX3VzZXJfaWQiOiI3IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYzc1NjExMTVmNjE0MTg1OTJlNWM3MzUxMThjNmEwOTBlMGQ2ZGQxIn0=','2019-10-21 20:55:01.999954'),('71k1zybbn9zppjkf6wvlxil2kn7v0b16','MjNhOThmOWVmMzU4YTUyOWRkMGM2NDI4YWZhNTg3MWRhYjRkOWM3ODp7Il9hdXRoX3VzZXJfaWQiOiIxMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMDUwN2NiZDAyOTFlNTRhYTIyZTU4YjcyNTdhMjRkM2NiODlkN2I0YSJ9','2019-10-18 20:58:13.550293'),('8o5yx7okj7pe9szk2n5937k7z9yd6tya','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-22 16:56:28.106825'),('e7ow35qul4bdhgrhkhjayvbwfhgdx5sl','NjkzOWJkMDBkZjM4YTI4NzIzYzgxODkzOGVlMTQ2YTkwMDU1OTAwMDp7Il9hdXRoX3VzZXJfaWQiOiIxMCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiNTEyODlkZjI1NTA3ODJlOTc0MWIxNmIzN2EyOTAxNzdlMWQ1MDEzNiJ9','2019-10-22 18:36:39.623122'),('2sogy6o6tvp4fpekkl5f25ufhvzqg80h','OTc1YzA0NjAxNGMzYjkwNzY0ZmI5MTgwYWFiMjZiMjc5YTRmNzZkNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzNmIxNjkwMTVmNjllMGFjZWFiNmMyNGE5ZTZkMmQ3YTMwZTUwZjg3In0=','2019-10-22 19:10:39.928275');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_cdnalibraryprep`
--

DROP TABLE IF EXISTS `hcat_cdnalibraryprep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_cdnalibraryprep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_assaytech_short_name_fc7a5a4b_uniq` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_cdnalibraryprep`
--

LOCK TABLES `hcat_cdnalibraryprep` WRITE;
/*!40000 ALTER TABLE `hcat_cdnalibraryprep` DISABLE KEYS */;
INSERT INTO `hcat_cdnalibraryprep` VALUES (1,'10x Chromium V2','10x single-cell sequencing Chromium V2 chemistry',''),(2,'smart-seq2 PE','smart-seq2 library prep paired end sequencing of single cells',''),(3,'smart-seq2 SE','smart-seq2 library prep single ended sequencing of single cells',''),(4,'bulk RNA','bulk RNA sequencing of some sort, not single cell',''),(6,'bulk DNA','sequencing of bulk, non-single-cell, DNA',''),(7,'C1 SMARTer-seq','SMARTer-seq RNA protocol on Fluidigm C1 microfluidics chip',''),(8,'inDrop','A droplet based single cell RNA sequencing method now sold by 1cellbio',''),(9,'mars-seq','A plate-based single cell RNA sequencing assay with kits available from Illumina',''),(10,'cite-seq','Measures levels of surface proteins and RNA levels in the same cell. Satija lab.',''),(11,'dronc-seq','A droplet-based single nuclei sequencing method from Regev lab',''),(12,'drop-seq','The classic free do-it-yourself droplet based single cell sequencing method',''),(13,'10x Chromium V1','Early version of 10x RNA-sequencing.  The fastq files are different beware!',''),(14,'10x Chromium V3','10x\'s 2019 ssRNA-seq kit. Improves sensitivity and adds 2 bases to UMI barcode',''),(15,'sn-RNA-seq','single-nucleus RNA sequencing',''),(16,'cel-seq2','sensitive highly-multiplexed single-cell RNA-Seq',''),(17,'sci-rna-seq','single-cell combinatorial indexing RNA sequencing',''),(18,'seq-well','Seq-Well is a portable, low-cost platform for single-cell RNA sequencing designed to be compatible with low-input, clinical biopsies.','');
/*!40000 ALTER TABLE `hcat_cdnalibraryprep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_cdnalibraryprep_projects`
--

DROP TABLE IF EXISTS `hcat_cdnalibraryprep_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_cdnalibraryprep_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cdnalibraryprep_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_assaytech_projects_assaytech_id_project_id_82eea493_uniq` (`cdnalibraryprep_id`,`project_id`),
  KEY `hcat_assaytech_projects_assaytech_id_47be4cfd` (`cdnalibraryprep_id`),
  KEY `hcat_assaytech_projects_project_id_209d1898` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_cdnalibraryprep_projects`
--

LOCK TABLES `hcat_cdnalibraryprep_projects` WRITE;
/*!40000 ALTER TABLE `hcat_cdnalibraryprep_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_cdnalibraryprep_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_consent`
--

DROP TABLE IF EXISTS `hcat_consent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_consent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_consent_short_name_9a57e804_uniq` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_consent`
--

LOCK TABLES `hcat_consent` WRITE;
/*!40000 ALTER TABLE `hcat_consent` DISABLE KEYS */;
INSERT INTO `hcat_consent` VALUES (1,'already openly published','This dataset already exists on the internet in a public manner,  perhaps at EBI\'s ENA or NCBI\'s SRA or GEO',''),(2,'nonhuman data','Data is from mice or other model organisms',''),(3,'consented','Consented human data',''),(4,'dubious','Someone has looked at the consent and been unable to determine if it is sufficient.  Further research advised.',''),(5,'unconsented','Don\'t work on unconsented stuff, it\'ll break your heart','');
/*!40000 ALTER TABLE `hcat_consent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_contributor`
--

DROP TABLE IF EXISTS `hcat_contributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_contributor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(128) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `zip_postal_code` varchar(20) NOT NULL,
  `department` varchar(255) NOT NULL,
  `institute` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_contributor_name_7ba24c2b_uniq` (`name`),
  KEY `hcat_contributor_type_id_f4337177` (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=262 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_contributor`
--

LOCK TABLES `hcat_contributor` WRITE;
/*!40000 ALTER TABLE `hcat_contributor` DISABLE KEYS */;
INSERT INTO `hcat_contributor` VALUES (1,'Asa,Kristina,Bjorklund','asa.bjorklund@scilifelab.se','','','Uppsala','Sweden','','','','',1),(2,'Mjösberg,J,M','','','','','','','','','',4),(3,'Clay,M,Fischer','clayfischer@ucsc.edu','','','','','','','','',2),(4,'W,James,Kent','jimkent@ucsc.edu','','','Santa Cruz','','','','','Crotchety old hermit',2),(5,'Parisa,,Nejad','pnejad@ucsc.edu','','','','','','','','',2),(6,'William,G,Sullivan','wisulliv@ucsc.edu','','','','','','','','',2),(7,'Christopher,,Villarreal','cjvillar@ucsc.edu','','','','','','','','',2),(8,'Alex,,Pollen','Alex.Pollen@ucsf.edu','','','San Francisco','','','','','',1),(10,'Fiona,,Hamey','','','','','','','','','',3),(11,'Dimitris,,Karamitros','','','','','','','','','',3),(12,'Bilyana,,Stoilova','','','','','','','','','',3),(13,'Lindsey,W,Plasschaert','','','','','','','','','',3),(14,'Rapolas,,Zilionis','','','','','','','','','',3),(15,'Rayman,,Choo-Wing','','','','','','','','','',3),(16,'Virginia,,Savova','','','','','','','','','',3),(17,'Judith,,Knehr','','','','','','','','','',3),(18,'Guglielmo,,Roma','','','','','','','','','',3),(19,'Allon,M,Klein','','','','','','','','','',3),(20,'Aron,B,Jaffe','','','','','','','','','',3),(21,'Simone,,Picelli','','','','','','','','','',3),(22,'Marianne,,Forkel','','','','','','','','','',3),(23,'Rickard,,Sandberg','','','','','','','','','',3),(24,'Spyros,,Darmanis','','','','','','','','','',3),(25,'Stephen,R,Quake','','','','','','','','','',4),(26,'Daniel,T,Montoro','','','','','','','','','',3),(27,'Adam,L,Haber','','','','','','','','','',3),(28,'Moshe,,Biton','','','','','','','','','',3),(29,'Vladimir,,Vinarsky','','','','','','','','','',3),(30,'Sijia,,Chen','','','','','','','','','',3),(31,'Jorge,,Villoria','','','','','','','','','',3),(32,'Noga,,Rogel','','','','','','','','','',3),(33,'Purushothama,,Rao Tata','','','','','','','','','',3),(34,'Steven,M,Rowe','','','','','','','','','',3),(35,'John,F,Engelhardt','','','','','','','','','',3),(37,'Aviv,,Regev','','','','','','','','','',4),(38,'Jayaraj,,Rajagopal','','','','','','','','','',3),(39,'Brian,,Lin','','','','','','','','','',3),(40,'Susan,,Birket','','','','','','','','','',3),(41,'Feng,,Yuan','','','','','','','','','',3),(42,'Hui Min,,Leung','','','','','','','','','',3),(43,'Grace,,Burgin','','','','','','','','','',3),(44,'Alexander,,Tsankov','','','','','','','','','',3),(45,'Avinash,,Waghray','','','','','','','','','',3),(46,'Michal,,Slyper','','','','','','','','','',3),(47,'Julia,,Waldman','','','','','','','','','',3),(48,'Lan,,Nguyen','','','','','','','','','',3),(49,'Danielle,,Dionne','','','','','','','','','',3),(50,'Orit,,Rozenblatt-Rosen','','','','','','','','','',3),(51,'Hongmei,,Mou','','','','','','','','','',3),(52,'Manjunatha,,Shivaraju','','','','','','','','','',3),(53,'Herman,,Bihler','','','','','','','','','',3),(54,'Martin,,Mense','','','','','','','','','',3),(55,'Guillermo,,Tearney','','','','','','','','','',3),(56,'Maximillian,,Haeussler','max@soe.ucsc.edu','','','','','','','','',7),(58,'Evangelia,,Diamanti','ed347@cam.ac.uk','01223 62317','Wellcome Trust / MRC Building, Hills Road','Cambridge','United Kingdom','CB2 0XY','Haematology','University of Cambridge','',1),(101,'Eduardo,,BeltrÃ¡n','Eduardo.Beltran@med.uni-muenchen.de','','GroÃŸhaderner Str. 9','Planegg-Martinsried','Germany','','','Institute of Clinical Neuroimmunology, LMU Munich','',1),(60,'Jonah,,Cool','','','','','','','','','',5),(61,'Josh,,Stuart','','','','','','','','','',4),(62,'Jing,,Zhu','','','','','','','','UC Santa Cruz','',7),(63,'Benedict,,Paten','','','','','','','','','',4),(64,'Timothy,,Tickle','','','','','','','','','',6),(65,'Jingya,,Wang','wangjin@medimmune.com','3013980977','1 Medimmune Way','Gaithersburg','USA','','Autoimmune, Inflammation and Respiratory','MedImmune.LLC','',1),(66,'Alison,,Humbles','','','','','','','','','',3),(67,'Yoichiro,,Ohne','','','','','','','','','',3),(68,'Jincheng,,Wu','','','','','','','','','',3),(69,'Boqiang,John,Hu','huboqiang@gmail.com','','5th Yiheyuan Road','Beijing','China','','bio-dynamic imaging center','Peking university','',1),(70,'Yuqiong,,Hu','','','','','','','','','',3),(71,'Xiaoye,,Wang','','','','','','','','','',3),(72,'Boqiang,,Hu','','','','','','','','','',3),(73,'Yunuo,,Mao','','','','','','','','','',3),(74,'Yidong,,Chen','','','','','','','','','',3),(75,'Liying,,Yan','','','','','','','','','',3),(76,'Jun,,Yong','','','','','','','','','',3),(77,'Ji,,Dong','','','','','','','','','',3),(78,'Yuan,,Wei','','','','','','','','','',3),(79,'Wei,,Wang','','','','','','','','','',3),(80,'Lu,,Wen','','','','','','','','','',3),(81,'Jie,,Qiao','','','','','','','','','',3),(82,'Fuchou,,Tang','','','','','','','','','',3),(83,'Subramaniam,,Malarkannan','malarkannanlab@gmail.com','','8727 W Watertown Plank Rd','Milwaukee','USA','','','Versiti Blood Research Institute','',1),(84,'Chao,,Yang','','','','','','','','','',3),(85,'Jason,R,Siebert','','','','','','','','','',3),(86,'Robert,,Burns','','','','','','','','','',3),(87,'Zachary,J,Gerbec','','','','','','','','','',3),(88,'Benedetta,,Bonacci','','','','','','','','','',3),(89,'Amy,,Rymaszewski','','','','','','','','','',3),(90,'Mary,,Rau','','','','','','','','','',3),(91,'Matthew,J,Riese','','','','','','','','','',3),(92,'Sridhar,,Rao','','','','','','','','','',3),(93,'Karen-Sue,,Carlson','','','','','','','','','',3),(94,'John,M,Routes','','','','','','','','','',3),(95,'James,W,Verbsky','','','','','','','','','',3),(96,'Monica,S,Thakar','','','','','','','','','',3),(97,'Kang,,Liu','','212-305-0839','701 W. 168 St., HHSC 1208','New York','USA','','Dept of Microbiology & Immunology','Columbia University','',1),(98,'Yu,J,Zhou','','','','','','','','','',3),(99,'Wenji,,Ma','','','','','','','','','',3),(100,'Yufeng,,Shen','','','','','','','','','',3),(102,'Cheng-Ran,,Xu','','','No.5 Yiheyuan Road Haidian District','Beijing','China','','College of Life Sciences','Peking University','',1),(103,'Lin-Chen,,Li','','','','','','','','','',3),(104,'Xin,,Wang','','','','','','','','','',3),(105,'Zi-Ran,,Xu','','','','','','','','','',3),(106,'Yan-Chun,,Wang','','','','','','','','','',3),(107,'Ye,,Feng','','','','','','','','','',3),(108,'Liu,,Yang','','','','','','','','','',3),(109,'Wei-Lin,,Qiu','','','','','','','','','',3),(110,'Li,,Yang','','','','','','','','','',3),(111,'Andrew,P,McMahon','amcmahon@med.usc.edu','323-442-7847','1425 San Pablo St, BCC 312','Los Angeles','USA','','Stem Cell Biol & Regen Med','University of Southern California','',1),(112,'Andrew,,Ransick','','','','','','','','','',3),(113,'Tracy,T,Tran','','','','','','','','','',3),(114,'Nils,O,Lindstrom','','','','','','','','','',3),(115,'Guilherme,,De Sena Brandine','','','','','','','','','',3),(116,'Doyoung,,Kim','doyoung.kim@nih.gov','','Bldg10, 12N256, 10 Center Dr','Bethesda','USA','','Dermatology Branch','NIAMS/NIH','',1),(117,'Benjamin,,Voisin','','','','','','','','','',3),(118,'Keisuke,,Nagao','','','','','','','','','',3),(119,'Ioannis,,Moustakas','ioannis.moustakas1@gmail.com','','Einthovenweg 20','Leiden','Netherlands','','Anatomy and Embryology','Leiden University Medical Center','',1),(120,'S,M,Chuva de Sousa Lopes','','','','','','','','','',3),(121,'I,,Moustakas','','','','','','','','','',3),(122,'M,,Bialecka','','','','','','','','','',3),(123,'Andrew,,Butler','abutler@nygenome.org','','101 6th Ave','New York','USA','','','New York Genome Center','',1),(124,'Tim,,Stuart','','','','','','','','','',3),(125,'Zhenyuan,,Yu','yuzhenyuan@126.com','+8613617715617','Shuangyong road 22','Nanning','China','','Center for Genomic and Personalized Medicine','Guangxi Medical University','',1),(126,'Jinling,,Liao','','','','','','','','','',3),(127,'Yang,,Chen','','','','','','','','','',3),(128,'Chunlin,,Zou','','','','','','','','','',3),(129,'Haiying,,Zhang','','','','','','','','','',3),(130,'Jiwen,,Cheng','','','','','','','','','',3),(131,'Deyun,,Liu','','','','','','','','','',3),(132,'Tianyu,,Li','','','','','','','','','',3),(133,'Qingyun,,Zhang','','','','','','','','','',3),(134,'Zengnan,,Mo','','','','','','','','','',3),(135,'Florent,,Ginhoux','Florent_Ginhoux@immunol.a-star.edu.sg','','8A Biomedical Grove, Immunos Building, Level 3','Singapore','Singapore','','','Singapore Immunology Network (SIgN), A*STAR','',1),(136,'Charles-Antoine,,Dutertre','','','','','','','','','',3),(137,'Etienne,,Becht','','','','','','','','','',3),(138,'Sergio,E,Irac','','','','','','','','','',3),(139,'Ahad,,Khalilnezhad','','','','','','','','','',3),(140,'Vipin,,Narang','','','','','','','','','',3),(141,'Shabnam,,Khalilnezhad','','','','','','','','','',3),(142,'Pei,Y,Ng','','','','','','','','','',3),(143,'Lucas,L,vandenHoogen','','','','','','','','','',3),(144,'Jing,Y,Leong','','','','','','','','','',3),(145,'Bernett,,Lee','','','','','','','','','',3),(146,'Marion,,Chevrier','','','','','','','','','',3),(147,'Xiao,M,Zhang','','','','','','','','','',3),(148,'Pearly,J,Ai Yong','','','','','','','','','',3),(149,'Geraldine,,Koh','','','','','','','','','',3),(150,'Josephine,,Lum','','','','','','','','','',3),(151,'ShanShan,W,Howland','','','','','','','','','',3),(152,'Esther,,Mok','','','','','','','','','',3),(153,'Jinmiao,,Chen','','','','','','','','','',3),(154,'Anis,,Larbi','','','','','','','','','',3),(155,'Henry,K,Tan','','','','','','','','','',3),(156,'Tony,H,Lim','','','','','','','','','',3),(157,'Panagiota,,Karagianni','','','','','','','','','',3),(158,'Athanasios,G,Tzioufas','','','','','','','','','',3),(159,'Benoit,,Malleret','','','','','','','','','',3),(160,'Joshua,,Brody','','','','','','','','','',3),(161,'Salvatore,,Albani','','','','','','','','','',3),(162,'Joel,,van Roon','','','','','','','','','',3),(163,'Timothy,,Radstake','','','','','','','','','',3),(164,'Evan,W,Newell','','','','','','','','','',3),(165,'Todd,E,Scheetz','todd-scheetz@uiowa.edu','','3181B MERF','Iowa City','USA','','','UNIVERSITY OF IOWA','',1),(167,'Robert,F,Mullins','','','','','','','','','',3),(168,'Beagan,,Nguy','bnguy@ucsc.edu','','','','','','','','',8),(169,'Pranav,,Muthuraman','pmuthura@ucsc.edu','','','','','','','','',8),(170,'Kamron,,Mojabe','kmojabe1@ucsc.edu','','','','','','','','',8),(172,'Mallory,Ann,Freeberg','','','','','','','','','',2),(173,'Kerstin,B,Meyer','','','','','','','','','',3),(174,'Sarah,A,Teichmann','','','','','','','','','',3),(175,'Oliver,,Stegle','','','','','','','','','',3),(176,'Danielle,,Welter','','','','','','','','','',2),(177,'Barbara,,Treutlein','','','','','','','','','',3),(178,'Menna,,Clatworthy','','','','','','','','','',3),(179,'Sam,,Behjati','','','','','','','','','',3),(180,'Muzlifah,,Haniffa','','','','','','','','','',3),(181,'Sarah,,Teichmann','','','','','','','','','',3),(183,'Rahul,,Satija','','','','','','','','','',3),(210,'Berthold,,Göttgens','','','','Cambridge','United Kingdom','','Department of Haematology','University of Cambridge','',4),(186,'Laura,,Huerta','','','','','','','','','',2),(187,'Anja,,Fullgrabe','','','','','','','','','',3),(188,'Matthew,,Green','','','','','','','','','',2),(189,'Benjamin,D,Humphreys','','','','','','','','','',3),(209,'John,C,Marioni','','','','','United Kingdom','','','','',4),(191,'Dana,,Pe\'er','','','','','','','','','',3),(192,'Sonya,A,MacParland','','','','','','','','','',3),(193,'Gary,D,Bader','','','','','','','','','',3),(194,'Ian,D,McGilvray','','','','','','','','','',3),(195,'Jane,C,Sowden','','','','','','','','','',3),(196,'Trevor,D,Lamb','','','','','','','','','',3),(197,'Peng-Yuna,,Wang','','','','','','','','','',3),(198,'Alex,W,Hewitt','','','','','','','','','',3),(199,'Mark,C,Gillies','','','','','','','','','',3),(200,'Joseph,E,Powell','','','','','','','','','',3),(201,'Raymond,CB,Wong','','','','','','','','','',3),(202,'Marion,F,Shadbolt','','','','','','','','','',3),(203,'Anindita,,Basu','','','','','','','','','',3),(204,'Sebastian,,Pott','','','','','','','','','',3),(205,'Zinaida,A,Perova','','','','','','','','','',3),(206,'Sten,,Linnarsson','','','','','','','','','',3),(207,'Donna,L,Farber','','','','','','','','','',3),(208,'Peter,A,Sims','','','','','','','','','',3),(234,'Magnus,David,Lynch','magnus.lynch@kcl.ac.uk','','28th Floor, Tower Wing, Guy\'s Campus','London','United Kingdom','','Centre for Stem Cells and Regenerative Medicine','King\'s College London','',1),(233,'Yaoyao,,Zhang','','','','','','','','','',3),(232,'Zhiqiang,,Yan','zqyan@pku.edu.cn','','No.5 Yiheyuan Road Haidian District','Beijing','China','','','Peking University','',1),(219,'Albert,D,Kim','','','','','','','','','',3),(220,'Gordon,K,Smyth','smyth@wehi.edu.au','(+61 3) 9345 2326','1G Royal Pde','Parkville','Australia','3052','Bioinformatics','Walter and Eliza Hall Institute of Medical Research','',1),(221,'Karsten,,Bach','kb615@cam.ac.uk','','Tennis Court Road','Cambridge','United Kingdom','','Department of Pharmacology','University of Cambridge','',1),(222,'Pensa,,Sara','','','','','','','','','',3),(223,'Jihwan,,Park','jihwan.park@postech.ac.kr','','415 CRB, 415 Curie Blvd','Philadelphia','USA','','','University of Pensylvania','',1),(224,'Rojesh,,Shrestha','','','','','','','','','',3),(225,'Chengxiang,,Qiu','','','','','','','','','',3),(226,'Ayano,,Kondo','','','','','','','','','',3),(227,'Shizheng,,Huang','','','','','','','','','',3),(228,'Max,,Werth','','','','','','','','','',3),(229,'Mingyao,,Li','','','','','','','','','',3),(230,'Jonathan,,Barasch','','','','','','','','','',3),(231,'Katalin,,Suszták','','','','','','','','','',3),(237,'Thiago,Y,Oliveira','toliveira@rockefeller.edu','','1230 YORK AVE','New York','USA','','Immunology, Virology and Microbiology','The Rockefeller University','',1),(236,'Fiona,M,Watt','','','','','','','','','',3),(239,'Enrique,Sapena,Ventura','enrique@ebi.ac.uk','','','Cambridge','United Kingdom','','','','',2),(240,'Adrian,,Veres','ed347@cam.ac.uk','0122362317','7 Divinity Ave; Cambridge, Massachusetts  USA','Cambridge','USA','95060','','Harvard University','',1),(241,'Maayan,,Baron','','','','','','','','','',3),(242,'Peter,A,Szabo','','','','','','','','','',3),(243,'Hanna,Mendes,Levitin','','','','','','','','','',3),(244,'Michelle,,Miron','','','','','','','','','',3),(245,'Mark,E,Snyder','','','','','','','','','',3),(246,'Takashi,,Senda','','','','','','','','','',3),(247,'Jinzhou,,Yuan','','','','','','','','','',3),(248,'Yim,L,Cheng','','','','','','','','','',3),(249,'Erin,C,Bush','','','','','','','','','',3),(250,'Pranay,,Dogra','','','','','','','','','',3),(251,'Puspa,,Thapa','','','','','','','','','',3),(252,'Pandurangan,,Vijayanand','vijay@lji.org','','9420 Athena Circle; La Jolla, California  USA','La Jolla','USA','','Division of Vaccine Discovery','La Jolla Institute for Allergy and Immunology','',1),(253,'Grace,X.Y.,Zheng','grace@10xgenomics.com','','7068 Koll Center Parkway','Pleasanton','USA','94566','','10X Genomics Inc','',1),(254,'Jeff,,Liu','jeff.liu@utoronto.ca','416-340-4800','67 College Street, RM427','Toronto','Canada','M5G 2M1','Cellular and Molecular Biology','University Health Network','',1),(255,'Christoph,,Ziegenhain','ziegenhain@bio.lmu.de','','GroÃŸhaderner Str. 2','Martinsried','Germany','82152','Department Biology II','Ludwig-Maximilians University Munich','',1),(256,'Wolfgang,,Enard','','','','','','','','','',3),(257,'Itai,,Yana','itai.yanai@nyumc.org','','Haifa, 3200003','','Israel','','Faculty of Biology','Technion - Israel Institute of Technology','',1),(258,'Filipe,,Pereira','','','','','','','','','',4),(259,'Rui,,Chen','','','','Houston','USA','','Human Genome Sequencing Center, Department of Molecular and Human Genetics,','Baylor College of Medicine','',4),(260,'Margaret,,DeAngelis','','','','Lake City','USA','','Department of Ophthalmology and Visual Sciences','University of Utah','',4);
/*!40000 ALTER TABLE `hcat_contributor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_contributor_grants`
--

DROP TABLE IF EXISTS `hcat_contributor_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_contributor_grants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contributor_id` int(11) NOT NULL,
  `grant_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_contributor_grants_contributor_id_grant_id_c1db5ff4_uniq` (`contributor_id`,`grant_id`),
  KEY `hcat_contributor_grants_contributor_id_72008a75` (`contributor_id`),
  KEY `hcat_contributor_grants_grant_id_d9a8eb67` (`grant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_contributor_grants`
--

LOCK TABLES `hcat_contributor_grants` WRITE;
/*!40000 ALTER TABLE `hcat_contributor_grants` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_contributor_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_contributortype`
--

DROP TABLE IF EXISTS `hcat_contributortype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_contributortype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_contributortype`
--

LOCK TABLES `hcat_contributortype` WRITE;
/*!40000 ALTER TABLE `hcat_contributortype` DISABLE KEYS */;
INSERT INTO `hcat_contributortype` VALUES (1,'lab contact','This is who we reach out to with questions about a lab or a data set',''),(2,'wrangler','A data wrangler herds slightly mismatched collections of large data files, spreadsheets, photos, and so forth from scientists, engineers, and other places  into a nice tidy database without losing too much information in the process',''),(3,'contributor','Someone who is willing to contribute data, money. or otherwise help the HCA.  Everyone associated with a project is considered a contributor.  For external DB imports we maintain the contributors lists from GEO etc.',''),(4,'PI','The primary investigator on a grant.  Often the lab contact\'s boss.',''),(5,'program officer','Someone from the funding agency who is responsible for administering a portfolio of related grants.','Often a good person to contact with questions about consent and funding issues'),(6,'pipeliner','Someone involved with high throughput compute on big data sets.',''),(7,'analyst','Someone who does custom analysis or visualization',''),(8,'intern','Someone here to learn a skill','');
/*!40000 ALTER TABLE `hcat_contributortype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_disease`
--

DROP TABLE IF EXISTS `hcat_disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_disease` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_disease_short_name_f5dc3e71_uniq` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_disease`
--

LOCK TABLES `hcat_disease` WRITE;
/*!40000 ALTER TABLE `hcat_disease` DISABLE KEYS */;
INSERT INTO `hcat_disease` VALUES (1,'obstructive sleep apnea','Difficulties breathing while sleeping that sometimes can be relieved by tonsilectomy',''),(2,'healthy','Healthy donor and specimen',''),(3,'type 2 diabetes','Type 2 diabetes mellitus - high blood sugar levels from insulin insensitivity',''),(4,'cardiovascular disease','A disease of the heart, arteries, veins, and lungs',''),(5,'parkinsons','Parkinson\'s disease - tremors and stiffness from atrophy of substantia negra',''),(6,'hepatic steatosis','hepatic steatosis, also known as fatty liver, effects 1% of the USA',''),(9,'subclinical neuro-inflammation','neural inflammation detectable but not at a level yet to generally interfere with life',''),(8,'GATA2T354M','Human genetic variation GATA2T354M',''),(10,'multiple schlerosis','Clinically definite multiple schlerosis, an autoimmune disorder of the central nervous system',''),(11,'autoimmune encephalitis','inflammation of the brain caused by an autoimmune response',''),(12,'cancer','A large family of diseases involving out of control growth of cells where it is not helpful',''),(13,'lupus','Systemic lupus erythematosus - an autoimmune disease effecting connective tissue with variable and sometimes tragic outcomes',''),(14,'melanoma','A cancer, often of the skin, derived from pigmented melanocytes','');
/*!40000 ALTER TABLE `hcat_disease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_disease_projects`
--

DROP TABLE IF EXISTS `hcat_disease_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_disease_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disease_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_disease_projects_disease_id_project_id_027ff738_uniq` (`disease_id`,`project_id`),
  KEY `hcat_disease_projects_disease_id_a4d5d498` (`disease_id`),
  KEY `hcat_disease_projects_project_id_f88f39b1` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_disease_projects`
--

LOCK TABLES `hcat_disease_projects` WRITE;
/*!40000 ALTER TABLE `hcat_disease_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_disease_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_file`
--

DROP TABLE IF EXISTS `hcat_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(80) NOT NULL,
  `file` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_file`
--

LOCK TABLES `hcat_file` WRITE;
/*!40000 ALTER TABLE `hcat_file` DISABLE KEYS */;
INSERT INTO `hcat_file` VALUES (1,'Full empty template for v6 metadata','uploads/hca_allFields.xlsx','An excel file that contains all tabs that anyone might ever want as of mid 2019','');
/*!40000 ALTER TABLE `hcat_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_funder`
--

DROP TABLE IF EXISTS `hcat_funder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_funder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_funder`
--

LOCK TABLES `hcat_funder` WRITE;
/*!40000 ALTER TABLE `hcat_funder` DISABLE KEYS */;
INSERT INTO `hcat_funder` VALUES (1,'Swedish Research Council','Funds research in Sweden.  See https://www.vr.se/english.html',''),(2,'NIH','National Institutes of Health of the Unites States of America',''),(3,'CZI','Chan-Zuckerberg Initiative',''),(4,'MRC','United Kingdom\'s Medical Research Council',''),(5,'Gates','Gates Foundation',''),(6,'anonymous','A donor who is humble enough not to be pestered by further requests for more funds.','');
/*!40000 ALTER TABLE `hcat_funder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_grant`
--

DROP TABLE IF EXISTS `hcat_grant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_grant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grant_title` varchar(200) NOT NULL,
  `grant_id` varchar(200) NOT NULL,
  `funder_id` int(11) DEFAULT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hcat_grant_funder_id_a47964f4` (`funder_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_grant`
--

LOCK TABLES `hcat_grant` WRITE;
/*!40000 ALTER TABLE `hcat_grant` DISABLE KEYS */;
INSERT INTO `hcat_grant` VALUES (2,'anonymous gift','gift_0001',6,''),(3,'HCA-DCP UC Santa Cruz','CZI # 2017-171531',3,'');
/*!40000 ALTER TABLE `hcat_grant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_grant_funded_contributors`
--

DROP TABLE IF EXISTS `hcat_grant_funded_contributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_grant_funded_contributors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grant_id` int(11) NOT NULL,
  `contributor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_grant_funded_contri_grant_id_contributor_id_4b64935e_uniq` (`grant_id`,`contributor_id`),
  KEY `hcat_grant_funded_contributors_grant_id_448f7bc3` (`grant_id`),
  KEY `hcat_grant_funded_contributors_contributor_id_0015c0ac` (`contributor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_grant_funded_contributors`
--

LOCK TABLES `hcat_grant_funded_contributors` WRITE;
/*!40000 ALTER TABLE `hcat_grant_funded_contributors` DISABLE KEYS */;
INSERT INTO `hcat_grant_funded_contributors` VALUES (3,2,4),(4,3,3),(5,3,4),(6,3,5),(7,3,6),(8,3,7),(9,3,56),(10,3,60),(11,3,62),(12,3,63);
/*!40000 ALTER TABLE `hcat_grant_funded_contributors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_grant_funded_labs`
--

DROP TABLE IF EXISTS `hcat_grant_funded_labs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_grant_funded_labs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grant_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_grant_funded_labs_grant_id_lab_id_0c7bf27e_uniq` (`grant_id`,`lab_id`),
  KEY `hcat_grant_funded_labs_grant_id_517887b0` (`grant_id`),
  KEY `hcat_grant_funded_labs_lab_id_87e7b483` (`lab_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_grant_funded_labs`
--

LOCK TABLES `hcat_grant_funded_labs` WRITE;
/*!40000 ALTER TABLE `hcat_grant_funded_labs` DISABLE KEYS */;
INSERT INTO `hcat_grant_funded_labs` VALUES (3,3,3);
/*!40000 ALTER TABLE `hcat_grant_funded_labs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_grant_funded_projects`
--

DROP TABLE IF EXISTS `hcat_grant_funded_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_grant_funded_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grant_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_grant_funded_projects_grant_id_project_id_53c1372f_uniq` (`grant_id`,`project_id`),
  KEY `hcat_grant_funded_projects_grant_id_b65d47bb` (`grant_id`),
  KEY `hcat_grant_funded_projects_project_id_4db04f16` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_grant_funded_projects`
--

LOCK TABLES `hcat_grant_funded_projects` WRITE;
/*!40000 ALTER TABLE `hcat_grant_funded_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_grant_funded_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_intern`
--

DROP TABLE IF EXISTS `hcat_intern`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_intern` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments` varchar(255) NOT NULL,
  `advisor_id` int(11) DEFAULT NULL,
  `who_id` int(11) NOT NULL,
  `interests` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hcat_curator_advisor_id_6989ac01` (`advisor_id`),
  KEY `hcat_curator_who_id_047884c7` (`who_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_intern`
--

LOCK TABLES `hcat_intern` WRITE;
/*!40000 ALTER TABLE `hcat_intern` DISABLE KEYS */;
INSERT INTO `hcat_intern` VALUES (2,'',5,168,'single cell sequencing'),(3,'',5,169,'single cell sequencing'),(4,'',5,170,'single cell sequencing');
/*!40000 ALTER TABLE `hcat_intern` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_lab`
--

DROP TABLE IF EXISTS `hcat_lab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_lab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `pi_id` int(11) DEFAULT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_lab_short_name_b6009c0a_uniq` (`short_name`),
  KEY `hcat_lab_pi_id_ef656759` (`pi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_lab`
--

LOCK TABLES `hcat_lab` WRITE;
/*!40000 ALTER TABLE `hcat_lab` DISABLE KEYS */;
INSERT INTO `hcat_lab` VALUES (1,'Mjösberg Lab Uppsala University','Uppsala University',2,''),(2,'CziBioHub','Bio Hub',25,''),(3,'Jim Kent UC Santa Cruz','UC Santa Cruz',4,''),(5,'Gottgens University of Cambridge','University of Cambridge',210,''),(7,'Liu Lab Columbia University','Columbia University',97,''),(8,'Andrew McMahon University of Southern California','University of Southern California',111,''),(9,'Chuva Sousa Lopes Lab','Leiden University Medical Center',120,''),(10,'Satija Lab New York Genome Center','New York Genome Center',183,''),(11,'Klein Lab Harvard Medical School','Harvard Medical School',19,''),(12,'Smyth Lab Walter and Eliza Hall Institute','Walter and Eliza Hall Institute of Medical Research',220,''),(13,'Sims Lab; Department of Systems Biology',NULL,208,''),(14,'D Pe\'er Lab Sloan Kettering','Sloan Kettering Institute',191,''),(15,'Rui Chen Lab at Baylor','Baylor College of Medicine',259,''),(16,'DeAngelis Lab University of Utah','University of Utah',260,'');
/*!40000 ALTER TABLE `hcat_lab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_lab_contributors`
--

DROP TABLE IF EXISTS `hcat_lab_contributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_lab_contributors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_id` int(11) NOT NULL,
  `contributor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_lab_contributors_lab_id_contributor_id_5982dc54_uniq` (`lab_id`,`contributor_id`),
  KEY `hcat_lab_contributors_lab_id_d78ce88d` (`lab_id`),
  KEY `hcat_lab_contributors_contributor_id_99fd52fb` (`contributor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_lab_contributors`
--

LOCK TABLES `hcat_lab_contributors` WRITE;
/*!40000 ALTER TABLE `hcat_lab_contributors` DISABLE KEYS */;
INSERT INTO `hcat_lab_contributors` VALUES (1,1,1),(2,1,2),(3,1,21),(4,1,22),(5,1,23),(6,2,24),(7,2,25),(8,3,4),(9,3,3),(10,3,5),(11,3,6),(12,3,7),(20,5,12),(19,5,11),(18,5,10),(17,5,58),(21,7,97),(22,7,98),(23,7,99),(24,7,100),(25,8,112),(26,8,113),(27,8,114),(28,8,115),(29,8,111),(30,9,120),(31,9,121),(32,9,122),(33,10,123),(34,10,124),(35,11,13),(36,11,14),(37,11,15),(38,11,16),(39,11,17),(40,11,18),(41,11,19),(42,11,20),(43,13,207);
/*!40000 ALTER TABLE `hcat_lab_contributors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_lab_grants`
--

DROP TABLE IF EXISTS `hcat_lab_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_lab_grants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_id` int(11) NOT NULL,
  `grant_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_lab_grants_lab_id_grant_id_ece9905c_uniq` (`lab_id`,`grant_id`),
  KEY `hcat_lab_grants_lab_id_ac121b06` (`lab_id`),
  KEY `hcat_lab_grants_grant_id_0645f728` (`grant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_lab_grants`
--

LOCK TABLES `hcat_lab_grants` WRITE;
/*!40000 ALTER TABLE `hcat_lab_grants` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_lab_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_organ`
--

DROP TABLE IF EXISTS `hcat_organ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_organ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `ontology_id` varchar(32) DEFAULT NULL,
  `ontology_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_organ_short_name_16091268_uniq` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_organ`
--

LOCK TABLES `hcat_organ` WRITE;
/*!40000 ALTER TABLE `hcat_organ` DISABLE KEYS */;
INSERT INTO `hcat_organ` VALUES (1,'tonsil','Small almond-shaped masses of lymph tissue found on either side of the oropharynx','','UBERON:0002372','tonsil'),(2,'lung','Respiration organ that develops as an oupocketing of the esophagus','','UBERON:0002048','lung'),(3,'full body','complete body used as specimen','',NULL,NULL),(4,'pancreas','An endoderm derived structure that produces precursors of digestive enzymes and blood glucose regulating enzymes','','UBERON:0001264','pancreas'),(5,'kidney','A paired organ of the urinary tract which has the production of urine as its primary function','','UBERON:0002113','kidney'),(6,'brain','The brain is the center of the nervous system in all vertebrate, and most invertebrate, animals','','UBERON:0000955','brain'),(7,'liver','An exocrine gland which secretes bile and functions in metabolism of protein and carbohydrate and fat, synthesizes substances involved in the clotting of the blood, synthesizes vitamin A, detoxifies poisonous substances, stores glycogen','','UBERON:0002107','liver'),(8,'umbilical cord','The connecting cord from the developing embryo to the placenta','','UBERON:0002331','umbilical cord'),(9,'blood','A fluid that is composed primarily of small oxygen carrying red blood cells and larger immune cells suspended in a plasma of nutrients, antibodies, signaling molecules, and wastes','','UBERON:0000178','blood'),(10,'eye','An organ that detects light','','UBERON:0000970','eye'),(11,'bone marrow','The soft tissue that fills the cavities of bones','','UBERON:0002371','bone marrow'),(12,'spinal cord','Part of the central nervous system located in the vertebral canal continuous with and caudal to the brain','','UBERON:0002240','spinal chord'),(13,'skin','The organ covering the body that consists of the dermis and epidermis','','UBERON:0002097','skin of body'),(14,'ovary','The gonad of a female organism which contains germ cells','','UBERON:0000992','ovary'),(15,'colon','The colon is the last part of the digestive tract before the rectum, where water is removed','',NULL,NULL),(16,'spleen','An organ of the immune system responsible for recycling old blood cells and fighting blood-borne infections','',NULL,NULL),(17,'esophagus','The part of the alimentary canal that connects the throat to the stomach, also known as the gullet.','',NULL,NULL),(18,'breast','NEEDS DESCRIPTION','',NULL,NULL),(19,'lymph node','A place where lymph fluid is filtered and probed by immune cells','',NULL,NULL);
/*!40000 ALTER TABLE `hcat_organ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_organ_projects`
--

DROP TABLE IF EXISTS `hcat_organ_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_organ_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organ_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_organ_projects_organ_id_project_id_29a0a969_uniq` (`organ_id`,`project_id`),
  KEY `hcat_organ_projects_organ_id_35c37cd8` (`organ_id`),
  KEY `hcat_organ_projects_project_id_fb9e00cf` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_organ_projects`
--

LOCK TABLES `hcat_organ_projects` WRITE;
/*!40000 ALTER TABLE `hcat_organ_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_organ_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_organpart`
--

DROP TABLE IF EXISTS `hcat_organpart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_organpart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `ontology_id` varchar(32) DEFAULT NULL,
  `ontology_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_organpart_short_name_06308530_uniq` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_organpart`
--

LOCK TABLES `hcat_organpart` WRITE;
/*!40000 ALTER TABLE `hcat_organpart` DISABLE KEYS */;
INSERT INTO `hcat_organpart` VALUES (1,'healthy tonsils from apnea patients','Healthy tonsil surgically removed from sleep apnea patients','',NULL,NULL),(2,'lung airway epithelium','cells harvested from the epithelium of lungs','',NULL,NULL),(4,'kidney cortex','Cortex of Kidney','',NULL,NULL),(5,'whole','complete organ was sampled','',NULL,NULL),(6,'kidney organoid','An organoid grown according to a kidney differentiation protocol','',NULL,NULL),(7,'cord blood','Blood extracted from the umbilical cord of a newborn infant','',NULL,NULL),(8,'peripheral blood','Blood extracted from a blood vessel, usually a vein, as opposed to blood in an organ','',NULL,NULL),(9,'Human Embryonic Retinal Cells','','',NULL,NULL),(10,'Bone marrow NK cells','Natural killer cells from bone marrow','',NULL,NULL),(11,'Blood NK cells','','',NULL,NULL),(12,'classic dentritic cell','','',NULL,NULL),(13,'precursor dentritic cell','','',NULL,NULL),(14,'mixed of preDC and DCs','','',NULL,NULL),(15,'CD1c(CD1c+ classic dentritic cell)','','',NULL,NULL),(16,'CD141(CD141+ classic dentritic cell)','','',NULL,NULL),(17,'preDC(precursor dentritic cell)','','',NULL,NULL),(18,'CDP(common dendritic cell progenitor )','','',NULL,NULL),(19,'cerebro-spinal fluid','','',NULL,NULL),(20,'embryonic somatic stage mesoderm','','',NULL,NULL),(23,'stroma from ovary','connective tissue, blood vessels and other in between parts of the ovary','',NULL,NULL),(24,'Follicle 2-5mm from ovary','An egg follicle at the 2-5mm stage','',NULL,NULL),(25,'Follicle 1-2mm from ovary','An egg follicle at the 1-2mm stage','',NULL,NULL),(26,'Bone Marrow Mononuclear Cells','Cells with a relatively small  size and one simple nucleus from bone marrow','',NULL,NULL),(28,'peripheral blood phagocytes','Peripheral blood dendritic cells and monocytes','',NULL,NULL),(29,'retina','NEEDS DESCRIPTION','',NULL,NULL),(30,'fovea','NEEDS DESCRIPTION','',NULL,NULL),(31,'differentiated H1 cells','','',NULL,NULL),(32,'cerebral organoid','','',NULL,NULL),(33,'HBECs','ir-liquid interface culture of primary Human bron','',NULL,NULL),(34,'Trachea','NEEDS DESCRIPTION','',NULL,NULL),(35,'Mammary gland','NEEDS DESCRIPTION','',NULL,NULL),(36,'Mammary gland, 5wk','NEEDS DESCRIPTION','',NULL,NULL),(37,'Mammary gland, P7D','NEEDS DESCRIPTION','',NULL,NULL),(38,'Mammary gland, P7E','NEEDS DESCRIPTION','',NULL,NULL),(39,'Primary papillary dermis','NEEDS DESCRIPTION','',NULL,NULL),(40,'Primary reticular dermis','NEEDS DESCRIPTION','',NULL,NULL),(41,'Blood Dendritic Cells','NEEDS DESCRIPTION','',NULL,NULL),(42,'Cord Blood pre-cDCs','NEEDS DESCRIPTION','',NULL,NULL),(43,'Blood pre-cDCs','NEEDS DESCRIPTION','',NULL,NULL),(44,'cerebral cortex','','',NULL,NULL),(45,'subventricular zone','','',NULL,NULL),(46,'hippocampus','','',NULL,NULL),(47,'pancreatic islets','Islets containing endocrine cells such as insulin producing beta cells from pancreas','',NULL,NULL);
/*!40000 ALTER TABLE `hcat_organpart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_organpart_projects`
--

DROP TABLE IF EXISTS `hcat_organpart_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_organpart_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organpart_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_organpart_projects_organpart_id_project_id_9ccf00df_uniq` (`organpart_id`,`project_id`),
  KEY `hcat_organpart_projects_organpart_id_845b3850` (`organpart_id`),
  KEY `hcat_organpart_projects_project_id_cd86deaf` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_organpart_projects`
--

LOCK TABLES `hcat_organpart_projects` WRITE;
/*!40000 ALTER TABLE `hcat_organpart_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_organpart_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_preservationmethod`
--

DROP TABLE IF EXISTS `hcat_preservationmethod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_preservationmethod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_preservationmethod`
--

LOCK TABLES `hcat_preservationmethod` WRITE;
/*!40000 ALTER TABLE `hcat_preservationmethod` DISABLE KEYS */;
INSERT INTO `hcat_preservationmethod` VALUES (1,'fresh','fresh sample used without the need for preservation','');
/*!40000 ALTER TABLE `hcat_preservationmethod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project`
--

DROP TABLE IF EXISTS `hcat_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(80) NOT NULL,
  `title` varchar(120) NOT NULL,
  `description` longtext NOT NULL,
  `stars` int(11) NOT NULL,
  `consent_id` int(11) DEFAULT NULL,
  `cells_expected` int(11) NOT NULL,
  `project_source_id` int(11) DEFAULT NULL,
  `staging_area` varchar(255) NOT NULL,
  `back_to_lab` varchar(100) DEFAULT NULL,
  `sheet_from_lab` varchar(100) DEFAULT NULL,
  `sheet_template` varchar(100) DEFAULT NULL,
  `sheet_submitted` varchar(100) DEFAULT NULL,
  `origin_name` varchar(200) NOT NULL,
  `first_contact_date` date DEFAULT NULL,
  `last_contact_date` date DEFAULT NULL,
  `questionnaire_date` date DEFAULT NULL,
  `sheet_from_lab_date` date DEFAULT NULL,
  `sheet_template_date` date DEFAULT NULL,
  `sheet_validated_date` date DEFAULT NULL,
  `staging_area_date` date DEFAULT NULL,
  `tAndC_date` date DEFAULT NULL,
  `submit_date` date DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `comments` varchar(255) NOT NULL,
  `submit_comments` varchar(255) NOT NULL,
  `primary_wrangler_id` int(11) DEFAULT NULL,
  `secondary_wrangler_id` int(11) DEFAULT NULL,
  `lab_review_date` date DEFAULT NULL,
  `lab_review_comments` varchar(255) NOT NULL,
  `back_to_lab_date` date DEFAULT NULL,
  `questionnaire_comments` varchar(255) NOT NULL,
  `git_ticket_url` varchar(200) DEFAULT NULL,
  `tAndC_comments` varchar(255) NOT NULL,
  `shared_google_sheet` varchar(200) DEFAULT NULL,
  `wrangling_status_id` int(11) DEFAULT NULL,
  `wrangler_drive` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hcat_project_concent_id_fbd4fd2f` (`consent_id`),
  KEY `hcat_project_origin_id_bc12bf09` (`project_source_id`),
  KEY `hcat_project_state_reached_id_a2e57236` (`status_id`),
  KEY `hcat_project_wrangler1_id_474ad0aa` (`primary_wrangler_id`),
  KEY `hcat_project_wrangler2_id_6a9604b0` (`secondary_wrangler_id`),
  KEY `hcat_project_wrangling_state_id_627473b0` (`wrangling_status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project`
--

LOCK TABLES `hcat_project` WRITE;
/*!40000 ALTER TABLE `hcat_project` DISABLE KEYS */;
INSERT INTO `hcat_project` VALUES (1,'HumanInnateLymphoidCells','Single cell RNA-sequencing of human tonsil Innate lymphoid cells (ILCs)','Single cell RNA-sequencing of human tonsil Innate lymphoid cells (ILCs) from three independent tonsil donors.',5,1,50000,1,'','','uploads/project/GSE70580.xlsx','','uploads/project/human_tonsil_GSE70580_paris_1.xlsx','GSE70580',NULL,NULL,NULL,'2019-09-06',NULL,'2019-08-21',NULL,NULL,NULL,4,'','',3,NULL,NULL,'',NULL,'',NULL,'',NULL,4,''),(2,'Tabula Muris','A single cell atlas of the mouse','We have created a compendium of single cell transcriptome data from the model organism Mus musculus comprising more than 100,000 cells from 20 organs and tissues. These data represent a new resource for cell biology, revealing gene expression in poorly characterized cell populations and allowing for direct and controlled comparison of gene expression in cell types shared between tissues, such as T-lymphocytes and endothelial cells from distinct anatomical locations. Two distinct technical approaches were used for most tissues: one approach, microfluidic droplet-based 3’-end counting, enabled the survey of thousands of cells at relatively low coverage, while the other, FACS-based full length transcript analysis, enabled characterization of cell types with high sensitivity and coverage. The cumulative data provide the foundation for an atlas of transcriptomic cell biology.',4,2,1000000,2,'','','','','uploads/project/Tabula_Muris_Ontology_17_05.xlsx','Tabula Muris',NULL,NULL,NULL,NULL,NULL,'2019-07-09',NULL,NULL,'2019-07-09',8,'','',4,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(3,'RevisedAirwayEpithelialHierarchy','A revised airway epithelial hierarchy includes CFTR-expressing ionocytes','Airways conduct gases to the lung and are disease sites of asthma and cystic fibrosis. Here we study the cellular composition and hierarchy of the mouse tracheal epithelium by single-cell RNA-sequencing (scRNA-seq) and in vivo lineage tracing. We identify a rare cell type, the Foxi1+ pulmonary ionocyte; functional variations in club cells by proximodistal location; a distinct cell type in high turnover squamous epithelial structures that we term \\\'hillocks\\\'; and disease-relevant subsets of tuft and goblet cells. We developed \\\'pulse-seq\\\' , combining scRNA-seq and lineage tracing, to show that tuft, neuroendocrine and ionocyte cells are continually and directly replenished by basal progenitor cells. Ionocytes are the major source of transcripts of the cystic fibrosis transmembrane conductance regulator in both mouse (Cftr) and human (CFTR). Knockout of Foxi1 in mouse ionocytes causes loss of Cftr expression and disrupts airway fluid and mucus physiology, phenotypes that characterize cystic fibrosis. By associating cell-type-specific expression programs with key disease genes, we establish a new cellular narrative for airways disease.',4,2,0,1,'','','uploads/project/GSE103354_s8tqNaC.xlsx','','','GSE103354',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,4,'','',3,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(11,'HumanLymphoMyeloidProgenitorCells','Single Cell RNA sequencing analysis of human haemopoietic lympho-myeloid progenitor populations (LMPP, MLP and GMP)','We performed single cell RNA sequencing of human haemopoietic lympho-myeloid progenitors with the aim to separate functionally and transcriptionally distinct progenitors within the heterogeneous GMP, LMPP and MLP populations. We performed RNA sequencing in a total of 415 single cells. From donors 1 (CB369) and 2 (CB431), 163/166 and 157/249 cells passed quality control.We further analysed the 320 single cells that passed quality control from two  different donors (157 and 163 from each donor; 91 LMPP, 110 MLP and 119 GMP). We performed clustering using Seurat package, which identified 3 clusters of cells.  We identified genes that were differentially expressed among cells of the different clusters. The majority of the cells in cluster 1 were MLP, the majority of cluster 3 were GMP while cluster comprised of LMPP and GMP cells. Cluster 1 showed high expression of lymphoid-affiliated genes. Conversely, cluster 3 showed increased expression of myeloid genes, while cluster 2 showed a mixed transcriptional signature. PCA analysis revealed a transcriptional continuum of LMPP, MLP and GMP populations.',5,1,0,1,'','','/uploads/project/GSE100618.xlsx','','','GSE100618',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(12,'Diabetic Nephropathy snRNA-seq','The Single Cell Transcriptomic Landscape of Early Human Diabetic Nephropathy','Diabetic nephropathy is characterized by damage to both the glomerulus and tubulointerstitium, but relatively little is known about accompanying cell-specific changes in gene expression. We performed unbiased single nucleus RNA sequencing (snRNAseq) on cryopreserved human diabetic kidney samples to generate 23,980 single nucleus transcriptomes from three control and three early diabetic nephropathy samples. All major cell types of the kidney were represented in the final dataset. Side by side comparison demonstrated cell-type-specific changes in gene expression that are important for ion transport, angiogenesis, and immune cell activation. In particular, we show that the diabetic thick ascending limb, late distal convoluted tubule, and principal cells all adopt a gene expression signature consistent with increased potassium secretion, including alterations in Na-K+-ATPase, WNK1, mineralocorticoid receptor and NEDD4L expression, as well as decreased paracellular calcium and magnesium reabsorption. We also identify strong angiogenic signatures in glomerular cell types, proximal convoluted tubule, distal convoluted tubule and principal cells. Taken together, these results suggest that increased potassium secretion and angiogenic signaling represent early kidney responses in human diabetic nephropathy.',5,1,0,2,'','','','','uploads/project/hca_spreadsheet-humphreys_final_sep_4.xlsx','',NULL,NULL,NULL,NULL,NULL,'2019-09-04','2019-09-16',NULL,'2019-09-06',8,'','no issues, can\'t be analyzed by DCP at the moment',3,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(13,'HumanIlcSubsetsHumblesWang','Single cell RNAseq of human innate lymphoid cells (ILC)','Single cell RNAseq of human ILCs to investigate potential heterogeneity within ILC subsets',5,1,0,1,'','','/uploads/project/GSE114396.xlsx','','','GSE114396',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(16,'HumanNaturalKillerDiversityYang','The Developmental Heterogeneity of Human Natural Killer Cells Defined by Single-cell Transcriptome','The heterogeneity of human NK cells has not been fully-defined. Using single-cell RNA-sequencing technology, we find more human NK subsets than previously defined by cell surface markers. The transcriptome-based pseudotime analysis support that CD56bright NK cells are precursors of CD56dim NK cells with identification of a transitional stage. Our data significantly expand our understanding of the heterogeneity and development of human NK cells.',5,1,0,1,'','','/uploads/project/GSE130430.xlsx','','','GSE130430',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(17,'PreCdcFateTxFactCompetition','Single Cell RNA-Seq Analysis Reveals  Fate Decision of Human Pre-cDC Determined  by Transcription Factor Competition','Classic dendritic cells (cDCs) play a central role in the immune system and consist of two major subsets: CD141+ cDC (cDC1) and CD1c+ cDC (cDC2). The pre-cDCs is the immediate precursors to both cDC subsets. Previous studies showed that there were two pre-committed pre-cDC subpopulations. However, the key molecular drivers of pre-commitment in human pre-cDCs were not investigated. To address this question, we performed both single cell and bulk RNA sequencing (RNA-seq) of two cDC subsets and pre-cDCs. We inferred a list of sixteen candidate master regulator transcriptional factors (TFs) that can indeed separate pre-cDCs into two sub-populations, with one close to cDC1 and the other close to cDC2. More importantly, these two pre-cDC sub-populations are correlated with ratio of IRF8 to IRF4 expression level more than their individual expression level. Our results suggest the concept that the ratio of antagonistic TFs and their competition determine cDC subset differentiation fate.',5,1,0,1,'','','/uploads/project/GSE89322.xlsx','','','GSE89322',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(15,'HumanDevoRetinaHuTang','Dissecting the transcriptome landscape of human neural retina and retinal pigment epithelium by Single-cell RNA sequenci','The developmental pathway of the neural retina (NR) and retinal pigment epithelium (RPE) has been revealed by extensive research in mice. However, the molecular mechanisms underlying the development of the human NR and RPE, as well as the interactions between these two tissues, have not been well defined. Here, we analyzed 2,421 individual cells from human fetal NR and RPE using single-cell RNA sequencing (RNA-seq) technique and revealed the tightly regulated spatiotemporal gene expression network of human retinal cells. We identified major cell classes of human fetal retina and potential crucial transcription factors for each cell class. We dissected the dynamic expression patterns of visual cycle and ligand-receptor interaction related genes in the RPE and NR. Moreover, we provided a map of disease-related genes for human fetal retinal cells and highlighted the importance of retinal progenitor cells as potential targets of inherited retinal diseases. Our findings captured the key in vivo features of the development of the human NR and RPE and offered insightful clues for further functional studies.',5,1,0,1,'','','/uploads/project/GSE107618.xlsx','','','GSE107618',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(18,'CsfFromTwinsDiscordantForMultSclerosis','Single-cell RNA-seq in monozygotic twins discordant for multiple sclerosis','Here we investigated the earliest possible evidence of subclinical neuro-inflammation (SCNI) using a small cohort of monozygotic twins where one sibling had clinically definite MS and the other been clinically \\\"healthy\\\" but has a maximal genetic for developing MS. In contrast to subjects with radiologically isolated syndrome (RIS), our group of very early SCNI does not even fulfill the (arbitrary) MRI criteria for RIS but have more subtle MRI changes and/or evidence of neuro-inflammation in the CSF, e.g. oligoclonal bands (OCBs). For analyzing CSF samples from Twin pairs and controls in greater detail we applied single-cell whole transcriptome sequencing (scRNAseq). Our findings demonstrate that even the earliest experimentally approachable stage of MS is characterized by synergistic activation of CD8+ T cells, CD4+ T cells and B cells.',5,1,0,1,'','','/uploads/project/GSE127969.xlsx','','','GSE127969',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(19,'MammalSomatogenEndodermLiXu','Single Cell Transcriptome of Mouse and Human Endoderm at early somitogenesis stages','Defining the patterning of the definitive endoderm is critical for understanding the mechanisms of organogenesis and internal organ regeneration, yet the cell types and precise regionalization of the endoderm remain unclear, especially in humans. We performed well-based single-cell RNA-sequencing on dissected regional endoderm cells during the early somitogenesis stages in mice and humans. We developed molecular criteria with experimental verification and identified four major endoderm regions and their temporal formation pathways. In each region, we determined the cell subpopulations and their spatial distributions and defined molecular features along the body axes. Moreover, we discovered that dorsal and ventral pancreatic progenitors originate from midgut cells, following distinct pathways to develop into an identical cell type. Finally, we defined the generally conserved endoderm patterning in humans, with obvious differences in dorsal cell distribution. Thus, our study comprehensively defined endoderm patterning and provided novel insights to understand the regulation of endoderm specification.',5,1,0,1,'','','/uploads/project/GSE135889.xlsx','','','GSE135889',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(22,'HumanSkinBloodHypSensAndNormalKim','Single-cell RNA-sequencing of skin, fresh blood, and cultured peripheral blood mononuclear cells from a patient with dru','Purpose: Determine new therapeutic targets for a refractory drug-induced hypersensitivity syndrome/DRESS using single cell transcriptomic analysis.',5,1,0,1,'','','/uploads/project/GSE132802.xlsx','','','GSE132802',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(23,'Human5Ovary10xChuva','Single-cell analysis of adult human ovary using 10X genomics','The ovary is perhaps the most dynamic organ in the human body, only rivaled by the uterus. The molecular mechanisms that regulate follicular growth and regression, ensuring ovarian tissue homeostasis, remain elusive. We have performed single-cell RNA-sequencing using human adult ovaries to provide a map of the molecular signature of growing and regressing follicular populations. We have identified different types of granulosa and theca cells and detected local production of components of the complement system by (atretic) theca cells and stromal cells. We also have detected a mixture of adaptive and innate immune cells, as well as several types of endothelial and smooth muscle cells to aid the remodeling process. Our results highlight the relevance of mapping whole adult organs at the single-cell level and reflect ongoing efforts to map the human body. The association between complement system and follicular remodeling may provide key insights in reproductive biology and (in)fertility.',5,1,0,1,'','','/uploads/project/GSE118127.xlsx','','','GSE118127',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(21,'HumanDevoKidneyOrganoidsRansick','Single Cell RNA-Seq profiling of human embryonic kidney outer and inner cortical cells and kidney organoid cells','To study the developmental process of human podocytes and compare to the in vitro counterpart, we dissociated cells from the inner and outer kidney cortex as well as kidney organoids, and performed 10X Genomics single-cell RNA sequencing.',5,1,0,1,'','','/uploads/project/GSE124472.xlsx','','','GSE124472',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(24,'HumanMarrowIntegrationButlerStuart','Comprehensive integration of single-cell data','Single-cell transcriptomics (scRNA-seq) has transformed our ability to discover and annotate cell types and states, but deep biological understanding requires more than a taxonomic listing of clusters. As new methods arise to measure distinct cellular modalities, including high-dimensional immunophenotypes, chromatin accessibility, and spatial positioning, a key analytical challenge is to integrate these datasets into a harmonized atlas that can be used to better understand cellular identity and function. Here, we developed a computational strategy to \\\"anchor\\\" diverse datasets together, enabling us to integrate and compare single-cell measurements not only across scRNA-seq technologies, but different modalities as well. As one demonstration of the method, we anchor single-cell protein measurements with a human bone marrow atlas to annotate and characterize lymphocyte populations. The multimodal data, generated using CITE-seq, is provided here alongside a corresponding bulk validation experiment.',5,1,0,1,'','','/uploads/project/GSE128639.xlsx','','','GSE128639',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(25,'HumanQuickAdultKidneyLiaoMo','Single-cell RNA sequencing of human kidney','A comprehensive cellular anatomy of normal human kidney is vital to address the cellular origins of renal disease and renal cancer. Some kidney diseases may be cell type-specific, especially renal tubular cells. To investigate the classification and transcriptomic information of human kidney, we performed a method to obtain single-cell suspension of kidney rapidly, and conducted single-cell RNA sequencing (scRNA-seq). We present scRNA-seq data of 22,808 high quality cells from human kidneys of 3 donors. In this dataset, we show 13 clusters of normal human renal cells. Due to the high quality of single cell transcriptomic information, proximal tubule (PT) cells were classified into 6 subtypes and collecting ducts cells into 2 subtypes. Collectively, our data will provide a reliable reference for the studies of renal cell biology and kidney diseases.',5,1,22808,1,'','','/uploads/project/GSE131685.xlsx','','','GSE131685',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(26,'HumanPhagocytesHealthyLupusDutetre','Single-cell omics reveal human mononuclear phagocyte heterogeneity and inflammatory DC in health and disease','Human mononuclear phagocytes comprise phenotypically and functionally overlapping subsets of dendritic cells (DC) and monocytes, but their identification remains elusive. By integrating high-dimensional single-cell protein and RNA expression data, we clearly delineated monocytes from conventional DC2 (cDC2), identifying new markers including CD88/CD89 for monocytes and HLA-DQ/Fcï¥RIï¡ for cDC2, allowing their unambiguous characterization in blood and tissues. We also show that cDC2 can be subdivided into phenotypically and functionally distinct subsets based on CD5, CD163 and CD14 expression, including a unique subset of circulating inflammatory CD5-CD163+CD14+ cells related to previously defined DC3. These inflammatory DC3 were expanded in systemic lupus erythematosus patients, correlating with disease activity. Unravelling the heterogeneity of DC sub-populations in health and disease paves the way for specific DC subset-targeting therapies.',5,1,0,1,'','','/uploads/project/GSE132566.xlsx','','','GSE132566',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(27,'HumanFoveaRetinaScheetzSheffield','Single-cell RNA-Seq Investigation of Foveal and Peripheral Expression in the Human Retina','Purpose: Single-cell RNA sequencing has revolutionized cell-type specific gene expression analysis. The goals of this study are to compare cell specific gene expression patterns between retinal cell types originating from the fovea and the periphery of human eyes.',5,1,0,1,'','','/uploads/project/GSE130636.xlsx','','','GSE130636',NULL,NULL,NULL,'2019-09-06',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(28,'HumanColonicMesenchymeIBD','Structural Remodeling of the Human Colonic Mesenchyme in Inflammatory Bowel Disease','Intestinal mesenchymal cells play essential roles in epithelial homeostasis, matrix remodeling, immunity, and inflammation. But the extent of heterogeneity within the colonic mesenchyme in these processes remains unknown. Using unbiased single-cell profiling of over 16,500 colonic mesenchymal cells, we reveal four subsets of fibroblasts expressing divergent transcriptional regulators and functional pathways, in addition to pericytes and myofibroblasts. We identified a niche population located in proximity to epithelial crypts expressing SOX6, F3 (CD142), and WNT genes essential for colonic epithelial stem cell function. In colitis, we observed dysregulation of this niche and emergence of an activated mesenchymal population. This subset expressed TNF superfamily member 14 (TNFSF14), fibroblastic reticular cell-associated genes, IL-33, and Lysyl oxidases. Further, it induced factors that impaired epithelial proliferation and maturation and contributed to oxidative stress and disease severity in vivo. Our work defines how the colonic mesenchyme remodels to fuel inflammation and barrier dysfunction in IBD.',4,3,0,2,'','','','','uploads/project/hca-metadata-spreadsheet-GSE95459-GSE114374-colon.xlsx','',NULL,NULL,NULL,NULL,NULL,'2019-07-26',NULL,NULL,'2019-07-26',10,'','',9,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(29,'Tissue stability','Ischaemic sensitivity of human tissue by single cell RNA seq','Assessment of ischaemic sensitivity of human tissues using 10x 3\\\' single cell RNA sequencing. This project contains data for spleen, oesophagus epithelium and lung parenchyma (based on previously published bulk RNA-seq data, we expect spleen to be the least sensitive to ischaemia and lung to be the most). Samples will be collected into hypothermasol FRS hypothermic preservation media and dissociated fresh (i.e. as soon as possible) or at 12h, 24h, 72h post onset of ischaemia in the donor. Single cell RNA sequencing data will be generated at each time point using the 10x genomics single cell 3\\\' method.',5,3,0,2,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-15',10,'','',9,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(30,'demo HPSI human cerebral organoids','demo - Assessing the relevance of organoids to model inter-individual variation','demo - Assessing the relevance of organoids to model inter-individual variation',4,3,0,2,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-06-20',8,'','',9,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(31,'Mouse Melanoma','Melanoma infiltration of stromal and immune cells','The cancer microenvironment is a complex ecosystem characterized by dynamic interactions between diverse cell types, including malignant, immune and stromal cells. Here, we performed single-cell RNA sequencing on CD45+ and CD45- cells isolated from tumour and lymph nodes during a mouse model of melanoma. The transcriptional profiles of these individual cells taken at different time points coupled with assembled T cell receptor sequences, allowed us to identify distinct immune subpopulations and delineate their developmental trajectory. Our study provides insights into the complex interplay among cells within the tumour microenvironment and presents a valuable resource for future translational applications.',3,2,0,2,'','','','','uploads/project/mf-Teichmann-spreadsheet-v10.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-14',8,'','',12,9,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(32,'KidneySingleCellAtlas','Spatio-temporal immune zonation of the human kidney','1) Kidneys from fetal tissue aged 7-16 post conception weeks, flow sorted into CD45+ and CD45-. 10X scRNAseq. 2) Kidneys from tumour nephrectomy and declined transplant organs, live dead selection. 10x scRNAseq. 3) Kidneys from tumour nephrectomy and declined transplant organs, percoll leukocyte enrichment, live dead selection. 10x scRNAseq.',5,3,0,2,'','','','','uploads/project/hca-metadata-spreadsheet-Stewart-kidney_2019_08_12_Enrique_Rereview.xlsx','',NULL,NULL,NULL,NULL,NULL,'2019-08-13',NULL,NULL,'2019-08-12',9,'','',14,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(33,'Multiplexed scRNA-seq with barcoded antibodies','Cell hashing with barcoded antibodies enables multiplexing and doublet detection for single cell genomics','Despite rapid developments in single cell sequencing technology, sample-specific batch effects, detection of cell doublets, and the cost of generating massive datasets remain outstanding challenges. Here, we introduce cell hashing, where oligo-tagged antibodies against ubiquitously expressed surface proteins are used to uniquely label cells from distinct samples, which can be subsequently pooled. By sequencing these tags alongside the cellular transcriptome, we can assign each cell to its sample of origin, and robustly identify doublets originating from multiple samples. We demonstrate our approach by pooling eight human PBMC samples on a single run of the 10x Chromium system, substantially reducing our per-cell costs for library generation. Cell hashing is inspired by, and complementary to, elegant multiplexing strategies based on genetic variation, which we also leverage to validate our results. We therefore envision that our approach will help to generalize the benefits of single cell multiplexing to diverse samples and experimental designs.',4,3,0,2,'','','','','uploads/project/Sajita_re-ingest.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-17',8,'','',5,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(34,'HPSI human cerebral organoids','Assessing the relevance of organoids to model inter-individual variation','The purpose of this project is to assess the relevance of pluripotent stem cell-derived cerebral and liver organoids to recapitulate the variation in cell-type specific gene expression programs between individuals. Towards this aim, we will generate reference atlases of the developing cortex and liver from multiple individuals, derive iPSC lines from these same individuals, and determine if inter-individual gene expression variation is recapitulated in cerebral and liver organoids from the same individual from which we have reference maps. In parallel we will assess the genetic contribution to variablity between organoids from different iPSCs of multiple human individuals that are available in existing iPSC resources (e.g. HipSci).',4,3,0,2,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-15',10,'','',9,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(36,'Healthy and type 2 diabetes pancreas','Single-cell RNA-seq analysis of human pancreas from healthy individuals and type 2 diabetes patients','We used single-cell RNA-sequencing to generate transcriptional profiles of endocrine and exocrine cell types of the human pancreas. Pancreatic tissue and islets were obtained from six healthy and four T2D cadaveric donors. Islets were cultured and dissociated into single-cell suspension. Viable individual cells were distributed via fluorescence-activated cell sorted (FACS) into 384-well plates containing lysis buffer. Single-cell cDNA libraries were generated using the Smart-seq2 protocol. Gene expression was quantified as reads per kilobase transcript and per million mapped reads (RPKM) using rpkmforgenes. Bioinformatics analysis was used to classify cells into cell types without knowledge of cell types or prior purification of cell populations. We revealed subpopulations in endocrine and exocrine cell types, identified genes with interesting correlations to body mass index (BMI) in specific cell types and found transcriptional alterations in T2D. Complementary whole-islet RNA-seq data have also been deposited at ArrayExpress under accession number E-MTAB-5060 (http://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-5060).',5,3,0,2,'','','','','uploads/project/mf-E-MTAB-5061_spreadsheet_v7.xlsx','E-MTAB-5061',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-14',8,'','',9,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(37,'Single cell transcriptome analysis of human pancreas','Single cell transcriptome analysis of human pancreas reveals transcriptional signatures of aging and somatic mutation pa','As organisms age, cells accumulate genetic and epigenetic changes that eventually lead to impaired organ function or catastrophic failure such as cancer. Here we describe a single-cell transcriptome analysis of 2544 human pancreas cells from donors, spanning six decades of life. We find that islet cells from older donors have increased levels of disorder as measured both by noise in the transcriptome and by the number of cells which display inappropriate hormone expression, revealing a transcriptional instability associated with aging. By analyzing the spectrum of somatic mutations in single cells from previously-healthy donors, we find a specific age-dependent mutational signature characterized by C to A and C to G transversions, indicators of oxidative stress, which is absent in single cells from human brain tissue or in a tumor cell line. Cells carrying a high load of such mutations also express higher levels of stress and senescence markers, including FOS, JUN, and the cytoplasmic superoxide dismutase SOD1, markers previously linked to pancreatic diseases with substantial age-dependent risk, such as type 2 diabetes mellitus and adenocarcinoma. Thus, our single-cell approach unveils gene expression changes and somatic mutations acquired in aging human tissue, and identifies molecular pathways induced by these genetic changes that could influence human disease. Also, our results demonstrate the feasibility of using single-cell RNA-seq data from primary cells to derive meaningful insights into the genetic processes that operate on aging human tissue and to determine which molecular mechanisms are coordinated with these processes. Examination of single cells from primary human pancreas tissue',5,3,0,2,'','','','','uploads/project/E-GEOD-81547_curated_ontologies_07_2019.xlsx','GSE81547',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-10',10,'','',11,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(38,'Single cell RNAseq characterization of cell types produced over time','Single-cell RNA-seq analysis  throughout a 125-day differentiation protocol that converted H1 human embryonic stem cells','Diverse cell types are produced from dorsal and ventral regions of the developing neural tube. In this study we describe a system for generating human inhibitory interneurons by ventralizing human embryonic stem cells in vitro and characterizing the gene expression of the cell types produced over time. We engineered a DCX-Citrine/Y hESC line to sort and characterize progenitor and neuron transcriptomics separately at both the subpopulation and single cell level. The cells generated in vitro were compared to similar populations present in human fetal brain samples by mapping gene expression data from human fetal cells onto the principal component analysis (PCA) space of in vitro-derived populations. Weighted gene co-expression network analysis (WGCNA) was used to determine the discreet cell types present at D24, D54, D100 and D125 of culture, and describe the gene expression changes that occur in progenitor and neuron populations over time. Immature lateral ganglionic eminence and medial ganglionic eminence cells are present at early timepoints, along with MGE-like and dorsal pallium-like neuronal progenitors. At later timepoints we observe the emergence of SST-expressing interneurons, as well as oligodendrocyte and astrocyte progenitors. We also identified genes that were upregulated in somatostatin-expressing interneurons as they mature. The transcriptomes of 1732 ventralized single cells were profiled by SmartSeq2 at different timepoints throughout a 125-day differentiation protocol that converted H1 human embryonic stem cells to a variety of ventrally-derived cell types.',4,3,0,2,'','','','','uploads/project/GEOD-93593_HCA_Ontologies_July_2.xlsx','GSE93802',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-14',10,'','',11,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(39,'Kidney biopsy scRNA-seq','Single Cell Transcriptomics of a Human Kidney Allograft Biopsy Defines a Diverse Inflammatory Response','Single cell genomics are revolutionizing our ability to characterize complex tissues. By contrast, the techniques used to analyze the renal biopsy are little changed over the past several decades. In this study we have tested the hypothesis that single cell RNA sequencing (sc-RNA-seq) can comprehensively describe cell types and states in a human kidney biopsy. We generated 8,746 single cell cell transcriptomes from a healthy adult kidney and a single kidney transplant biopsy core by sc-RNA-seq. Unsupervised clustering analysis of the biopsy identified 16 distinct cell types, including all of the major immune cell types and most native kidney cell types in this biopsy whose histologic read was mixed rejection. Endothelial cells formed three distinct sub-clusters: resting cells and two activated endothelial cell clusters, including expression of Fc-receptor pathway activation and immunoglobulin internalization genes, consistent with the pathologic diagnosis of antibody-mediated rejection. Monocytes formed two sub-clusters representing a non-classical CD16+ group and a classical CD16- group expressing dendritic cell maturation markers. The presence of both monocyte cell subtypes was validated by staining of of independent transplant biopsies. Comparison of healthy kidney epithelial transcriptomes to their biopsy counterparts identified novel segment specific pro-inflammatory responses. We mapped previously defined genes that associate with rejection outcomes to single cell types and generated a searchable online gene expression database. These findings represent a first step towards incorporation of single cell transcriptomics into kidney biopsy interpretation, describe a heterogeneous immune response in mixed rejection and provide a searchable resource for the scientific community.',4,3,8746,2,'','','','','uploads/project/Humphreys_re-ingest.xlsx','GSE109564',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-16',8,'','',3,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(40,'BM_PC','Bone marrow plasma cells from hip replacement surgeries','Our aims are to generate a full representation of human hematopoiesis in blood and bone marrow of humans using a multi-tier and iterative collection and analysis of 200,000 cells from ten healthy human bone marrow donors',4,3,199969,2,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-16',8,'Spreadsheet doesn\'t open in excel','',11,NULL,NULL,'',NULL,'',NULL,'','https://drive.google.com/drive/u/0/folders/1SK3eMQP8vX5BuI46-LcDg2kJyeSg2jlQ',NULL,''),(41,'Human Hematopoietic Profiling','Profiling of CD34+ cells from human bone marrow to understand hematopoiesis','Differentiation is among the most fundamental processes in cell biology. Single cell RNA-seq studies have demonstrated that differentiation is a continuous process and in particular cell states are observed to reside on largely continuous spaces. We have developed Palantir, a graph based algorithm to model continuities in cell state transitions and cell fate choices. Modeling differentiation as a Markov chain, Palantir determines probabilities of reaching terminal states from cells in each intermediate state. The entropy of these probabilities represent the differentiation potential of the cell in the corresponding state. Applied to single cell RNA-seq dataset of CD34+ hematopoietic cells from human bone marrows, Palantir accurately identified key events leading up to cell fate commitment. Integration with ATAC-seq data from bulk sorted populations helped identify key regulators that correlate with cell fate specification and commitment.',5,3,41000,2,'','','','','uploads/project/Peer_re-ingest.xlsx','',NULL,NULL,NULL,NULL,NULL,'2019-07-18',NULL,NULL,'2019-07-18',8,'','',3,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(43,'SingleCellLiverLandscape','Dissecting the human liver cellular landscape by single cell RNA-seq reveals novel intrahepatic monocyte/ macrophage pop','The liver is the largest solid organ in the body and is critical for metabolic and immune functions. However, little is known about the cells that make up the human liver and its immune microenvironment. Here we report a map of the cellular landscape of the human liver using single-cell RNA sequencing. We provide the transcriptional profiles of 8444 parenchymal and non-parenchymal cells obtained from the fractionation of fresh hepatic tissue from five human livers. Using gene expression patterns, flow cytometry, and immunohistochemical examinations, we identify 20 discrete cell populations of hepatocytes, endothelial cells, cholangiocytes, hepatic stellate cells, B cells, conventional and non-conventional T cells, NK-like cells, and distinct intrahepatic monocyte/macrophage populations. Together, our study presents a comprehensive view of the human liver at single-cell resolution that outlines the characteristics of resident cells in the liver, and in particular provides a map of the human hepatic immune microenvironment.',5,3,8444,2,'','','','','','GSE115469',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-06-28',8,'','',5,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(44,'WongAdultRetina','A single-cell transcriptome atlas of the adult human retina','The retina is a specialized neural tissue that senses light and initiates image processing. Although the functional organization of specific retina cells has been well studied, the molecular profile of many cell types remains unclear in humans. To comprehensively profile the human retina, we performed single?cell RNA sequencing on 20,009 cells from three donors and compiled a reference transcriptome atlas. Using unsupervised clustering analysis, we identified 18 transcriptionally distinct cell populations representing all known neural retinal cells: rod photoreceptors, cone photoreceptors, Müller glia, bipolar cells, amacrine cells, retinal ganglion cells, horizontal cells, astrocytes, and microglia. Our data captured molecular profiles for healthy and putative early degenerating rod photoreceptors, and revealed the loss of MALAT1 expression with longer post?mortem time, which potentially suggested a novel role of MALAT1 in rod photoreceptor degeneration. We have demonstrated the use of this retina transcriptome atlas to benchmark pluripotent stem cell?derived cone photoreceptors and an adult Müller glia cell line. This work provides an important reference with unprecedented insights into the transcriptional landscape of human retinal cells, which is fundamental to understanding retinal biology and disease.',5,3,20009,2,'','','','','uploads/project/wong-adult-retina-hca_spreadsheet-20190909.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-09',8,'','',15,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(45,'Drop-seq, DroNc-seq, Fluidigm C1 Comparison','Comparison, calibration, and benchmarking of high-throughput single cell RNA-Seq techniques for unbiased cell-type class','The Human Cell Atlas project seeks to identify and functionally characterize all cell types in the human body. Single-cell RNA-sequencing (scRNA-seq) methods quantify gene expression in individual cells. In principle, highly parallelized scRNA-seq approaches enable marker-free decomposition of cells from complex tissues to identify known and unknown cell types and provide direct insights into regulatory and functional states of each cell. Different scRNA-seq technologies vary in cell capture efficiency, library preparation, and throughput. Importantly, these approaches also vary in sensitivity and accuracy of mRNA quantification. The Human Cell Atlas project will collate data generated across many labs, necessitating the evaluation of experimental replicability, and comparing different experimental procedures. It is important to develop robust sequencing protocols and benchmark their performance on select cells and tissues. This project will perform a systematic comparison of three single cell RNA sequencing technologies, viz., Drop-Seq, Fluidigm C1, and DroNC-Seq and resulting datasets. Droplet-based methods facilitate high-throughput processing of tens of thousands of cells in parallel and at low costs, making them ideal for the Human Cell Atlas project. This project proposes to compare the sensitivity, accuracy, and precision with which the three methods quantify transcript levels within individual cells. In addition, this project will directly compare these methods using a ‘synthetic tissue’ created from a mixture of multiple cell types at known ratios.',4,3,0,2,'','','','','uploads/project/Basu_May_re-ingest.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-15',8,'','',3,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(46,'1M Immune Cells','Census of Immune Cells','Diverse cells of the immune system maintain and protect tissue function, integrity, and homeostasis upon changes in functional demands and diverse perturbations. Recent advances such as massively parallel single-cell RNA-sequencing and sophisticated computational methods help shed new light on this complexity. This immune cell census aims to profile up to 2M immunocytes, the first tranche of this is currently available. With computational methods optimized to a massive scale, we can readily identify cell types and markers, as well as the process of hematopoietic differentiation. The high quality and comprehensive reference map is provided as an open community resource for understanding human health and disease.',5,3,0,2,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-07-03',10,'','',9,12,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(47,'1M Neurons','1.3 Million Brain Cells from E18 Mice','Cortex, hippocampus, and subventricular zone were purchased from BrainBits (C57EHCV). They were from 2 E18 C57BL/6 mice dissected on the same day, shipped overnight on ice, and stored at 4C until being prepared for scRNA-Seq. Brain tissues were dissociated following the Demonstrated Protocol for Mouse Embryonic Neural Tissue (https://support.10xgenomics.com/single-cell/sample-prep/doc/demonstrated-protocol-dissociation-of-mouse-embryonic-neural-tissue-for-single-cell-rna-sequencing). 69 scRNA-Seq libraries were made from first mouse brain 2 days after the dissection. Another 64 scRNA-Seq libraries were made from second mouse brain 6 days after the dissection.',4,2,1300000,2,'','','','','uploads/project/10x_05_16.xlsx','GSE93421',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-16',8,'','',5,NULL,NULL,'',NULL,'','https://github.com/HumanCellAtlas/hca-data-wrangling/issues/17','',NULL,NULL,''),(48,'Fetal/Maternal Interface','Reconstructing the human first trimester fetal-maternal interface using single cell transcriptomics','During early human pregnancy the uterine mucosa transforms into the decidua, into which the fetal placenta implants and where placental trophoblast cells intermingle and communicate with maternal cells. Trophoblast–decidual interactions underlie common diseases of pregnancy, including pre-eclampsia and stillbirth. Here we profile the transcriptomes of about 70,000 single cells from first-trimester placentas with matched maternal blood and decidual cells. The cellular composition of human decidua reveals subsets of perivascular and stromal cells that are located in distinct decidual layers. There are three major subsets of decidual natural killer cells that have distinctive immunomodulatory and chemokine profiles. We develop a repository of ligand–receptor complexes and a statistical tool to predict the cell-type specificity of cell–cell communication via these molecular interactions. Our data identify many regulatory interactions that prevent harmful innate or adaptive immune responses in this environment. Our single-cell atlas of the maternal–fetal interface reveals the cellular organization of the decidua and placenta, and the interactions that are critical for placentation and reproductive success.',5,3,0,2,'','','','','uploads/project/zp-fetal-maternal-interface-reingest.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-15',10,'','',16,9,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(49,'CD4+ cytotoxic T lymphocytes','Precursors of human CD4+ cytotoxic T lymphocytes identified by single-cell transcriptome analysis','CD4+ cytotoxic T lymphocytes (CD4-CTLs) have been reported to play a protective role in several viral infections. However, little is known in humans about the biology of CD4-CTL generation, their functional properties, heterogeneity and clonal diversity, especially in relation to other well-described CD4+ memory T cell subsets. We performed single-cell RNA-seq in over 9000 cells to unravel CD4-CTL heterogeneity, transcriptional profile and clonality in humans. The single-cell differential gene expression analysis, revealed a spectrum of known transcripts, including several linked to cytotoxic and co-stimulatory function, and transcripts of unknown cytotoxicity-related function that are expressed at higher levels in the TEMRA subset, which is highly enriched for CD4-CTLs, compared to cells in the central and effector memory subsets (TCM, TEM). Simultaneous T cells antigen receptor (TCR) analysis in single-cells and bulk subsets revealed that CD4-TEMRA cells show marked clonal expansion compared to TCM and TEM cells and that the majority of CD4-TEMRA were dengue virus (DENV)-specific in subjects with previous DENV infection. The profile of CD4-TEMRA was highly heterogeneous across subjects, with four distinct clusters identified by the single-cell analysis. Most importantly, we identified distinct clusters of CD4-CTL effector and precursor cells in the TEMRA subset; the precursor cells shared TCR clonotypes with CD4-CTL effectors and were distinguished by high expression of the interleukin-7 receptor. Our identification of a CD4-CTL precursor population may allow further investigation of how CD4-CTLs arise in humans and thus could provide insights into the mechanisms that may be utilized to generate durable and effective CD4-CTL immunity.',5,3,0,2,'','','','','uploads/project/mf-E-GEOD-106540_spreadsheet_v9.xlsx','GSE106544',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-05-16',8,'','',9,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(50,'HDCA-Sweden-10x','HDCA project: single cell transcriptomics','This project is part of the Swedish Human Developmental Cell Atlas: a comprehensive molecular atlas of human prenatal development, describing every cell type in molecular detail, and showing the spatial distribution of cells in three dimensions and their development over time. The project will focus on developmental tissue from brain, lung and heart. This part of the project is generating single cell gene expression profiles using high-throughput single cell mRNA sequencing with the aim to identify and characterize molecularly defined celltypes.',5,3,0,2,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-07-12',8,'','',16,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(51,'HumanTissueTcellActivation','A single-cell reference map of transcriptional states for human blood and tissue T cell activation','Human T cells coordinate adaptive immunity in diverse anatomic compartments through production of cytokines and effector molecules, but it is unclear how tissue site influences T cell persistence and function. Here, we use single cell RNA-sequencing (scRNA-seq) to define the heterogeneity of human T cells isolated from lungs, lymph nodes, bone marrow and blood, and their functional responses following stimulation. Through analysis of >50,000 resting and activated T cells, we reveal tissue T cell signatures in mucosal and lymphoid sites, and lineage-specific activation states across all sites including distinct effector states for CD8+ T cells and an interferon-response state for CD4+ T cells. Comparing scRNA-seq profiles of tumor-associated T cells to our dataset reveals predominant activated CD8+ compared to CD4+ T cell states within multiple tumor types. Our results therefore establish a high dimensional reference map of human T cell activation in health for analyzing T cells in disease.',5,3,0,2,'','','','','uploads/project/hca_spreadsheet_Sep_9_2019_TCell_Levitin.xlsx','GSE126030',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-09',9,'','',4,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(52,'HumanMousePancreas','A Single-Cell Transcriptomic Map of the Human and Mouse Pancreas Reveals Inter- and Intra-cell Population Structure','Although the function of the mammalian pancreas hinges on complex interactions of distinct cell types, gene expression profiles have primarily been described with bulk mixtures. Here we implemented a droplet-based, single-cell RNA-seq method to determine the transcriptomes of over 12,000 individual pancreatic cells from four human donors and two mouse strains. Cells could be divided into 15 clusters that matched previously characterized cell types: all endocrine cell types, including rare epsilon-cells; exocrine cell types; vascular cells; Schwann cells; quiescent and activated stellate cells; and four types of immune cells. We detected subpopulations of ductal cells with distinct expression profiles and validated their existence with immuno-histochemistry stains. Moreover, among human beta- cells, we detected heterogeneity in the regulation of genes relating to functional maturation and levels of ER stress. Finally, we deconvolved bulk gene expression samples using the single-cell data to detect disease-associated differential expression. Our dataset provides a resource for the discovery of novel cell type-specific transcription factors, signaling receptors, and medically relevant genes.',4,3,12000,2,'','','','','uploads/project/hca-metadata-spreadsheet-GSE84133_pancreas.xlsx','GSE84133',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-07-04',8,'','',9,NULL,NULL,'',NULL,'',NULL,'','https://docs.google.com/spreadsheets/d/1Wahht2XB5XsLKwQSoyYmqccB8NEHtW-2WGq-XYC7r5U/edit#gid=2057378522',NULL,''),(53,'MouseGastrulationAtlas','A single-cell molecular map of mouse gastrulation and early organogenesis','Across the animal kingdom, gastrulation represents a key developmental event during which embryonic pluripotent cells diversify into lineage-specific precursors that will generate the adult organism. Here we report the transcriptional profiles of 116,312 single cells from mouse embryos collected at nine sequential time points ranging from 6.5 to 8.5 days post-fertilization. We construct a molecular map of cellular differentiation from pluripotency towards all major embryonic lineages, and explore the complex events involved in the convergence of visceral and primitive streak-derived endoderm.',4,2,116312,2,'','','','','uploads/project/esv_Marioni_Atlas_MouseGastrulation_10_06_2019_ZP_1.xlsx','',NULL,NULL,NULL,NULL,NULL,'2019-08-08',NULL,NULL,NULL,4,'','',14,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(56,'AirwayEpitheliumPulmonaryIonocyte','A single cell atlas of the airway epithelium reveals the CFTR-rich pulmonary ionocyte','The functions of epithelial tissues are dictated by the types, abundance, and distribution of the differentiated cells they contain. Attempts to restore tissue function after damage require knowledge of how physiological tasks are distributed among cell types, and how cell states vary between homeostasis, injury/repair, and disease. In the conducting airway, a heterogeneous basal cell population gives rise to specialized luminal cells that perform mucociliary clearance. We performed single cell profiling of human bronchial epithelial cells and mouse tracheal epithelial cells to obtain a comprehensive picture of cell types in the conducting airway and their behavior in homeostasis and regeneration. Our analysis reveals cell states that represent known and novel cell populations, delineates their heterogeneity, and identifies distinct differentiation trajectories during homeostasis and tissue repair. Finally, we identified a novel, rare cell type, which we call the \"\"pulmonary ionocyte\"\", that co-expresses FOXI1, multiple subunits of the V-ATPase, and CFTR, the gene mutated in cystic fibrosis (CF). Using immunofluorescence, signaling pathway modulation, and electrophysiology, we show that Notch signaling is necessary and FOXI1 expression sufficient to drive the production of the pulmonary ionocyte, and that the pulmonary ionocyte is a major source of CFTR activity in the conducting airway epithelium.',4,1,0,1,'','','/uploads/project/GSE102580.xlsx','','','GSE102580',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(57,'CorticalNephrogenicNicheKidney','Single Cell RNA-Seq profiling human embryonic kidney cortex cells','To characterize the cellular diversity in the human kidney cortical nephrogenic niche we dissociated cells from the cortex and performed 10X Genomics single-cell RNA sequencing.',5,1,0,1,'','','/uploads/project/GSE102596.xlsx','','','GSE102596',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(58,'DevelopmentalLineageMouseMammaryGland','Single cell RNA-seq of mouse mammary gland epithelium cells','This SuperSeries is composed of the SubSeries listed below.',4,1,0,1,'','','/uploads/project/GSE103275.xlsx','','','GSE103275',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(59,'MouseMammaryEpithelialCells','Differentiation dynamics of mammary epithelial cells revealed by single-cell RNA-sequencing','The mammary gland is a unique organ as it undergoes most of its development during puberty and adulthood. Characterising the hierarchy of the various mammary epithelial cells and how they are regulated in response to gestation, lactation and involution is important for understanding how breast cancer develops. Recent studies have used numerous markers to enrich, isolate and characterise the different epithelial cell compartments within the adult mammary gland. However, in all of these studies only a handful of markers were used to define and trace cell populations. Therefore, there is a need for an unbiased and comprehensive description of mammary epithelial cells within the gland at different developmental stages. To this end we used single cell RNA sequencing (scRNAseq) to determine the gene expression profile of individual mammary epithelial cells across four adult developmental stages; nulliparous, mid gestation, lactation and post weaning (full natural involution). Our data from 25,010 individual cells identifies 8 distinct mammary epithelial cell populations and allows their hierarchical structure across development to be charted. Interestingly, the effect of gestation and lactation appeared to be more pronounced for some cell types. For example, our analysis revealed a cluster of luminal progenitor cells in post involution glands, which is distinct from progenitors found in nulliparous glands. The data also showed that few clusters could be fully characterized by a single marker gene. We argue instead that the epithelial cells â€“ especially in the luminal compartment â€“ should rather be conceptualized as being part of a continuous spectrum of differentiation. This view highlights the plasticity of the tissue and might help to explain some of the conflicting results from lineage tracing studies.',4,1,25000,1,'','','/uploads/project/GSE106273.xlsx','','','GSE106273',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(60,'SingleCellTranscriptomicsMouseKidney','Comprehensive single cell RNAseq analysis of the kidney reveals novel cell types and unexpected cell plasticity','We characterized 57,979 cells from healthy mouse kidneys using unbiased single-cell RNA sequencing. We show that genetic mutations that present with similar phenotypes mostly affect genes that are expressed in a single unique differentiated cell type. On the other hand, we found unexpected cell plasticity of epithelial cells in the final segment of the kidney (collecting duct) that is responsible for final composition of the urine. Using computational cell trajectory analysis and in vivo linage tracing, we found that, intercalated cells (that secrete protons) and principal cells (that maintain salt, water and potassium balance) undergo a Notch mediated interconversion via a newly identified transitional cell type. In disease states this transition is shifted towards the principal cell fate. Loss of intercalated cells likely contributes to metabolic acidosis observed in kidney disease.',4,1,0,1,'','','/uploads/project/GSE107585.xlsx','','','GSE107585',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(61,'TranscriptomeLandscapeHumanFollicle','Transcriptome Landscape of Human Folliculogenesis Reveals Oocytes and Granulosa Cells Interactions','The dynamic transcriptional regulation and interactions of human germlines and surrounding somatic cells during folliculogenesis remains unknown. Using RNA-Seq analysis of human oocytes and corresponding granulosa cells (GCs) spanning five follicular stages, we revealed unique features in transcriptional machinery, transcription factor networks and reciprocal interactions in human oocytes and GCs that displayed developmental-stage-specific expression patterns. Notably, we identified specific gene signatures of two cell types in particular developmental stage that may reflect developmental competency and ovarian reserve. Additionally, we uncovered key pathways that may concert germline-somatic interactions and drive the transition of primordial-to-primary follicle which represents follicle activation. Thus, our work provides key insights into the crucial features of the transcriptional regulation in the stepwise folliculogenesis and offers important clues for improving follicle recruitment in-vivo and restoring fully competent oocytes in-vitro.',4,1,0,1,'','','/uploads/project/GSE107746.xlsx','','','GSE107746',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(62,'HumanDermalFibroblastSubpopulations','Spatial and single-cell transcriptional profiling identifies functionally distinct human dermal fibroblast subpopulation','Fibroblasts synthesize the extracellular matrix of connective tissue and play an essential role in maintaining tissue integrity. We have previously shown that mouse skin connective tissue, the dermis, is comprised of functionally distinct fibroblast lineages. However, the extent of fibroblast heterogeneity in human skin is unknown. Here, using a combination of spatial transcriptional profiling of human and mouse dermis and single cell transcriptional profiling of human dermal fibroblasts, we show that there are at least four distinct fibroblast populations in adult human skin. We define markers permitting prospective isolation of these cells and show that although marker expression is rapidly lost in culture, different fibroblast subpopulations retain distinct functionality in terms of Wnt signalling, T cell communication and the ability to support human epidermal reconstitution in organotypic culture. Furthermore, while some fibroblast subpopulations are spatially segregated, others are not. These findings have profound implications for normal wound healing and diseases characterized by excessive fibrosis, and suggest that ex vivo expansion or in vivo ablation of specific fibroblast subpopulations may have therapeutic applications.',5,1,0,1,'','','/uploads/project/GSE109822.xlsx','','','GSE109822',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(63,'HumanDCsFromPre-cDCs','Single-cell RNA-seq reveals heterogeneity within human pre-cDCs','Here, we use a microfluidics-based approach to prepare single-cell RNA-Seq libraries from 164 primary human conventional dendritic cells (cDCs) as well as cord blood (452) and blood (341) pre-cDCs. We examined heterogeneity between individual cells to document potential subpopulations within human cDCs and pre-cDCs.',5,1,1000,1,'','','/uploads/project/GSE89232.xlsx','','','GSE89232',NULL,NULL,NULL,'2019-09-15',NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(64,'Mouse_J1_scRNA_seq_comparison','Comparative analysis of single-cell RNA sequencing methods','Single-cell RNA sequencing (scRNA-seq) offers new possibilities to address biological and medical questions. However, systematic comparisons of the performance of diverse scRNA-seq protocols are lacking. We generated data from 583 mouse embryonic stem cells to evaluate six prominent scRNA-seq methods: CEL-seq2, Drop-seq, MARS-seq, SCRB-seq, Smart-seq and Smart-seq2. While Smart-seq2 detected the most genes per cell and across cells, CEL-seq2, Drop-seq, MARS-seq and SCRB-seq quantified mRNA levels with less amplification noise due to the use of unique molecular identifiers (UMIs). Power simulations at different sequencing depths showed that Drop-seq is more cost-efficient for transcriptome quantification of large numbers of cells, while MARS-seq, SCRB-seq and Smart-seq2 are more efficient when analyzing fewer cells. Our quantitative comparison offers the basis for an informed choice among six prominent scRNA-seq methods and provides a framework for benchmarking further improvements of scRNA-seq protocols.',3,1,0,1,'','','uploads/project/GSE75790.xlsx','','','GSE75790',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,''),(65,'Reprogrammed_Dendritic_Cells','Single cell profilling of human induced dendritic cells generated by direct reprogramming of embryonic fibroblasts','Dendritic cells (DCs) are professional antigen-presenting cells specialized in the recognition, processing and presentation of antigens to T-cells, inducing adaptive immune responses. We have identified PU.1, IRF8 and BATF3 transcription factors (TFs) to reprogram human fibroblasts into DC type 1 (DC1). Induced DCs acquire a step-wise DC1 transcriptional signature at the single cell level as assessed with droplet based scRNA-seq. Hence, we provide evidence that antigen presentation can be dynamically programmed by a small combination of TFs in human cells. Moreover, it represents a platform for generating autologous DC1, the most attractive DC subset for cancer immunotherapy.',4,3,0,2,'','','','','uploads/project/filipe_spreadsheet_enrique_review_paris_review_9_20.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-20',9,'','',14,NULL,NULL,'',NULL,'',NULL,'',NULL,5,''),(66,'snRNA-seq_for_human_retina','Transcriptomic classification of human retinal cell types with single-nuclei RNA-seq.','The human neural retina is a heterogenous tissue that is an ordered array of approximately 70 different types of neurons, each playing a unique role in processing the visual signal. Currently, the transcriptomic-level classification of human retinal cell types is still limited. Using single-nuclei RNA-seq, a comprehensive single-cell profiling study has been carried out for healthy human retina from four individual donors. With the transcriptomic profiles for a total of over 200K nuclei being generated, we aim at revealing the transcriptome profiles for most subtypes of the retinal cells. Comparison with previous published macaque and mice dataset indicates an overall good alignment among species. In addition, the gene expression profile that is unique to human has been discovered. Furthermore, over 200 genes associated with human retinal diseases are investigated in our dataset and are found to show both cell type and regional specificity. In summary, results from our study serves as not only a cell atlas reference but also the foundation for future studies of human retinal diseases.',5,3,200000,2,'','','','','uploads/project/Rui_Chen_retina_ZPv5.xlsx','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-20',8,'','',5,NULL,NULL,'',NULL,'',NULL,'',NULL,5,''),(67,'scRNAseqSystemicComparison','Systematic comparative analysis of single cell RNA-sequencing methods','A multitude of single-cell RNA sequencing methods have been developed in recent years, with dramatic advances in scale and power, and enabling major discoveries and large scale cell mapping efforts. However, these methods have not been systematically and comprehensively benchmarked. Here, we directly compare seven methods for single cell and/or single nucleus profiling from three types of samples – cell lines, peripheral blood mononuclear cells and brain tissue – generating 36 libraries in six separate experiments in a single center. To analyze these datasets, we developed and applied scumi, a flexible computational pipeline that can be used for any scRNA-seq method. We evaluated the methods for both basic performance and for their ability to recover known biological information in the samples. Our study will help guide experiments with the methods in this study as well as serve as a benchmark for future studies and for computational algorithm development.',3,NULL,0,NULL,'','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,'',NULL,'',NULL,'',NULL,NULL,'');
/*!40000 ALTER TABLE `hcat_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_cdna_library_prep`
--

DROP TABLE IF EXISTS `hcat_project_cdna_library_prep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_cdna_library_prep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `cdnalibraryprep_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_assay_tech_project_id_assaytech_id_099970cc_uniq` (`project_id`,`cdnalibraryprep_id`),
  KEY `hcat_project_assay_tech_project_id_0d1877f7` (`project_id`),
  KEY `hcat_project_assay_tech_assaytech_id_1a961e03` (`cdnalibraryprep_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_cdna_library_prep`
--

LOCK TABLES `hcat_project_cdna_library_prep` WRITE;
/*!40000 ALTER TABLE `hcat_project_cdna_library_prep` DISABLE KEYS */;
INSERT INTO `hcat_project_cdna_library_prep` VALUES (1,2,1),(2,1,1),(5,2,2),(6,13,1),(7,15,2),(8,18,2),(9,17,7),(10,16,1),(11,22,1),(12,21,1),(13,19,3),(14,23,1),(15,24,2),(16,24,4),(17,25,1),(18,26,2),(19,27,1),(20,28,1),(21,28,2),(22,29,1),(23,30,1),(24,31,2),(25,32,1),(26,34,1),(48,33,10),(28,36,2),(29,37,2),(30,38,2),(31,39,8),(32,40,9),(33,41,1),(46,45,7),(35,43,1),(36,45,11),(37,45,12),(38,46,1),(39,47,1),(40,48,1),(41,48,2),(42,49,2),(43,50,14),(44,51,1),(45,52,8),(47,44,1),(49,53,1),(50,53,2),(51,56,8),(52,57,1),(53,12,15),(54,59,1),(55,62,2),(56,49,1),(57,64,9),(58,64,2),(59,64,12),(60,65,1),(61,66,14);
/*!40000 ALTER TABLE `hcat_project_cdna_library_prep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_contacts`
--

DROP TABLE IF EXISTS `hcat_project_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `contributor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_contacts_project_id_contributor_id_5ba2931c_uniq` (`project_id`,`contributor_id`),
  KEY `hcat_project_contacts_project_id_ce077dfa` (`project_id`),
  KEY `hcat_project_contacts_contributor_id_960b1526` (`contributor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_contacts`
--

LOCK TABLES `hcat_project_contacts` WRITE;
/*!40000 ALTER TABLE `hcat_project_contacts` DISABLE KEYS */;
INSERT INTO `hcat_project_contacts` VALUES (2,11,1),(3,16,83),(4,15,70),(5,13,65),(6,17,97),(7,18,101),(8,19,102),(11,22,116),(10,21,111),(12,23,119),(13,24,123),(14,25,125),(15,26,135),(18,27,165),(40,56,19),(69,52,257),(68,64,255),(67,43,254),(66,47,253),(65,49,252),(64,52,240),(42,57,111),(43,58,220),(44,59,221),(46,60,223),(56,61,233),(58,62,234),(61,63,237);
/*!40000 ALTER TABLE `hcat_project_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_contributors`
--

DROP TABLE IF EXISTS `hcat_project_contributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_contributors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `contributor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_contributor_project_id_contributor_i_b55c023b_uniq` (`project_id`,`contributor_id`),
  KEY `hcat_project_contributors_project_id_7c4f2183` (`project_id`),
  KEY `hcat_project_contributors_contributor_id_678dfbc4` (`contributor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=320 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_contributors`
--

LOCK TABLES `hcat_project_contributors` WRITE;
/*!40000 ALTER TABLE `hcat_project_contributors` DISABLE KEYS */;
INSERT INTO `hcat_project_contributors` VALUES (1,1,1),(2,1,4),(3,1,2),(4,1,21),(5,1,22),(6,1,23),(7,2,24),(8,2,25),(9,2,7),(10,3,26),(11,3,27),(12,3,28),(13,3,29),(14,3,30),(15,3,31),(16,3,32),(17,3,33),(18,3,34),(19,3,35),(20,3,37),(21,3,38),(22,3,39),(23,3,40),(24,3,41),(25,3,42),(26,3,43),(27,3,44),(28,3,45),(29,3,46),(30,3,47),(31,3,48),(32,3,49),(33,3,50),(34,3,51),(35,3,52),(36,3,53),(37,3,54),(38,3,55),(242,53,209),(67,13,66),(62,11,58),(63,11,10),(64,11,11),(65,11,12),(66,12,5),(68,13,67),(69,13,68),(70,13,65),(71,15,70),(72,15,71),(73,15,72),(74,15,73),(75,15,74),(76,15,75),(77,15,76),(78,15,77),(79,15,78),(80,15,79),(81,15,80),(82,15,81),(83,15,82),(84,16,84),(85,16,85),(86,16,86),(87,16,87),(88,16,88),(89,16,89),(90,16,90),(91,16,91),(92,16,92),(93,16,93),(94,16,94),(95,16,95),(96,16,96),(97,16,83),(98,17,97),(99,17,98),(100,17,99),(101,17,100),(102,18,101),(103,19,103),(104,19,104),(105,19,105),(106,19,106),(107,19,107),(108,19,108),(109,19,109),(110,19,110),(111,19,102),(126,23,121),(125,23,120),(124,22,118),(123,22,117),(122,22,116),(117,21,112),(118,21,113),(119,21,114),(120,21,115),(121,21,111),(127,23,122),(128,24,123),(129,24,124),(130,25,126),(131,25,125),(132,25,127),(133,25,128),(134,25,129),(135,25,130),(136,25,131),(137,25,132),(138,25,133),(139,25,134),(140,26,136),(141,26,137),(142,26,138),(143,26,139),(144,26,140),(145,26,141),(146,26,142),(147,26,143),(148,26,144),(149,26,145),(150,26,146),(151,26,147),(152,26,148),(153,26,149),(154,26,150),(155,26,151),(156,26,152),(157,26,153),(158,26,154),(159,26,155),(160,26,156),(161,26,157),(162,26,158),(163,26,159),(164,26,160),(165,26,161),(166,26,162),(167,26,163),(168,26,164),(169,26,135),(238,27,165),(171,27,167),(172,28,172),(173,29,173),(174,29,174),(175,29,175),(176,29,172),(177,29,176),(178,30,177),(179,30,172),(180,31,172),(181,31,176),(182,32,178),(183,32,179),(184,32,180),(185,32,181),(312,32,239),(187,34,177),(188,34,172),(191,36,172),(192,36,186),(193,36,187),(194,37,186),(195,37,188),(196,38,186),(197,38,188),(198,39,189),(240,39,5),(200,40,188),(203,43,192),(204,43,193),(205,43,194),(237,43,6),(207,44,195),(208,44,196),(209,44,197),(210,44,198),(211,44,199),(212,44,200),(213,44,201),(214,44,202),(215,45,203),(216,45,204),(239,45,5),(218,46,172),(219,46,176),(236,47,6),(221,48,174),(222,48,172),(223,48,205),(224,48,187),(225,49,172),(226,49,186),(227,50,206),(228,50,205),(229,51,207),(230,51,208),(231,52,172),(232,41,5),(233,41,191),(234,33,6),(235,33,183),(259,56,13),(260,56,14),(261,56,15),(262,56,16),(263,56,17),(264,56,18),(265,56,19),(266,56,20),(267,57,112),(268,57,219),(269,57,115),(270,57,114),(271,57,111),(272,58,220),(273,59,221),(274,59,222),(275,60,223),(276,60,224),(277,60,225),(278,60,226),(279,60,227),(280,60,228),(281,60,229),(282,60,230),(283,60,231),(284,61,233),(285,61,232),(286,61,81),(289,62,234),(288,62,236),(292,63,237),(291,63,183),(293,52,240),(294,52,241),(295,51,242),(296,51,243),(297,51,244),(298,51,245),(299,51,246),(300,51,247),(301,51,248),(302,51,249),(303,51,250),(304,51,251),(305,49,252),(306,47,253),(307,43,254),(308,64,255),(309,64,256),(310,52,257),(311,53,239),(313,65,258),(314,65,239),(315,66,192),(316,66,193),(317,66,194),(318,66,6),(319,67,7);
/*!40000 ALTER TABLE `hcat_project_contributors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_disease`
--

DROP TABLE IF EXISTS `hcat_project_disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_disease` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `disease_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_disease_project_id_disease_id_59397fe9_uniq` (`project_id`,`disease_id`),
  KEY `hcat_project_disease_project_id_9dab5ae6` (`project_id`),
  KEY `hcat_project_disease_disease_id_5631dfbf` (`disease_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_disease`
--

LOCK TABLES `hcat_project_disease` WRITE;
/*!40000 ALTER TABLE `hcat_project_disease` DISABLE KEYS */;
INSERT INTO `hcat_project_disease` VALUES (1,1,1),(2,2,2),(3,3,2),(14,13,2),(11,11,2),(12,12,2),(13,12,3),(15,15,2),(18,16,2),(17,16,8),(19,17,2),(20,18,2),(21,18,9),(22,18,10),(23,18,11),(24,19,2),(25,21,2),(26,22,2),(27,23,2),(28,23,12),(29,24,2),(30,25,2),(31,26,2),(32,26,13),(33,27,2),(34,36,2),(35,36,3),(37,31,14),(38,56,2),(39,57,2),(40,58,2),(41,59,2),(42,60,2),(43,61,2),(44,62,2),(45,63,2),(46,47,2),(47,52,2),(48,52,3),(49,51,2),(50,66,2);
/*!40000 ALTER TABLE `hcat_project_disease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_grants`
--

DROP TABLE IF EXISTS `hcat_project_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_grants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `grant_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_grants_project_id_grant_id_85770e16_uniq` (`project_id`,`grant_id`),
  KEY `hcat_project_grants_project_id_44cf85bc` (`project_id`),
  KEY `hcat_project_grants_grant_id_9cbff215` (`grant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_grants`
--

LOCK TABLES `hcat_project_grants` WRITE;
/*!40000 ALTER TABLE `hcat_project_grants` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_project_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_labs`
--

DROP TABLE IF EXISTS `hcat_project_labs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_labs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `lab_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_labs_project_id_lab_id_841c4833_uniq` (`project_id`,`lab_id`),
  KEY `hcat_project_labs_project_id_dfc8abdd` (`project_id`),
  KEY `hcat_project_labs_lab_id_7261c9d2` (`lab_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_labs`
--

LOCK TABLES `hcat_project_labs` WRITE;
/*!40000 ALTER TABLE `hcat_project_labs` DISABLE KEYS */;
INSERT INTO `hcat_project_labs` VALUES (1,1,1),(2,2,2),(8,17,7),(7,11,5),(11,23,9),(10,21,8),(12,24,10),(15,56,11),(16,57,8),(17,58,12),(18,51,13),(19,41,14),(20,66,16),(21,66,15);
/*!40000 ALTER TABLE `hcat_project_labs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_organ`
--

DROP TABLE IF EXISTS `hcat_project_organ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_organ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `organ_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_organ_project_id_organ_id_c5884702_uniq` (`project_id`,`organ_id`),
  KEY `hcat_project_organ_project_id_a275bb67` (`project_id`),
  KEY `hcat_project_organ_organ_id_a1ca29e9` (`organ_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_organ`
--

LOCK TABLES `hcat_project_organ` WRITE;
/*!40000 ALTER TABLE `hcat_project_organ` DISABLE KEYS */;
INSERT INTO `hcat_project_organ` VALUES (6,1,1),(4,11,8),(5,12,5),(7,13,9),(8,15,10),(9,16,11),(10,16,9),(11,17,9),(12,18,12),(15,22,13),(14,21,5),(16,22,9),(17,23,14),(18,24,11),(19,25,5),(20,26,9),(21,27,10),(22,52,4),(23,44,10),(24,36,4),(26,32,5),(27,28,15),(28,29,16),(29,29,17),(30,29,2),(32,56,2),(33,57,5),(34,58,18),(35,59,18),(36,60,5),(37,61,14),(38,62,13),(39,63,9),(40,47,6),(41,43,7),(42,51,19),(43,51,9),(44,51,2),(45,51,11),(46,49,9),(47,41,11),(48,40,11),(49,39,5),(50,66,10);
/*!40000 ALTER TABLE `hcat_project_organ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_organ_part`
--

DROP TABLE IF EXISTS `hcat_project_organ_part`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_organ_part` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `organpart_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_body_part_project_id_bodypart_id_2181d641_uniq` (`project_id`,`organpart_id`),
  KEY `hcat_project_body_part_project_id_deafaf9e` (`project_id`),
  KEY `hcat_project_body_part_bodypart_id_a4860a5d` (`organpart_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_organ_part`
--

LOCK TABLES `hcat_project_organ_part` WRITE;
/*!40000 ALTER TABLE `hcat_project_organ_part` DISABLE KEYS */;
INSERT INTO `hcat_project_organ_part` VALUES (1,1,1),(2,3,2),(13,13,8),(11,11,7),(12,12,4),(14,15,9),(15,16,10),(16,16,11),(17,17,12),(18,17,13),(19,17,14),(20,17,15),(21,17,16),(22,17,17),(23,17,18),(24,18,19),(25,19,20),(32,21,6),(31,21,5),(28,23,23),(29,23,24),(30,23,25),(33,24,26),(34,25,5),(35,26,28),(36,27,29),(37,27,30),(38,44,29),(39,38,31),(40,34,32),(41,30,32),(42,56,33),(43,57,4),(44,58,35),(45,58,36),(46,58,37),(47,58,38),(48,59,35),(49,62,39),(50,62,40),(51,63,41),(52,63,42),(53,63,43),(54,47,44),(55,47,45),(56,47,46),(57,52,47),(58,66,29);
/*!40000 ALTER TABLE `hcat_project_organ_part` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_preservation_method`
--

DROP TABLE IF EXISTS `hcat_project_preservation_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_preservation_method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `preservationmethod_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_preservatio_project_id_preservationm_02c28996_uniq` (`project_id`,`preservationmethod_id`),
  KEY `hcat_project_preservation_method_project_id_614f12e4` (`project_id`),
  KEY `hcat_project_preservation_method_preservationmethod_id_8750acef` (`preservationmethod_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_preservation_method`
--

LOCK TABLES `hcat_project_preservation_method` WRITE;
/*!40000 ALTER TABLE `hcat_project_preservation_method` DISABLE KEYS */;
INSERT INTO `hcat_project_preservation_method` VALUES (1,66,1);
/*!40000 ALTER TABLE `hcat_project_preservation_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_publications`
--

DROP TABLE IF EXISTS `hcat_project_publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_publications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `publication_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_publication_project_id_publication_i_8c90a466_uniq` (`project_id`,`publication_id`),
  KEY `hcat_project_publications_project_id_95d1e789` (`project_id`),
  KEY `hcat_project_publications_publication_id_313b37c7` (`publication_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_publications`
--

LOCK TABLES `hcat_project_publications` WRITE;
/*!40000 ALTER TABLE `hcat_project_publications` DISABLE KEYS */;
INSERT INTO `hcat_project_publications` VALUES (1,1,1),(2,3,2),(5,11,3),(6,15,4),(7,17,5),(8,23,6),(9,24,7),(10,27,8),(11,12,10),(14,56,11),(15,57,12),(16,58,13),(17,59,14),(18,60,15),(19,61,16),(20,63,17),(21,49,18),(22,47,19),(23,43,20),(24,41,21),(25,39,22),(26,38,23),(27,64,24);
/*!40000 ALTER TABLE `hcat_project_publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_sample_type`
--

DROP TABLE IF EXISTS `hcat_project_sample_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_sample_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `sampletype_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_sample_type_project_id_sampletype_id_24d5e6dc_uniq` (`project_id`,`sampletype_id`),
  KEY `hcat_project_sample_type_project_id_219fb241` (`project_id`),
  KEY `hcat_project_sample_type_sampletype_id_d697a9eb` (`sampletype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_sample_type`
--

LOCK TABLES `hcat_project_sample_type` WRITE;
/*!40000 ALTER TABLE `hcat_project_sample_type` DISABLE KEYS */;
INSERT INTO `hcat_project_sample_type` VALUES (5,1,1),(10,27,1),(9,12,1),(12,29,1),(13,47,1),(14,38,4),(15,64,2),(16,65,4),(17,66,1);
/*!40000 ALTER TABLE `hcat_project_sample_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_species`
--

DROP TABLE IF EXISTS `hcat_project_species`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_species` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `species_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_species_project_id_species_id_cf70c5cc_uniq` (`project_id`,`species_id`),
  KEY `hcat_project_species_project_id_99f8f1ab` (`project_id`),
  KEY `hcat_project_species_species_id_7a05e848` (`species_id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_species`
--

LOCK TABLES `hcat_project_species` WRITE;
/*!40000 ALTER TABLE `hcat_project_species` DISABLE KEYS */;
INSERT INTO `hcat_project_species` VALUES (1,1,1),(2,2,2),(5,3,2),(14,13,1),(12,11,1),(13,12,1),(15,15,1),(16,16,1),(17,17,1),(18,18,1),(19,19,1),(20,19,2),(23,22,1),(22,21,1),(24,23,1),(25,24,1),(26,25,1),(27,26,1),(28,27,1),(29,28,1),(30,28,2),(31,29,1),(32,30,1),(33,31,2),(34,32,1),(35,33,1),(36,34,1),(38,36,1),(39,37,1),(40,38,1),(41,39,1),(42,40,1),(43,41,1),(55,44,1),(45,43,1),(46,45,1),(47,46,1),(48,47,2),(49,48,1),(50,49,1),(51,50,1),(52,51,1),(53,52,1),(54,52,2),(60,56,1),(61,56,2),(62,57,1),(63,58,2),(64,59,2),(65,60,2),(66,61,1),(67,62,1),(68,63,1),(69,64,2),(70,65,1),(71,66,1);
/*!40000 ALTER TABLE `hcat_project_species` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_tags`
--

DROP TABLE IF EXISTS `hcat_project_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_tags_project_id_tag_id_86cb0966_uniq` (`project_id`,`tag_id`),
  KEY `hcat_project_tags_project_id_52c054e4` (`project_id`),
  KEY `hcat_project_tags_tag_id_5d2bd4be` (`tag_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_tags`
--

LOCK TABLES `hcat_project_tags` WRITE;
/*!40000 ALTER TABLE `hcat_project_tags` DISABLE KEYS */;
INSERT INTO `hcat_project_tags` VALUES (1,66,3);
/*!40000 ALTER TABLE `hcat_project_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_project_urls`
--

DROP TABLE IF EXISTS `hcat_project_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_project_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `url_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_project_urls_project_id_url_id_24c08cd7_uniq` (`project_id`,`url_id`),
  KEY `hcat_project_urls_project_id_dee701af` (`project_id`),
  KEY `hcat_project_urls_url_id_983d2564` (`url_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_project_urls`
--

LOCK TABLES `hcat_project_urls` WRITE;
/*!40000 ALTER TABLE `hcat_project_urls` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_project_urls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_projectsourcetype`
--

DROP TABLE IF EXISTS `hcat_projectsourcetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_projectsourcetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_projectsourcetype`
--

LOCK TABLES `hcat_projectsourcetype` WRITE;
/*!40000 ALTER TABLE `hcat_projectsourcetype` DISABLE KEYS */;
INSERT INTO `hcat_projectsourcetype` VALUES (1,'import GEO','Imported from NCBI\'s Gene Expression Omnibus (GEO) using UCSC Strex pipeline',''),(2,'live wrangling','Imported into hca by live HCA-sponsered wrangling efforts','');
/*!40000 ALTER TABLE `hcat_projectsourcetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_projectstatus`
--

DROP TABLE IF EXISTS `hcat_projectstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_projectstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(30) NOT NULL,
  `description` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_projectstate_state_d27d4743_uniq` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_projectstatus`
--

LOCK TABLES `hcat_projectstatus` WRITE;
/*!40000 ALTER TABLE `hcat_projectstatus` DISABLE KEYS */;
INSERT INTO `hcat_projectstatus` VALUES (1,'suitable','Interesting dataset might be good for HCA'),(2,'unsuitable','Project evaluated and found unsuitable for the HCA'),(3,'stalled','Work got started but it\'s stalled until somebody kicks it'),(4,'wrangling','Wrangling work is proceeding actively on project'),(7,'submitted','Project has been submitted to ingest'),(8,'ingested','project has passed through ingestion and is visible in blue box'),(9,'primary analysis','Compute before step of making gene/cell matrix.  Aligning reads, registering images, etc.'),(10,'cell matrix','a matrix that relates cell to cell measurements, typically RNA levels'),(11,'cell clusters','Have a computationally generated typology of cells inferred from the data'),(12,'cell types','Have a human curated set of cell types relevant to this data set');
/*!40000 ALTER TABLE `hcat_projectstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_publication`
--

DROP TABLE IF EXISTS `hcat_publication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_publication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `pmid` varchar(16) NOT NULL,
  `doi` varchar(32) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_publication`
--

LOCK TABLES `hcat_publication` WRITE;
/*!40000 ALTER TABLE `hcat_publication` DISABLE KEYS */;
INSERT INTO `hcat_publication` VALUES (1,'pmid: 26878113','The heterogeneity of human CD127(+) innate lymphoid cells revealed by single-cell RNA sequencing.','26878113','10.1038/ni.3368',''),(2,'pmid: 30069044','A revised airway epithelial hierarchy includes CFTR-expressing ionocytes.','30069044','10.1038/s41586-018-0393-7',''),(3,'pmid: 29167569','Single-cell analysis reveals the continuum of human lympho-myeloid progenitor cells','29167569','0.1038/s41590-017-0001-2',''),(4,'pmid: 31269016','Dissecting the transcriptome landscape of the human fetal neural retina and retinal pigment epithelium by single-cell RNA-seq analysis','31269016','10.1371/journal.pbio.3000365',''),(5,'pmid: 31253076','Single cell RNA-Seq reveals pre-cDCs fate determined by transcription factor combinatorial dose','31253076','10.1186/s12860-019-0199-y',''),(6,'pmid: 31320652','Single-cell reconstruction of follicular remodeling in the human adult ovary','31320652','10.1038/s41467-019-11036-9',''),(7,'pmid: 31178118','Comprehensive Integration of Single-Cell Data','31178118','10.1016/j.cell.2019.05.031',''),(8,'pmid: 31075224','Molecular characterization of foveal versus peripheral human retina by single-cell RNA sequencing','31075224','31075224',''),(9,'pmid: 30787436','A single-cell molecular map of mouse gastrulation and early organogenesis','30787436','10.1038/s41586-019-0933-9',''),(10,'pmid: 31506348','The single-cell transcriptomic landscape of early human diabetic nephropathy.','31506348','10.1073/pnas.1908706116',''),(11,'pmid: 30069046','A single-cell atlas of the airway epithelium reveals the CFTR-rich pulmonary ionocyte','30069046','10.1038/s41586-018-0394-6',''),(12,'pmid: 29449449','Conserved and Divergent Features of Mesenchymal Progenitor Cell Types within the Cortical Nephrogenic Niche of the Human and Mouse Kidney','29449449','10.1681/ASN.2017080890',''),(13,'pmid: 29158510','Construction of developmental lineage relationships in the mouse mammary gland by single-cell RNA profiling','29158510','10.1038/s41467-017-01560-x',''),(14,'pmid: 29225342','Differentiation dynamics of mammary epithelial cells revealed by single-cell RNA sequencing','29225342','10.1038/s41467-017-02001-5',''),(15,'pmid: 29622724','Single-cell transcriptomics of the mouse kidney reveals potential cellular targets of kidney disease','29622724','10.1126/science.aar2131',''),(16,'pmid: 30472193','Transcriptome Landscape of Human Folliculogenesis Reveals Oocyte and Granulosa Cell Interactions','30472193','10.1016/j.molcel.2018.10.029',''),(17,'pmid: 27864467','Human dendritic cells (DCs) are derived from distinct circulating precursors that are precommitted to become CD1c+ or CD141+ DCs','27864467','10.1084/jem.20161135',''),(18,'pmid: 29352091','Precursors of human CD4+ cytotoxic T lymphocytes identified by single-cell transcriptome analysis','29352091','10.1126/sciimmunol.aan8664',''),(19,'pmid: 28091601','Massively parallel digital transcriptional profiling of single cells.','28091601','10.1038/ncomms14049',''),(20,'pmid: 30348985','Single cell RNA sequencing of human liver reveals distinct intrahepatic macrophage populations','30348985','10.1038/s41467-018-06318-7',''),(21,'pmid: 30899105','Characterization of cell fate probabilities in single-cell data with Palantir','30899105','10.1038/s41587-019-0068-4',''),(22,'pmid: 29980650','Single-Cell Transcriptomics of a Human Kidney Allograft Biopsy Specimen Defines a Diverse Inflammatory Response','29980650','10.1681/ASN.2018020125',''),(23,'pmid: 28279351','Single-Cell Profiling of an In Vitro Model of Human Interneuron Development Reveals Temporal Dynamics of Cell Type Production and Maturation','28279351','10.1016/j.neuron.2017.02.014',''),(24,'pmid: 28212749','Comparative Analysis of Single-Cell RNA Sequencing Methods','28212749','','');
/*!40000 ALTER TABLE `hcat_publication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_sampletype`
--

DROP TABLE IF EXISTS `hcat_sampletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_sampletype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_sampletype_short_name_0d95d0a4_uniq` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_sampletype`
--

LOCK TABLES `hcat_sampletype` WRITE;
/*!40000 ALTER TABLE `hcat_sampletype` DISABLE KEYS */;
INSERT INTO `hcat_sampletype` VALUES (1,'primary tissue','Tissue taken directly from organism without intermediate culture',''),(2,'standard cell line','a standard cell line that can be purchased from commercial sources easiliy',''),(3,'iPSC','Induced pluripotent stem cell',''),(4,'organoid','organoid artificially produced from stem cells',''),(5,'cancer','cancerous cells',''),(6,'frozen sample','sample frozen while fresh and stored suitably',''),(7,'primary cell line','cells cultured from fresh tissue samples without treatment to immortalize the culture',''),(8,'immortalized cell line','cells treated with EBV or other agents so that they can divide forever, escaping the Hayflick limit',''),(9,'xenograft','most commonly some human cells implanted in a SCID mouse to see what happens','');
/*!40000 ALTER TABLE `hcat_sampletype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_softwaredeveloper`
--

DROP TABLE IF EXISTS `hcat_softwaredeveloper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_softwaredeveloper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `favorite_languages` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `who_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hcat_softwaredeveloper_who_id_ae39ad9c` (`who_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_softwaredeveloper`
--

LOCK TABLES `hcat_softwaredeveloper` WRITE;
/*!40000 ALTER TABLE `hcat_softwaredeveloper` DISABLE KEYS */;
INSERT INTO `hcat_softwaredeveloper` VALUES (1,'C,  Python, awk, rexx','',4),(2,'Javascript, C, Python','',56),(3,'PhP','',3);
/*!40000 ALTER TABLE `hcat_softwaredeveloper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_species`
--

DROP TABLE IF EXISTS `hcat_species`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_species` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `common_name` varchar(40) NOT NULL,
  `scientific_name` varchar(150) NOT NULL,
  `ncbi_taxon` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_species_ncbi_taxon_04279782_uniq` (`ncbi_taxon`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_species`
--

LOCK TABLES `hcat_species` WRITE;
/*!40000 ALTER TABLE `hcat_species` DISABLE KEYS */;
INSERT INTO `hcat_species` VALUES (1,'human','Homo sapiens',9606),(2,'mouse','Mus musculus',10090);
/*!40000 ALTER TABLE `hcat_species` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_tag`
--

DROP TABLE IF EXISTS `hcat_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(40) NOT NULL,
  `description` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_tag`
--

LOCK TABLES `hcat_tag` WRITE;
/*!40000 ALTER TABLE `hcat_tag` DISABLE KEYS */;
INSERT INTO `hcat_tag` VALUES (1,'preview','One of three sets of data for preview site'),(2,'soft launch','The closed beta or soft launch'),(3,'Barcelona incentives','Projects incentivized by a trip to Barcelona and a speaking slot in 2019');
/*!40000 ALTER TABLE `hcat_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_tag_projects`
--

DROP TABLE IF EXISTS `hcat_tag_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_tag_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hcat_tag_projects_tag_id_project_id_b8fd01ee_uniq` (`tag_id`,`project_id`),
  KEY `hcat_tag_projects_tag_id_60337f2f` (`tag_id`),
  KEY `hcat_tag_projects_project_id_fc00f439` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_tag_projects`
--

LOCK TABLES `hcat_tag_projects` WRITE;
/*!40000 ALTER TABLE `hcat_tag_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hcat_tag_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_tracker`
--

DROP TABLE IF EXISTS `hcat_tracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_tracker` (
  `uuid` varchar(37) NOT NULL,
  `submission_id` varchar(33) NOT NULL,
  `submission_bundles_exported_count` int(11) NOT NULL,
  `aws_primary_bundle_count` int(11) NOT NULL,
  `gcp_primary_bundle_count` int(11) NOT NULL,
  `aws_analysis_bundle_count` int(11) NOT NULL,
  `gcp_analysis_bundle_count` int(11) NOT NULL,
  `azul_analysis_bundle_count` int(11) NOT NULL,
  `succeeded_workflows` int(11) NOT NULL,
  `matrix_bundle_count` int(11) NOT NULL,
  `matrix_cell_count` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`project_id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `submission_id` (`submission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_tracker`
--

LOCK TABLES `hcat_tracker` WRITE;
/*!40000 ALTER TABLE `hcat_tracker` DISABLE KEYS */;
INSERT INTO `hcat_tracker` VALUES ('f8aa201c-4ff1-45a4-890e-840d63459ca2','5d97141c71fe4a0008e0cd74',381,371,371,10,10,10,17,10,61604,28),('88ec040b-8705-4f77-8f41-f81e57632f7d','5d9dfd3771fe4a0008e10b5b',2618,2618,2618,765,765,765,765,0,0,67),('c4077b3c-5c98-4d26-a614-246d12c2e5d7','5cdc5ab4d96dad000859cebf',7,7,7,7,7,7,14,7,73515,29),('28ef60e5-1a4b-408f-8ac4-0e454304d8a6','5d0b619d88fa640008afc1d8',2,0,0,0,0,0,2,0,0,30),('8c3c290d-dfff-4553-8868-54ce45f4ba7f','5cda9de6d96dad00085796b9',6639,6639,6639,0,0,0,0,0,0,31),('abe1a013-af7a-45ed-8c26-f3793c24a1f4','5d53e0e68f8dfc00081dd8c5',47,47,47,47,47,47,47,47,552445,32),('f81efc03-9f56-4354-aabb-6ce819c3d414','5cdecb31a129310008b599a3',3,3,3,0,0,0,0,0,0,33),('116965f3-f094-4769-9d28-ae675c1b569c','5d8c9da2bddf5d0008e73147',0,3,3,3,3,3,3,3,15744,65),('005d611a-14d5-4fbf-846e-571a1f874f70','5cdbdd7dd96dad0008592f28',6,6,6,6,6,6,12,6,156936,34),('e0009214-c0a0-4a7b-96e2-d6a83e966ce0','5d24eda088fa640008b02b26',99840,99840,99840,0,0,0,0,0,0,2),('9c20a245-f2c0-43ae-82c9-2232ec6b594f','5d848dfdbddf5d0008992fd5',11,11,11,0,0,0,0,0,0,66),('ae71be1d-ddd8-4feb-9bed-24c3ddb6e1ad','5cda8757d96dad000856d2ae',3514,3514,3514,0,0,0,0,0,0,36),('cddab57b-6868-4be4-806f-395ed9dd635a','5cd588a4d96dad00085634a2',2544,2544,2544,2544,2544,2544,2603,2544,2544,37),('4d6f6c96-2a83-43d8-8fe1-0f53bffd4674','5d85050cbddf5d0008993515',5,5,5,5,5,5,5,5,299486,43),('8185730f-4113-40d3-9cc3-929271784c2b','5d7b555b118ea600080928af',5,5,5,5,5,5,5,5,41350,44),('2043c65a-1cf8-4828-a656-9e247d4e64f1','5cdb0344d96dad000858fff4',1733,1733,1733,1733,1733,1733,1736,1733,1733,38),('027c51c6-0719-469f-a7f5-640fe57cbece','5cdd20ffd96dad00085b0ff7',7,7,7,0,0,0,0,0,0,39),('a29952d9-925e-40f4-8a1c-274f118f1f51','5cdd1fcdd96dad00085af1ae',25,25,25,0,0,0,0,0,0,40),('091cf39b-01bc-42e5-9437-f419a66c8a45','5d30e0c49be88c0008a9b236',9,9,9,9,9,9,9,9,41331,41),('a9c022b4-c771-4468-b769-cabcf9738de3','5cdc1a0ad96dad0008593264',22,22,22,0,0,0,0,0,0,45),('cc95ff89-2e68-4a08-a234-480eca21ce79','5d1c67c688fa640008aff7cc',127,127,127,127,127,127,127,127,782859,46),('74b6d569-3b11-42ef-b6b1-a0454522b4a0','5cdd8b32d96dad0007e5a0ed',5459,5459,5459,0,0,0,0,0,0,47),('f83165c5-e2ea-4d15-a5cf-33f3550bffde','5cdc1b4ad96dad0008593302',7628,7628,7628,7628,7628,7628,7638,7628,546183,48),('90bd6933-40c0-48d4-8d76-778c103bf545','5cdd6c44d96dad0007e3cc8f',2244,2244,2244,0,0,0,0,0,0,49),('577c946d-6de5-4b55-a854-cd3fde40bff2','5d70097870c279000835d6ef',6,6,6,0,0,0,0,0,0,12),('1defdada-a365-44ad-9b29-443b06bd11d6','5d8b3aaebddf5d000810d6a8',2560,2560,2560,0,0,0,0,0,0,53),('008e40e8-66ae-43bb-951c-c073a2fa6774','5d2888ff88fa640008b669b6',38,38,38,0,0,0,0,0,0,50),('4a95101c-9ffc-4f30-a809-f04518a23803','5d7bd747bddf5d000898e7e5',16,16,16,16,16,16,16,16,267360,51),('f86f1ab4-1fbb-4510-ae35-3ffd752d4dfc','5d1e015c88fa640008b0009d',19,19,19,0,0,0,0,0,0,52);
/*!40000 ALTER TABLE `hcat_tracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_url`
--

DROP TABLE IF EXISTS `hcat_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short_name` varchar(50) NOT NULL,
  `path` varchar(200) NOT NULL,
  `description` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_url`
--

LOCK TABLES `hcat_url` WRITE;
/*!40000 ALTER TABLE `hcat_url` DISABLE KEYS */;
INSERT INTO `hcat_url` VALUES (1,'UCSC Genome Browser','https://genome.ucsc.edu','Many different annotations mapped to the genomic sequence viewable at a variety of scales.','');
/*!40000 ALTER TABLE `hcat_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_wrangler`
--

DROP TABLE IF EXISTS `hcat_wrangler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_wrangler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who_id` int(11) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hcat_wrangler_who_id_2d32e57b` (`who_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_wrangler`
--

LOCK TABLES `hcat_wrangler` WRITE;
/*!40000 ALTER TABLE `hcat_wrangler` DISABLE KEYS */;
INSERT INTO `hcat_wrangler` VALUES (6,3,''),(5,6,''),(3,5,''),(4,7,''),(7,4,''),(9,172,''),(11,188,''),(12,176,''),(14,239,''),(15,202,''),(16,205,'');
/*!40000 ALTER TABLE `hcat_wrangler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hcat_wranglingstatus`
--

DROP TABLE IF EXISTS `hcat_wranglingstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hcat_wranglingstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(30) NOT NULL,
  `description` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `state` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hcat_wranglingstatus`
--

LOCK TABLES `hcat_wranglingstatus` WRITE;
/*!40000 ALTER TABLE `hcat_wranglingstatus` DISABLE KEYS */;
INSERT INTO `hcat_wranglingstatus` VALUES (1,'starting','Primary wrangler has started to look at project.'),(2,'wrangling','Wrangler has accepted project and is actively working on it.'),(3,'review','Initial wrangling done, being reviewed by quality assurance and lab'),(4,'staged','lab is satisfied with metadata representation and files are in staging area'),(5,'submitted','project has been submitted to ingest');
/*!40000 ALTER TABLE `hcat_wranglingstatus` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-18  0:22:58
