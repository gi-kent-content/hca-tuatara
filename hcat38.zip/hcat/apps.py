from django.apps import AppConfig


class HcatConfig(AppConfig):
    name = 'hcat'
